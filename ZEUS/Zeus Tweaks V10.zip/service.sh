#!/system/bin/sh
# Written By @PietroVN

# Wait for boot to finish completely
while true; do
	if [[ $(getprop sys.boot_completed) ]]; then
	break ; fi
done

# Enable Spectrum support
setprop persist.spectrum.kernel "ZeusTweaks"
setprop spectrum.support 1

su -c "zeustweaks &"
