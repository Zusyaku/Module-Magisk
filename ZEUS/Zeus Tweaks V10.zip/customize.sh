#!/system/bin/sh
# Written By (@tytydraco) 
# Modified  by (Teixeira & Telegram @kodekasu)
# (Whitten Credits @PietroVn)

sleep 0.9
ui_print "**************************************"
ui_print "                                      "
ui_print "            Zeus Tweaks v10!          "
ui_print "                                      "
ui_print "**************************************"


##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

set_perm_recursive "$MODPATH/system/bin" root root 0777 0755

sleep 1
ui_print " Spectrum Support!"
# Enable Spectrum support
setprop persist.spectrum.kernel "ZeusTweaks"
setprop spectrum.support 1
ui_print "	"

sleep 3
ui_print "[*] Live Boot!"

su -c "sh $MODPATH/system/bin/zeustweaks &"
ui_print "	"

sleep 2
ui_print "[*] Performing adjustments.... "
sleep 2