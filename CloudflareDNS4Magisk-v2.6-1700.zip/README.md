As John Graham-Cumming announced, CloudFare now offers its own DNS service.
And surprise of the Boss if we believe his words: your history of browsing isn't saved on their servers !

DNS ?? Gne ?? What's this ?

To make it short: a DNS server makes the correspondence between the IP address of a requested website, and its domain name (forum.xda-developers.com for example).

For the long version a little reading is necessary: https://en.wikipedia.org/wiki/Domain_Name_System

The purpose of this module?
Forward all mobile data via their servers.


Requirements:

    An android device (something tells me if you're here it's because you have one..)
    Magisk installed (v15+ at least)
    five minutes of your free-times (and a little piece of your brain (just in case))



If you trust them, so you can install the module properly, restart and enjoy!
