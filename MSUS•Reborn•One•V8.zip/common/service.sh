Speed Power By DwikaNugraha

MODDIR=${0%/*}

# System Permission Tweaks Set Config;
chmod 775 /system/etc/cleaner;
chown root root /system/etc/cleaner;
chgrp shell shell /system/etc/cleaner;
chmod 775 /system/etc/booster;
chown root root /system/etc/booster;
chgrp shell shell /system/etc/booster;
chmod 775 /system/etc/fstrim;
chown root root /system/etc/fstrim;
chgrp shell shell /system/etc/fstrim;
chmod 775 /system/etc/schedulerboost;
chown root root /system/etc/schedulerboost;
chgrp shell shell /system/etc/schedulerboost;
chmod 775 /system/etc/loopysmoothness;
chown root root /system/etc/loopysmoothness;
chgrp shell shell /system/etc/loopysmoothness;
chmod 775 /system/etc/wakelock;
chown root root /system/etc/wakelock;
chgrp shell shell /system/etc/wakelock;
chmod 777 /system/bin/busybox;
chown root root /system/bin/busybox;
chgrp shell shell /system/bin/busybox;
chmod 755 /system/bin/flush;
chown root root /system/bin/flush;
chgrp shell shell /system/bin/flush;
chmod 755 /system/bin/flush2;
chown root root /system/bin/flush2;
chgrp shell shell /system/bin/flush2;

while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

sleep 30

for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh);;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done
exit 0
