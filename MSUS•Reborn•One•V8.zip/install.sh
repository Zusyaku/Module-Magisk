# ------------------------------------------------------------------------------------------
# 𝗠𝗦𝗨𝗦𝗥𝗲𝗯𝗼𝗿𝗻#𝗢𝗻𝗲𝗩8
# 𝗞𝗲𝘆 𝗦𝗲𝗹𝗲𝗰𝘁𝗼𝗿 𝗕𝗮𝘀𝗲𝗱 𝗢𝗻 @𝗪𝗲𝗔𝗿𝗲𝗥𝗮𝘃𝗲𝗻𝗦 & 113
# 𝗚𝗶𝘃𝗲 𝗔 𝗣𝗿𝗼𝗽𝗲𝗿 𝗖𝗿𝗲𝗱𝗶𝘁𝘀 𝗜𝗳 𝗬𝗼𝘂 𝗨𝘀𝗶𝗻𝗴 𝗔 𝗣𝗮𝗿𝘁 𝗢𝗳 𝗔𝗻𝘆 𝗖𝗼𝗱𝗲𝘀
# 𝗧𝗛𝗔𝗡𝗞𝗦 !
# 𝗞𝗮𝗻𝗴𝗲𝗿=𝗗𝗲𝗮𝗱
# -------------------------------------------------------------------------------------------

print_modname() {
ui_print " 
███╗░░░███╗░██████╗██╗░░░██╗░██████╗
████╗░████║██╔════╝██║░░░██║██╔════╝
██╔████╔██║╚█████╗░██║░░░██║╚█████╗░
██║╚██╔╝██║░╚═══██╗██║░░░██║░╚═══██╗
██║░╚═╝░██║██████╔╝╚██████╔╝██████╔╝
╚═╝░░░░░╚═╝╚═════╝░░╚═════╝░╚═════╝░

██████╗░░░░░█████╗░███╗░░██╗███████╗
██╔══██╗░░░██╔══██╗████╗░██║██╔════╝
██████╔╝░░░██║░░██║██╔██╗██║█████╗░░
██╔══██╗░░░██║░░██║██║╚████║██╔══╝░░
██║░░██║██╗╚█████╔╝██║░╚███║███████╗
╚═╝░░╚═╝╚═╝░╚════╝░╚═╝░░╚══╝╚══════╝

██╗░░░██╗░░░░█████╗░
██║░░░██║░░░██╔══██╗
╚██╗░██╔╝░░░╚█████╔╝
░╚████╔╝░░░░██╔══██╗
░░╚██╔╝░░██╗╚█████╔╝
░░░╚═╝░░░╚═╝░╚════╝░
                           "
sleep 2
ui_print " [@𝗱𝘄𝗶𝗸𝗮𝗻𝘂𝗴𝗿𝗮𝗵𝗮-𝘁𝗲𝗹𝗲𝗴𝗿𝗮𝗺]  "
sleep 2
 }

REPLACE=" 
"
props=$TMPDIR/system.prop
DNS=$MODPATH/msus/Mod/dns
DNMODS=$MODPATH/msus/Mod
MSUS=$MODPATH/msus
ZRAM=$TMPDIR/post-fs-data.sh
THERMAL=$MODPATH/msus/thermod
SET=/data/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/GameUserSettings.ini
SKIPMOUNT=false

on_install() {

sleep 1
	rm -rf \
	/data/adb/modules/MSUSReborn/config \
	/data/adb/modules/MSUSReborn/system.prop \
  /data/adb/modules/MSUSReborn/module.prop \
	/data/adb/modules/MSUSReborn/service.sh \
	/data/adb/modules/MSUSReborn/post-fs-data.sh \
	/data/adb/modules/MSUSReborn/msus \
	/data/adb/modules/MSUSReborn/system \
  /storage/emulated/0/MSuSReborn.log
sleep 1

  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'msus/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  unzip -o "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" -x 'META-INF/*' 'common/functions.sh' -d $MODPATH >&2
[ -f "$MODPATH/common/binary.tar.xz" ] && tar -xf $MODPATH/common/addon.tar.xz -C $MODPATH/common 2>/dev/null

touch /storage/emulated/0/MSuSReborn.log
mkdir $MODPATH/config
mkdir $MODPATH/system
mkdir $MODPATH/system/lib
mkdir $MODPATH/system/lib64
mkdir $MODPATH/system/etc
mkdir $MODPATH/system/etc/init
mkdir $MODPATH/system/bin
mkdir $MODPATH/system/vendor
mkdir $MODPATH/system/vendor/app
mkdir $MODPATH/system/vendor/app/com.qualcomm.qti.improvetouch.service
mkdir $MODPATH/system/vendor/lib
mkdir $MODPATH/system/vendor/lib64
mkdir $MODPATH/system/vendor/bin
mkdir $MODPATH/system/vendor/etc

 .  $TMPDIR/functions.sh
 .  $TMPDIR/addon/Volume-Key-Selector/preinstall.sh

ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "▒             𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼 "
ui_print "▒ 📱𝗗𝗲𝘃𝗶𝗰𝗲 : $(getprop ro.product.model) "
sleep 0.2
ui_print "▒ 📱𝗕𝗿𝗮𝗻𝗱 : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "▒ 📱𝗠𝗼𝗱𝗲𝗹 : $(getprop ro.build.product) "
sleep 0.2
ui_print "▒ 📱𝐊𝐞𝐫𝐧𝐞𝐥 : $(uname -r) "
sleep 0.2
ui_print "▒ 📱𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗼𝗿 : $(getprop ro.product.board)"
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print " 𝗦𝘁𝗮𝗿𝘁𝗶𝗻 𝗠𝗼𝗱𝘂𝗹𝗲 𝗜𝗻𝘀𝘁𝗮𝗹𝗹𝗮𝘁𝗶𝗼𝗻 "
sleep 1
ui_print "   ⚠️ [𝙑𝙤𝙡𝙪𝙢𝙚 + ] 𝙉𝙚𝙭𝙩 "
ui_print "   ⚠️ [𝙑𝙤𝙡𝙪𝙢𝙚 - ] 𝙄𝙣𝙨𝙩𝙖𝙡𝙡 "
sleep 2
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🆄🅽🅻🅾🅲🅺🅴🆁 🅼🅾🅳🅴: "
ui_print " 1. 𝗣𝗨𝗕𝗚 𝗠𝗼𝗯𝗶𝗹𝗲 𝗔𝗻𝗱 𝗠𝗼𝗯𝗶𝗹𝗲 𝗟𝗲𝗴𝗲𝗻𝗱 "
ui_print " 2. 𝗔𝘀𝗽𝗵𝗮𝗹𝘁, 𝗖𝗢𝗗 𝗠𝗼𝗯𝗶𝗹𝗲 𝗔𝗻𝗱 𝗕𝗹𝗮𝗰𝗸𝗗𝗲𝘀𝗲𝗿𝘁 𝗠𝗼𝗯𝗶𝗹𝗲 "
ui_print " 3. 𝗠𝗼𝗯𝗶𝗹𝗲 𝗟𝗲𝗴𝗲𝗻𝗱𝘀 𝗔𝗻𝗱 𝗟𝗲𝗮𝗴𝘂𝗲 𝗢𝗳 𝗟𝗲𝗴𝗲𝗻𝗱𝘀 "
ui_print " 4. 𝗔𝗿𝗲𝗻𝗮 𝗢𝗳 𝗩𝗮𝗹𝗼𝗿 - 𝗠𝗮𝘅 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 "
ui_print " 5. 𝗖𝗢𝗗 𝗠𝗼𝗯𝗶𝗹𝗲 - 120 𝗙𝗣𝗦 "
ui_print " 6. 𝗙𝗼𝗿𝘁𝗻𝗶𝘁𝗲 "
ui_print " 7. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗨𝗻𝗹𝗼𝗰𝗸𝗲𝗿"
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻 : "
GU=1
while true; do
	ui_print "  $GU"
	if $VKSEL; then
		GU=$((GU + 1))
	else 
		break
	fi
	if [ $GU -gt 7 ]; then
		GU=1
	fi
done
#
case $GU in
1 ) DNReborn="✓𝗣𝗨𝗕𝗚 𝗠𝗼𝗯𝗶𝗹𝗲 𝗔𝗻𝗱 𝗠𝗼𝗯𝗶𝗹𝗲 𝗟𝗲𝗴𝗲𝗻𝗱 "; sed -i '/ro.product.model/s/.*/ro.product.model=ASUS_I003DD/' $props; sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=Asus/' $props;;
2 ) DNReborn="✓𝗔𝘀𝗽𝗵𝗮𝗹𝘁, 𝗖𝗢𝗗 𝗠𝗼𝗯𝗶𝗹𝗲 𝗔𝗻𝗱 𝗕𝗗 𝗠𝗼𝗯𝗶𝗹𝗲 "; sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' $props; sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=Samsung/' $props;;
3 ) DNReborn="✓𝗠𝗼𝗯𝗶𝗹𝗲 𝗟𝗲𝗴𝗲𝗻𝗱𝘀 𝗔𝗻𝗱 𝗟𝗲𝗮𝗴𝘂𝗲 𝗢𝗳 𝗟𝗲𝗴𝗲𝗻𝗱𝘀 "; sed -i '/ro.product.model/s/.*/ro.product.model=A2218/' $props; sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=Apple/' $props;;
4 ) DNReborn="✓𝗔𝗿𝗲𝗻𝗮 𝗢𝗳 𝗩𝗮𝗹𝗼𝗿 "; sed -i '/ro.product.model/s/.*/ro.product.model=R11 Plus/' $props; sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=Oppo/' $props;;
5 ) DNReborn="✓𝗖𝗮𝗹𝗹 𝗢𝗳 𝗗𝘂𝘁𝘆 𝗠𝗼𝗯𝗶𝗹𝗲 120 𝗙𝗽𝘀 "; sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' $props; sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=Sony Mobile Communications/' $props;;
6 ) DNReborn="✓𝗙𝗼𝗿𝘁𝗻𝗶𝘁𝗲 "; chmod 0777 $SET; magiskhide enable; magiskhide add com.epicgames.fortnite; settings put global adb_enabled 0; mv /data/media/0/TWRP /data/media/0/PRWT; mv /data/media/0/Download/magisk_patched.img /data/media/0/Download/ksigam_dehctap.img; am force-stop com.epicgames.fortnite; sed -i -e 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' $SET; sed -i -e 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g'  $SET; sed -i -e 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g'  $SET; sed -i -e 's/MobileFPSMode=Mode_60Fps/MobileFPSMode=Mode_60Fps/g'  $SET; sed -i -e 's/MobileFPSMode=Mode_120Fps/MobileFPSMode=Mode_60Fps/g'  $SET;;
7 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗨𝗻𝗹𝗼𝗰𝗸𝗲𝗿";;
esac
ui_print " $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅳🅽🅿🆁🅾🅿 🅼🅾🅳🅴 "
ui_print " •𝗙𝗮𝘀𝘁𝗲𝗿 𝗢𝗽𝗲𝗻 𝗔𝗽𝗽𝘀 , 𝗖𝘂𝘀𝘁𝗼𝗺 𝗗𝗼𝘇𝗲 "
ui_print " •𝗦𝗺𝗼𝗼𝘁𝗵𝗹𝘆 𝗗𝗶𝘀𝗽𝗹𝗮𝘆 , 𝗥𝗮𝗺 𝗠𝗮𝗻𝗮𝗴𝗲𝗺𝗲𝗻𝘁 "
ui_print " •𝗖𝗼𝗼𝗹𝗶𝗻𝗴 𝗦𝘆𝘀𝘁𝗲𝗺 , 𝗚𝗿𝗮𝗽𝗶𝗰𝗵 𝗢𝗽𝘁𝗶𝗺𝗶𝘇𝗲𝗱 "
ui_print " •𝗚𝗽𝘂 𝗢𝗽𝘁𝗶𝗺𝗶𝘇𝗲𝗱 , 𝗘𝗻𝗴𝗴𝗶𝗻𝗲𝗿 𝗧𝘄𝗲𝗮𝗸𝘀 "
ui_print " •𝗤𝘂𝗶𝗰𝗸 𝗕𝗼𝗼𝘁𝗶𝗻𝗴 , 𝗙𝗣𝗦 𝗦𝘁𝗮𝗯𝗶𝗹𝗶𝘇𝗲𝗿 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗡𝗣𝗥𝗢𝗣 𝗠𝗼𝗱𝗲 "
ui_print " 2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗗𝗡𝗣𝗥𝗢𝗣 𝗠𝗼𝗱𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
DP=1
while true; do
	ui_print "  $DP"
	if $VKSEL; then
		DP=$((DP + 1))
	else 
		break
	fi
	if [ $DP -gt 2 ]; then
		DP=1
	fi
done
case $DP in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗡𝗣𝗥𝗢𝗣 𝗠𝗼𝗱𝗲 "; cp -af $DNMODS/prop/* $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗗𝗡𝗣𝗥𝗢𝗣 𝗠𝗼𝗱𝗲 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅳🅽🆃🆆🅴🅰🅺🆂 🅼🅾🅳🅴 "
ui_print " •𝗦𝗱𝗖𝗮𝗿𝗱 𝗧𝘄𝗲𝗮𝗸𝘀 , 𝗞𝗲𝗿𝗻𝗲𝗹 𝗧𝘄𝗲𝗮𝗸𝘀 "
ui_print " •𝗩𝗠 𝗧𝘄𝗲𝗮𝗸 , 𝗟𝗼𝘄 𝗠𝗲𝗺𝗼𝗿𝘆 𝗞𝗶𝗹𝗹𝗲𝗿 "
ui_print " •𝗔𝗻𝗶𝗺𝗮𝘁𝗶𝗼𝗻 𝗦𝗰𝗮𝗹𝗲 , 𝗖𝗹𝗮𝗺𝗽 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 "
ui_print " •𝗪𝗮𝗸𝗲𝗹𝗼𝗰𝗸 𝗕𝗹𝗼𝗰𝗸𝗲𝗿 , 𝗗𝗧2𝗪 𝗙𝗶𝘅 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗡𝗧𝗪𝗘𝗔𝗞𝗦 𝗠𝗼𝗱𝗲 "
ui_print " 2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗗𝗡𝗧𝗪𝗘𝗔𝗞𝗦 𝗠𝗼𝗱𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
DT=1
while true; do
	ui_print "  $DT"
	if $VKSEL; then
		DT=$((DT + 1))
	else 
		break
	fi
	if [ $DT -gt 2 ]; then
		DT=1
	fi
done
case $DT in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗡𝗧𝗪𝗘𝗔𝗞𝗦 𝗠𝗼𝗱𝗲 "; cp -af $DNMODS/tweak/* $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗗𝗡𝗧𝗪𝗘𝗔𝗞𝗦 𝗠𝗼𝗱𝗲 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🆉🆁🅰🅼 🅼🅾🅳🅴 "
ui_print " 1.  0 𝗚𝗕 (𝗡𝗼𝘁 𝗨𝘀𝗲 𝗭𝗿𝗮𝗺) "
ui_print " 2.  1 𝗚𝗕 "
ui_print " 3.  2 𝗚𝗕 "
ui_print " 4.  3 𝗚𝗕 "
ui_print " 5.  4 𝗚𝗕 "
ui_print " 6.  6 𝗚𝗕 "
ui_print " 7. 𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 (𝗥𝗲𝗰𝗼𝗺𝗲𝗻𝗱𝗲𝗱) "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
ZR=1
while true; do
ui_print "  $ZR"
	if $VKSEL; then
		ZR=$((ZR + 1))
	else 
		break
	fi
	if [ $ZR -gt 7 ]; then
		ZR=1
	fi
done
case $ZR in
1 ) DNReborn="✓0 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=0" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
2 ) DNReborn="✓1 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=1024MB" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
3 ) DNReborn="✓2 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=2048MB" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
4 ) DNReborn="✓3 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=3072MB" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
5 ) DNReborn="✓4 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=4096MB" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
6 ) DNReborn="✓6 𝗚𝗕 𝗭𝗿𝗮𝗺 "; echo "zramsize=6144MB" >> $ZRAM;
     echo "
     " >> $ZRAM; echo "zram" >> $ZRAM;;
7 ) DNReborn="✓𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 𝗭𝗿𝗮𝗺 ";;
 esac
ui_print " $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅿🅴🆁🅵🅾🆁🅼🅰🅽🅲🅴 🅼🅾🅳🅴 "
ui_print " ⚠️𝗥𝗲𝗰𝗼𝗺𝗲𝗻𝗱𝗮𝘁𝗶𝗼𝗻 𝗨𝘀𝗲 𝗢𝗖 𝗞𝗲𝗿𝗻𝗲𝗹⚠️"
ui_print " •𝗘𝗮𝘀=𝗦𝗰𝗵𝗲𝗱𝘂𝘁𝗶𝗹 "
ui_print " •𝗛𝗺𝗽=𝗜𝗻𝘁𝗲𝗿𝗮𝗰𝘁𝗶𝘃𝗲 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗕𝗮𝘀𝗶𝗰 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 "
ui_print " 2. 𝗫𝘁𝗿𝗮 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 "
ui_print " 3. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
PT=1
while true; do
	ui_print "  $PT"
	if $VKSEL; then
		PT=$((PT + 1))
	else 
		break
	fi
	if [ $PT -gt 3 ]; then
		PT=1
	fi
done
case $PT in
1 ) DNReborn="✓𝗕𝗮𝘀𝗶𝗰 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 "; cp -af $DNMODS/perf/* $MODPATH/config/;;
2 ) DNReborn="✓𝗫𝘁𝗿𝗮 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 "; cp -af $DNMODS/perf2/* $MODPATH/config/;;
3 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗧𝘄𝗲𝗮𝗸𝘀 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🆃🅷🅴🆁🅼🅰🅻 🅼🅾🅳 "
ui_print "⚠️𝗧𝗵𝗶𝘀 𝗖𝗮𝗻 𝗠𝗮𝗸𝗲 𝗬𝗼𝘂𝗿 𝗗𝗲𝘃𝗶𝗰𝗲 𝗢𝘃𝗲𝗿𝗵𝗲𝗮𝘁⚠️"
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗠𝗼𝗱 "
ui_print " 2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗠𝗼𝗱 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
TM=1
while true; do
	ui_print "  $TM"
	if $VKSEL; then
		TM=$((TM + 1))
	else 
		break
	fi
	if [ $TM -gt 2 ]; then
		TM=1
	fi
done
case $TM in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗠𝗼𝗱 "; cp -af $THERMAL/system/etc/init/* $MODPATH/system/etc/init; cp -af $THERMAL/system/lib/* $MODPATH/system/lib; cp -af $THERMAL/system/lib64/* $MODPATH/system/lib64; cp -af $THERMAL/system/vendor/etc/* $MODPATH/system/vendor/etc; $THERMAL/system/vendor/bin/* $MODPATH/system/vendor/bin; $THERMAL/system/vendor/lib/* $MODPATH/system/vendor/lib $THERMAL/system/vendor/lib64/* $MODPATH/system/vendor/lib64; cp -af $THERMAL/therlog $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗠𝗼𝗱 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🆃🅾🆄🅲🅷 🅸🅼🅿🆁🅾🆅🅴🅼🅴🅽🆃 "
ui_print " •𝗙𝗮𝘀𝘁𝗲𝗿 𝗦𝗰𝗿𝗼𝗹𝗹𝗶𝗻𝗴 "
ui_print " •𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗶𝘃𝗲 𝗧𝗼𝘂𝗰𝗵 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗧𝗼𝘂𝗰𝗵 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗺𝗲𝗻𝘁 "
ui_print " 2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗧𝗼𝘂𝗰𝗵 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗺𝗲𝗻𝘁 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
TI=1
while true; do
	ui_print "  $TI"
	if $VKSEL; then
		TI=$((TI + 1))
	else 
		break
	fi
	if [ $TI -gt 2 ]; then
		TI=1
	fi
done
case $TI in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗧𝗼𝘂𝗰𝗵 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗺𝗲𝗻𝘁 "; cp -af $DNMODS/touch/* $MODPATH/config/; cp -af $MSUS/Mod/boost/com.qualcomm.qti.improvetouch.service.apk $MODPATH/system/vendor/app/com.qualcomm.qti.improvetouch.service; cp -af $MSUS/Mod/boost/libIT7260-jni.so $MODPATH/system/lib;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗧𝗼𝘂𝗰𝗵 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗺𝗲𝗻𝘁 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅵🅾🆁🅲🅴 🅳🅰🆁🅺 🅼🅾🅳🅴 "
ui_print " •𝗗𝗮𝗿𝗸 𝗗𝗶𝘀𝗽𝗹𝗮𝘆 "
ui_print " •𝗗𝗮𝗿𝗸 𝗞𝗲𝘆𝗯𝗼𝗮𝗿𝗱 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print "   1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗮𝗿𝗸 𝗠𝗼𝗱𝗲 "
ui_print "   2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗗𝗮𝗿𝗸 𝗠𝗼𝗱𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
DM=1
while true; do
	ui_print "  $DM"
	if $VKSEL; then
		DM=$((DM + 1))
	else 
		break
	fi
	if [ $DM -gt 2 ]; then
		DM=1
	fi
done
case $DM in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗗𝗮𝗿𝗸 𝗠𝗼𝗱𝗲 "; sed -i '/debug.hwui.force_dark/s/.*/debug.hwui.force_dark=true/' $props;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗗𝗮𝗿𝗸 𝗠𝗼𝗱𝗲 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅶🅼🆂 🅳🅾🆉🅴 "
ui_print "  ⚠️ 𝗕𝗮𝘁𝘁𝗲𝗿𝘆 𝗦𝗮𝘃𝗲⚠️ "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print " 1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗚𝗺𝘀 𝗗𝗼𝘇𝗲 "
ui_print " 2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗚𝗺𝘀 𝗗𝗼𝘇𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
GD=1
while true; do
	ui_print "  $GD"
	if $VKSEL; then
		GD=$((GD + 1))
	else 
		break
	fi
	if [ $GD -gt 2 ]; then
		GD=1
	fi
done
case $GD in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗚𝗺𝘀 𝗗𝗼𝘇𝗲 "; cp -af $DNMODS/gms/* $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗚𝗺𝘀 𝗗𝗼𝘇𝗲";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅶🅿🆄 🆁🅴🅽🅳🅴🆁🅴🆁 "
ui_print "  1. 𝗢𝗽𝗲𝗻𝗚𝗟 "
ui_print "  2. 𝗦𝗸𝗶𝗮𝗚𝗟 "
ui_print "  3. 𝗩𝘂𝗹𝗸𝗮𝗻𝗦𝗸𝗶𝗮 "
ui_print "  4. 𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 (𝗥𝗲𝗰𝗼𝗺𝗲𝗻𝗱𝗲𝗱) "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
GR=1
while true; do
ui_print "  $GR"
	if $VKSEL; then
		GR=$((GR + 1))
	else 
		break
	fi
	if [ $GR -gt 4 ]; then
		GR=1
	fi
done
case $GR in
1 ) DNReborn="✓𝗢𝗽𝗲𝗻𝗚𝗟 "; sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=opengl/' $props;;
2 ) DNReborn="✓𝗦𝗸𝗶𝗮𝗚𝗟 "; sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiagl/' $props;;
3 ) DNReborn="✓𝗩𝘂𝗹𝗸𝗮𝗻𝗦𝗸𝗶𝗮 "; sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiavk/' $props;;
4 ) DNReborn="✓𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅾🅿🅴🅽🅶🅻 🆅🅴🆁🆂🅸🅾🅽 "
ui_print " 1. 𝗚𝗟 𝗘𝗦 1.1 𝗖𝗠 "
ui_print " 2. 𝗚𝗟 𝗘𝗦 3.2 "
ui_print " 3. 𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 (𝗥𝗲𝗰𝗼𝗺𝗲𝗻𝗱𝗲𝗱) "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
ES=1
while true; do
ui_print "  $ES"
	if $VKSEL; then
		ES=$((ES + 1))
	else 
		break
	fi
	if [ $ES -gt 3 ]; then
		ES=1
	fi
done
case $ES in
1 ) DNReborn="✓𝗚𝗟 𝗘𝗦 1.1 𝗖𝗠 "; sed -i '/ro.opengles.version/s/.*/ro.opengles.version=65535/' $props;;
2 ) DNReborn="✓𝗚𝗟 𝗘𝗦 3.2 "; sed -i '/ro.opengles.version/s/.*/ro.opengles.version=196610/' $props;;
3 ) DNReborn="✓𝗨𝘀𝗲 𝗗𝗲𝗳𝗮𝘂𝗹𝘁 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅽🅴🆃🆆🅾🆁🅺 🆂🅿🅴🅴🅳 🅼🅾🅳🅴 "
ui_print " •𝗧𝗖𝗣 𝗕𝘂𝗳𝗳𝗲𝗿𝗦𝗶𝘇𝗲 , 𝗧𝗖𝗣 𝗕𝗼𝗼𝘀𝘁 "
ui_print " •𝗜𝗣𝗩4 𝗕𝗼𝗼𝘀𝘁 , 𝗜𝗣𝗩6 𝗕𝗼𝗼𝘀𝘁 "
ui_print " •𝗪𝗶𝗳𝗶 𝗕𝗼𝗼𝘀𝘁 , 𝗡𝗲𝘁𝗖𝗼𝗿𝗲 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 2
ui_print "  1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗡𝗲𝘁𝘄𝗼𝗿𝗸 𝗦𝗽𝗲𝗲𝗱 𝗠𝗼𝗱𝗲  "
ui_print "  2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗡𝗲𝘁𝘄𝗼𝗿𝗸 𝗦𝗽𝗲𝗲𝗱 𝗠𝗼𝗱𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
NM=1
while true; do
ui_print "  $NM"
	if $VKSEL; then
		NM=$((NM + 1))
	else 
		break
	fi
	if [ $NM -gt 2 ]; then
		NM=1
	fi
done
case $NM in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗡𝗲𝘁𝘄𝗼𝗿𝗸 𝗦𝗽𝗲𝗲𝗱 𝗠𝗼𝗱𝗲 "; cp -af $DNMODS/net/* $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗡𝗲𝘁𝘄𝗼𝗿𝗸 𝗦𝗽𝗲𝗲𝗱 𝗠𝗼𝗱𝗲 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   🅳🅽🆂 🅾🅿🆃🅸🅾🅽 "
ui_print "  1. 𝗚𝗼𝗼𝗴𝗹𝗲 𝗗𝗡𝗦 "
ui_print "  2. 𝗖𝗹𝗼𝘂𝗱𝗙𝗹𝗮𝗿𝗲 𝗗𝗡𝗦 "
ui_print "  3. 𝗤𝘂𝗮𝗱 9 𝗗𝗡𝗦 "
ui_print "  4. 𝗔𝗱𝗯𝗹𝗼𝗰𝗸 𝗗𝗡𝗦 "
ui_print "  5. 𝗡𝗼𝗿𝘁𝗼𝗻 𝗗𝗡𝗦 "
ui_print "  6. 𝗢𝗽𝗲𝗻 𝗗𝗡𝗦 "
ui_print "  7. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗗𝗻𝘀 "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print " "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
NW=1
while true; do
ui_print "  $NW"
	if $VKSEL; then
		NW=$((NW + 1))
	else 
		break
	fi
	if [ $NW -gt 7 ]; then
		NW=1
	fi
done
case $NW in
1 ) DNReborn="✓𝗚𝗼𝗼𝗴𝗹𝗲 𝗗𝗡𝗦 "; cp -af $DNS/google/* $MODPATH/config/;;
2 ) DNReborn="✓𝗖𝗹𝗼𝘂𝗱𝗙𝗹𝗮𝗿𝗲 𝗗𝗡𝗦 "; cp -af $DNS/cloudflare/* $MODPATH/config/;;   
3 ) DNReborn="✓𝗤𝘂𝗮𝗱 9 𝗗𝗡𝗦 "; cp -af $DNS/quad9/* $MODPATH/config/;;
4 ) DNReborn="✓𝗔𝗱𝗯𝗹𝗼𝗰𝗸 𝗗𝗡𝗦 "; cp -af $DNS/adblock/* $MODPATH/config/;;
5 ) DNReborn="✓𝗡𝗼𝗿𝘁𝗼𝗻 𝗗𝗡𝗦 "; cp -af $DNS/norton/* $MODPATH/config/;;
6 ) DNReborn="✓𝗢𝗽𝗲𝗻 𝗗𝗡𝗦 "; cp -af $DNS/open/* $MODPATH/config/;;
7 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗗𝗡𝗦 ";;
 esac
ui_print " $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "  🅵🅰🆂🆃 🅲🅷🅰🆁🅶🅸🅽🅶 🅼🅾🅳🅴 "
ui_print " ⚠️𝗡𝗲𝗲𝗱 𝗞𝗲𝗿𝗻𝗲𝗹 𝗦𝘂𝗽𝗽𝗼𝗿𝘁⚠️ "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 1
ui_print "  1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗙𝗮𝘀𝘁 𝗖𝗵𝗮𝗿𝗴𝗶𝗻𝗴 𝗠𝗼𝗱𝗲 "
ui_print "  2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗙𝗮𝘀𝘁 𝗖𝗵𝗮𝗿𝗴𝗶𝗻𝗴 𝗠𝗼𝗱𝗲 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
FM=1
while true; do
ui_print "  $FM"
	if $VKSEL; then
		FM=$((FM + 1))
	else 
		break
	fi
	if [ $FM -gt 2 ]; then
		FM=1
	fi
done
case $FM in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗙𝗮𝘀𝘁 𝗖𝗵𝗮𝗿𝗴𝗶𝗻𝗴 𝗠𝗼𝗱𝗲 "; cp -af $DNMODS/char $MODPATH/config/;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗙𝗮𝘀𝘁 𝗖𝗵𝗮𝗿𝗴𝗶𝗻𝗴 𝗠𝗼𝗱𝗲 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "     🅰🅳🆂 🅱🅻🅾🅲🅺🅴🆁 "
ui_print "  ⚠️𝗥𝗲𝗺𝗼𝘃𝗲 𝗔𝗱𝘀 𝗢𝗻 𝗬𝗼𝘂𝗿 𝗗𝗲𝘃𝗶𝗰𝗲⚠️ "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 1
ui_print "  1. 𝗘𝗻𝗮𝗯𝗹𝗲 𝗔𝗱𝘀 𝗕𝗹𝗼𝗰𝗸𝗲𝗿 "
ui_print "  2. 𝗗𝗼𝗻'𝘁 𝗨𝘀𝗲 𝗔𝗱𝘀 𝗕𝗹𝗼𝗰𝗸𝗲𝗿 "
ui_print "   "
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸 𝗢𝗽𝘁𝗶𝗼𝗻: "
AB=1
while true; do
	ui_print "  $AB"
	if $VKSEL; then
		AB=$((AB + 1))
	else 
		break
	fi
	if [ $AB -gt 2 ]; then
		AB=1
	fi
done
case $AB in
1 ) DNReborn="✓𝗘𝗻𝗮𝗯𝗹𝗲 𝗔𝗱𝘀 𝗕𝗹𝗼𝗰𝗸𝗲𝗿 "; cp -af $MSUS/adsr/* $MODPATH/system/etc;;
2 ) DNReborn="⛔𝗡𝗼𝘁 𝗨𝘀𝗲 𝗔𝗱𝘀 𝗕𝗹𝗼𝗰𝗸𝗲𝗿 ";;
esac
ui_print "  $DNReborn "

sleep 1
ui_print "𝗧𝘄𝗲𝗮𝗸𝘀 𝗜𝗻𝘀𝘁𝗮𝗹𝗹𝗶𝗻𝗴 𝗣𝗿𝗼𝘀𝗲𝘀,𝗪𝗮𝗶𝘁"
sleep 5
ui_print " ⚠️𝗥𝗲𝘃𝗶𝗲𝘄 𝗔𝗻𝗱 𝗥𝗲𝗽𝗼𝗿𝘁 𝗧𝗼 𝗠𝗲⚠️ "
sleep 2
ui_print " [𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - @𝗱𝘄𝗶𝗸𝗮𝗻𝘂𝗴𝗿𝗮𝗵𝗮] "
sleep 1
 ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
 ui_print "       🙏𝗕𝗶𝗴 𝗧𝗵𝗮𝗻𝗸𝘀 & 𝗖𝗿𝗲𝗱𝗶𝘁🙏 "
 ui_print "       -𝗞𝗲𝘃𝗶𝗻 "
 ui_print "       -𝗪𝗲𝗔𝗿𝗲𝗥𝗮𝘃𝗲𝗻𝘀 "
 ui_print "       -𝗔𝗸𝗶𝗿𝗮_𝗩𝗶𝘀𝗵𝗮𝗹 "
 ui_print "       -𝗦𝗶𝗿_𝗔𝗻𝗰𝗵𝗲𝘁𝗮 "
 ui_print "       -𝗗𝗮𝘃𝗲𝗠𝗮𝗿𝘃𝗲𝘆 "
 ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 3
}

ui_print "- Cleaning Old Modules"
sleep 2
rm -rf \
$MODPATH/README.md \
$MODPATH/*.tar.xz \
$MODPATH/addon \

set_permissions() {

[ -f "$MODPATH/tar.tar.xz" ] && tar -xf $MODPATH/tar.tar.xz -C $MODPATH;
cp -af $DNMODS/tc/* $MODPATH/config
cp -af $DNMODS/bin/* $MODPATH/system/bin

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/config 0 0 0755 0755
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
}

system_prop() {
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  sed -n "$REGEX" $FILES 2>/dev/null | head -n 1
}

# load vendor property file
vendor_prop() {
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/vendor/build.prop'
  sed -n "$REGEX" $FILES 2>/dev/null | head -n 1
}