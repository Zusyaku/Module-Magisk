## Compatibility
```
Device   | Redmi Note4X
ARCH     | arm64
Board    | msm8953
ROM      | LOS/AOSP/MIUI


## Instruction
```
- Install Magisk Module
- Reboot
- Done
```

##PowerSpeed BY @dwikanugraha
```