# This script will be executed in late_start service mode
# More info in the main Magisk thread
stop logd
stop thermald

# Set Sched To HMP
echo Switching Kernel Mode To HMP
echo 0 > /sys/devices/system/cpu/eas/enable
echo Done
echo

# Game Touch Sampling
echo Enabling Game Touch Sampling Rate
echo 1 > /proc/touchpanel/game_switch_enable
echo Done
echo

# Disable CABC For Oppo / Realme Devices
echo Disable CABC Mode For Best Experience
echo 0 > /sys/kernel/oppo_display/cabc
echo Done
echo

# Power HAL Sport Mode
echo Add Some Games To Sport Mode
echo -e "com.mobile.legends\ncom.tencent.ig\ncom.miHoYo.GenshinImpact\ncom.tencent.tmgp.pubgmhd\ncom.dts.freefireth\ncom.dts.freefiremax\njp.konami.pesam\ncom.pubg.newstate\ncom.garena.game.codm\ncom.pubg.imobile\ncom.ea.gp.apexlegendsmobilefps\ncom.riotgames.league.wildrift\ncom.instagram.android\ncom.vng.pubgmobile\ncom.pubg.krmobile\ncom.rekoo.pubgm\ncom.roblox.client\ncom.google.android.youtube\ncom.GlobalSoFunny.Sausage\nskynet.cputhrottlingtest\ncom.neptune.domino\n" > /data/vendor/powerhal/smart

# SD Card Speed Tweaks
echo "2048" > /sys/devices/virtual/bdi/179:0/read_ahead_kb( For Class 4 And Above )
echo "512" > /sys/devices/virtual/bdi/179:0/read_ahead_kb ( For Class 3 And Lower )

echo This Script Was Made By In Collaboration Of @Zevux And @levv20
echo Last updated : 00:00 A.M. 01/01/2022
echo exit
