#!/sbin/sh

mount -o remount,rw /system
mount -t rootfs -o remount,rw rootfs
mount -o remount,rw /

mount /data 


rm -rf /data/adb/modules 
rm -rf /sbin/.magisk/modules 
rm -rf /system/app/YouTube/.replace

umount /system 


mkdir /mktmp
mount -o loop /data/adb/magisk /mktmp

cd /mktmp 

rm -rf Detach
rm -rf YouTube-Vanced-Black
rm -rf YouTube-Vanced-Dark
rm -rf YouTube-Vanced
rm -rf YouTube-Vanced-Detach
rm -rf /system/app/YouTube/.replace


umount /mktmp


