##########################################################################################
# AUROX - THERMAL
# VERSION = v2.6 | STABLE
# DATE = 20-09-2020
##########################################################################################

*NOTE: If you are using MIUI ROM please disable MIUI optimization and MIUI memory optimization because it resets most of these settings. If you use any app that tweaks settings above please uninstall or at least disable them to run and ruin the module's settings.*
