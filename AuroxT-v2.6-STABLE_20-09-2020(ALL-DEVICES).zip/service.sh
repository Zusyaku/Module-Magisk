##########################################################################################
# AUROX - THERMAL
# VERSION = v2.6 | STABLE
# DATE = 20-09-2020
##########################################################################################
#!/system/bin/sh


# Wait for boot to be completed
while [ ! "$(getprop ro.board.platform)" == "1" ! "$(getprop sys.io.scheduler)" == "noop" ! "$(getprop sys.post_boot.parsed)" == "1" ! "$(getprop persist.vendor.spectrum.profile)" == "0" ! "$(getprop sys.boot_completed)" == "1" ! "$(getprop vendor.post_boot.parsed)" == "1" ]; do
 sleep 1
done
sleep 60

# Remove LOG Android Tweaks Set Config
rm -rf /data/cache
rm -rf /data/log
rm -rf /data/system/dropbox
rm -rf /data/system/graphicsstats
rm -rf /data/system/heapdump
rm -rf /data/system/install_sessions
rm -rf /data/system/package_cache
rm -rf /data/system/perfd/default_values
rm -rf /data/system/stats_companion
rm -rf /data/system/usagestats
rm -rf /data/system/cachequota.xml
rm -rf /data/tombstones
rm -rf /proc/sys/vm/drop_caches

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.android.emergency'
sleep '0.001'
su -c 'pm enable com.android.stk'
sleep '0.001'
su -c 'pm enable com.google.android.as'
sleep '0.001'
su -c 'pm enable com.google.android.googlequicksearchbox'
sleep '0.001'
su -c 'pm enable com.google.android.apps.turbo'
sleep '0.001'
su -c 'pm enable com.google.android.apps.wellbeing'
sleep '0.001'
su -c 'pm enable com.google.android.apps.work.oobconfig'
sleep '0.001'
su -c 'pm enable com.google.android.tts'
sleep '0.001'
su -c 'pm enable android.ext.services'
sleep '0.001'
su -c 'pm enable com.mgoogle.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.calendar'
sleep '0.001'
su -c 'pm enable com.google.android.gm'
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.play.games'
sleep '0.001'
su -c 'pm enable com.google.android.webview'
sleep '0.001'
su -c 'pm enable com.qualcomm.qcrilmsgtunnel'
sleep '0.001'
su -c 'pm enable com.google.android.apps.pixelmigrate'
sleep '0.001'
su -c 'pm enable com.google.android.apps.maps'
sleep '0.001'
su -c 'pm enable com.google.android.trichromelibrary'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.gms.analytics.AnalyticsService'
sleep '0.001'
su -c 'pm disable com.google.android.gms.analytics.CampaignTrackingService'
sleep '0.001'
su -c 'pm disable com.google.android.gms.measurement.AppMeasurementService'
sleep '0.001'
su -c 'pm disable com.google.android.gms.analytics.AnalyticsReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.gms.analytics.CampaignTrackingReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.gms.measurement.AppMeasurementReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.gms.measurement.AppMeasurementContentProvider'

# Dt2W Fixed Tweaks Set Config
cat /sys/touchpanel/double_tap;
echo '0' > /sys/touchpanel/double_tap;
sleep 3s
cat /sys/touchpanel/double_tap;
echo '1' > /sys/touchpanel/double_tap;

# Disable Thermal HotPlug Tweaks Set Config
echo '0' > /sys/module/msm_thermal/core_control/cpus_offlined;
echo '0' > /sys/module/msm_thermal/core_control/enabled;

# Enable MSM Thermal Driver Tweaks Set Config
echo 'N' > /sys/module/msm_thermal/parameters/enabled;

# Enable Fast Charging Rate Tweaks Set Config
echo '1' > /sys/kernel/fast_charge/force_fast_charge;

# KCAL Tweaks Set Config
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable;
echo 'platform:kcal_ctrl' > /sys/devices/platform/kcal_ctrl.0/modalias;

# Fast Charging Tweaks Set Config
echo '2000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma;
echo '1800' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma;
echo '2400' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma;
echo '1800' > /sys/module/dwc3_msm/parameters/hvdcp_max_current;
echo '2000' > /sys/module/dwc3_msm/parameters/dcp_max_current;
echo '2000' > /sys/module/phy_msm_usb/parameters/dcp_max_current;
echo '1800' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current;
echo '1200000' > /sys/module/qpnp_smb2/parameters/weak_chg_icl_ua;

# Quick Charge 3.0 Specific settings
# Battery Maximum charging current, just a initial value
echo '140' > /sys/class/power_supply/bms/temp_cold;
echo '140' > /sys/class/power_supply/bms/temp_cool;
echo '460' > /sys/class/power_supply/bms/temp_hot;
echo '460' > /sys/class/power_supply/bms/temp_warm;
echo '3200000' > /sys/class/power_supply/usb/current_max;
echo '3200000' > /sys/class/power_supply/usb/hw_current_max;
echo '3200000' > /sys/class/power_supply/usb/pd_current_max;
echo '3200000' > /sys/class/power_supply/usb/ctm_current_max;
echo '3200000' > /sys/class/power_supply/usb/sdp_current_max;
echo '3200000' > /sys/class/power_supply/main/current_max;
echo '3200000' > /sys/class/power_supply/main/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/battery/current_max;
echo '3200000' > /sys/class/power_supply/battery/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/pc_port/current_max;
echo '3200000' > /sys/class/power_supply/constant_charge_current_max;
echo '4400000' > /sys/class/qcom-battery/restricted_current;

# CPU Governor Schedutil Tweaks Set Config
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor;

# CPU I/O Scheduler NOOP Tweaks Set Config
cat /sys/block/dm-0/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/dm-0/queue/scheduler;
cat /sys/block/dm-0/queue/scheduler;
echo 'noop' > /sys/block/dm-0/queue/scheduler;
cat /sys/block/mmcblk0/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/mmcblk0/queue/scheduler;
cat /sys/block/mmcblk0/queue/scheduler;
echo 'noop' > /sys/block/mmcblk0/queue/scheduler;
cat /sys/block/mmcblk0rpmb/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/mmcblk0rpmb/queue/scheduler;
cat /sys/block/mmcblk0rpmb/queue/scheduler;
echo 'noop' > /sys/block/mmcblk0rpmb/queue/scheduler;

# GPU Booster Tweaks Set Config
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus;
restorecon -R /dev/cpuset/foreground/cpus;
cat /dev/cpuset/foreground/effective_cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/effective_cpus;
restorecon -R /dev/cpuset/foreground/effective_cpus;
echo '0-7' > /dev/cpuset/top-app/cpus;
echo '0-7' > /dev/cpuset/top-app/effective_cpus;

# Perf HAL Tweaks Set Config
cat /proc/sys/kernel/perf_cpu_time_max_percent;
echo '5' > /proc/sys/kernel/perf_cpu_time_max_percent;
cat /proc/sys/kernel/sched_boost;
echo '1' > /proc/sys/kernel/sched_boost;
cat /proc/sys/kernel/timer_migration;
echo '0' > /proc/sys/kernel/timer_migration;

# Entropy Tweaks Set Config
echo '64' > /proc/sys/kernel/random/read_wakeup_threshold;
echo '896' > /proc/sys/kernel/random/write_wakeup_threshold;

# Battery Saver Tweaks Set Config
echo '500' > /proc/sys/vm/dirty_expire_centisecs;
echo '500' > /proc/sys/vm/dirty_writeback_centisecs;

# VM Kernel Manage.ment Tweaks Set Config
echo '0' > /proc/sys/vm/extra_free_kbytes;
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_dump_tasks;
echo '0' > /proc/sys/vm/overcommit_memory;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '1' > /proc/sys/vm/oom_kill_allocating_task;
cat /proc/sys/vm/drop_caches;
echo '3' > /proc/sys/vm/drop_caches;
echo '5' > /proc/sys/vm/stat_interval;
echo '50' > /proc/sys/vm/overcommit_ratio;
echo '80' > /proc/sys/vm/vfs_cache_pressure;
echo '60' > /proc/sys/vm/swappiness;
echo '70' > /proc/sys/vm/dirty_background_ratio;
echo '90' > /proc/sys/vm/dirty_ratio;
echo '4096' > /proc/sys/vm/mmap_min_addr;
echo '8192' > /proc/sys/vm/min_free_kbytes;

# Virtual RAM Memory Tweaks Set Config
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb;
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb;
echo '1024' > /sys/block/ram0/queue/read_ahead_kb;
echo '1024' > /sys/block/ram1/queue/read_ahead_kb;
echo '1024' > /sys/block/ram2/queue/read_ahead_kb;
echo '1024' > /sys/block/ram3/queue/read_ahead_kb;
echo '1024' > /sys/block/ram4/queue/read_ahead_kb;
echo '1024' > /sys/block/ram5/queue/read_ahead_kb;
echo '1024' > /sys/block/ram6/queue/read_ahead_kb;
echo '1024' > /sys/block/ram7/queue/read_ahead_kb;
echo '1024' > /sys/block/ram8/queue/read_ahead_kb;
echo '1024' > /sys/block/ram9/queue/read_ahead_kb;
echo '1024' > /sys/block/ram10/queue/read_ahead_kb;
echo '1024' > /sys/block/ram11/queue/read_ahead_kb;
echo '1024' > /sys/block/ram12/queue/read_ahead_kb;
echo '1024' > /sys/block/ram13/queue/read_ahead_kb;
echo '1024' > /sys/block/ram14/queue/read_ahead_kb;
echo '1024' > /sys/block/ram15/queue/read_ahead_kb;
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb;
cat /sys/block/zram0/max_comp_streams;
echo '6' > /sys/block/zram0/max_comp_streams;
cat /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
cat /sys/module/lowmemorykiller/parameters/adj;
echo '0,1,3,5,7,15' > /sys/module/lowmemorykiller/parameters/adj;
cat /sys/module/lowmemorykiller/parameters/adj_max_shift;
echo '500' > /sys/module/lowmemorykiller/parameters/adj_max_shift;
cat /sys/module/lowmemorykiller/parameters/lmk_fast_run;
echo '1' > /sys/module/lowmemorykiller/parameters/lmk_fast_run;
cat /sys/module/lowmemorykiller/parameters/cost;
echo '32' > /sys/module/lowmemorykiller/parameters/cost;
cat /sys/module/lowmemorykiller/parameters/minfree;
echo '3775,6144,9387,14336,17284,21240' > /sys/module/lowmemorykiller/parameters/minfree;

# CPU Boost Tweaks Set Config
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/iowait_boost_enable;
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us;

# TCP Congestion Control Tweaks Set Config
cat /proc/sys/net/core/default_qdisc;
echo 'fq_codel' > /proc/sys/net/core/default_qdisc;
restorecon -R /proc/sys/net/core/default_qdisc;
cat /proc/sys/net/ipv4/tcp_allowed_congestion_control;
echo 'bbr reno westwood' > /proc/sys/net/ipv4/tcp_allowed_congestion_control;
cat /proc/sys/net/ipv4/tcp_available_congestion_control;
echo 'bbr reno bic cdg cubic dctcp westwood hybla htcp vegas veno lp yeah illinois' > /proc/sys/net/ipv4/tcp_available_congestion_control;
cat /proc/sys/net/ipv4/tcp_congestion_control;
echo 'bbr' > /proc/sys/net/ipv4/tcp_congestion_control;

# Internet Speed Tweaks Set Config
echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '30' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '524288' > /proc/sys/net/core/wmem_max;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '524288' > /proc/sys/net/core/rmem_max;
echo '524288' > /proc/sys/net/core/rmem_default;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_rmem;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_wmem;
echo '4296 87380 404480' > /proc/sys/net/ipv4;
echo '524288 524288 524288' > /proc/sys/net/ipv4/tcp_mem;

sleep 5
done

# This script will be executed in late_start service mode
# More info in the main Magisk thread

