#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

# Set CF DNS servers address
setprop net.rmnet0.dns1 9.9.9.9
setprop net.rmnet0.dns2 149.112.112.112

setprop net.rmnet1.dns1 9.9.9.9
setprop net.rmnet1.dns2 149.112.112.112

setprop net.dns1 9.9.9.9
setprop net.dns2 149.112.112.112

setprop net.gprs.dns1 9.9.9.9
setprop net.gprs.dns2 149.112.112.112

setprop net.wcdma.dns1 9.9.9.9
setprop net.wcdma.dns2 149.112.112.112

setprop net.hspa.dns1 9.9.9.9
setprop net.hspa.dns2 149.112.112.112

setprop net.hsdpa.dns1 9.9.9.9
setprop net.hsdpa.dns2 149.112.112.112

setprop net.lte.dns1 9.9.9.9
setprop net.lte.dns2 149.112.112.112

setprop net.ltea.dns1 9.9.9.9
setprop net.ltea.dns2 149.112.112.112

setprop net.ppp0.dns1 9.9.9.9
setprop net.ppp0.dns2 149.112.112.112

setprop net.pdpbr1.dns1 9.9.9.9
setprop net.pdpbr1.dns2 149.112.112.112

setprop net.wlan0.dns1 9.9.9.9
setprop net.wlan0.dns2 149.112.112.112

setprop net.eth0.dns1 9.9.9.9
setprop net.eth0.dns2 149.112.112.112

setprop 2001:4860:4860::9999
setprop 2606:4700:4700::149112112112



# Edit the resolv conf file if it exist

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 9.9.9.9\nnameserver 149.112.112.112" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi
