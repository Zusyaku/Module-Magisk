#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

# Wait for boot to be completed
while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

# Apply settings
sleep 5s

# VM Management Tweaks Set Config
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /proc/sys/vm/swappiness;
echo '70' > /proc/sys/vm/dirty_background_ratio;
echo '90' > /proc/sys/vm/dirty_ratio;
echo '50' > /proc/sys/vm/vfs_cache_pressure;

# Virtual Memory Tweaks Set Config
stop perfd
echo '5' > /proc/sys/vm/swappiness;
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
echo '80' > /proc/sys/vm/vfs_cache_pressure;
echo '0' > /proc/sys/vm/extra_free_kbytes;
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb;
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb;
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo '4096' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '5' > /proc/sys/vm/dirty_ratio;
echo '20' > /proc/sys/vm/dirty_background_ratio;
sleep 30
chmod 666 /sys/module/lowmemorykiller/parameters/minfree;
chown root /sys/module/lowmemorykiller/parameters/minfree;
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree;
rm /data/system/perfd/default_values;
start perfd

# Disable Yellow Flash set Config;
echo 0 >/sys/devices/soc/qpnp-flash-led-25/leds/led:torch_1/max_brightness;

# Improve Touchscreen Set Config
echo '7035' > /sys/class/touch/switch/set_touchscreen;

# Misc Audio Optimizations Set Config
echo 1 >/sys/module/snd_soc_wcd9330/parameters/high_perf_mode;

#Force GPU for touch render Set Config
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;

# CPU Boost Tweaks Set Config
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_min_freq;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy0/scaling_setspeed;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;

# TCP Congestion Control Tweaks Set Config
write /proc/sys/net/core/default_qdisc; fq_codel
write /proc/sys/net/ipv4/tcp_congestion_control; bbr

# Enable Fast Charging Rate
if [ -e /sys/kernel/fast_charge/force_fast_charge; ]; then
  echo "1" > /sys/kernel/fast_charge/force_fast_charge
fi

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

done