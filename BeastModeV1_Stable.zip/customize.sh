#!/system/bin/sh
ui_print " "
ui_print " "
sleep 0.20                                                 
ui_print "    @@@@@@@   @@@@@@@@   @@@@@@    @@@@@@   @@@@@@@  "
sleep 0.19
ui_print "    @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@   @@@@@@@  "
sleep 0.18
ui_print "    @@!  @@@  @@!       @@!  @@@  !@@         @@!    "
sleep 0.17
ui_print "    !@   @!@  !@!       !@!  @!@  !@!         !@!    "
sleep 0.16
ui_print "    @!@!@!@   @!!!:!    @!@!@!@!  !!@@!!      @!!    "
sleep 0.15
ui_print "    !!!@!!!!  !!!!!:    !!!@!!!!   !!@!!!     !!!    "
sleep 0.14
ui_print "    !!:  !!!  !!:       !!:  !!!       !:!    !!:    "
sleep 0.13
ui_print "    :!:  !:!  :!:       :!:  !:!      !:!     :!:    "
sleep 0.12
ui_print "     :: ::::   :: ::::  ::   :::  :::: ::      ::    "
sleep 0.11
ui_print "    :: : ::   : :: ::    :   : :  :: : :       :     "                                                 
ui_print " " 
sleep 0.2
ui_print " "         
ui_print "    @@@@@@@@@@    @@@@@@   @@@@@@@   @@@@@@@@   "
sleep 0.19
ui_print "    @@@@@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@@   "
sleep 0.18
ui_print "    @@! @@! @@!  @@!  @@@  @@!  @@@  @@!        "
sleep 0.17
ui_print "    !@! !@! !@!  !@!  @!@  !@!  @!@  !@!        "
sleep 0.16
ui_print "    @!! !!@ @!@  @!@  !@!  @!@  !@!  @!!!:!     "
sleep 0.15
ui_print "    !@!   ! !@!  !@!  !!!  !@!  !!!  !!!!!:     "
sleep 0.14
ui_print "    !!:     !!:  !!:  !!!  !!:  !!!  !!:        "
sleep 0.13
ui_print "    :!:     :!:  :!:  !:!  :!:  !:!  :!:        "
sleep 0.12
ui_print "    :::     ::   ::::: ::   :::: ::   :: ::::   "
sleep 0.11
ui_print "     :      :     : :  :   :: :  :   : :: ::    "
sleep 0.5
ui_print " " 
ui_print " "
ui_print " "
ui_print "*****************************************************"
ui_print "  " 
ui_print "  × Better CPU/GPU Performance (Less Fps-Drop)       "
sleep 1.2
ui_print "  " 
ui_print "  × Better Battery Backup On Normal usage            "
sleep 1.3
ui_print "  " 
ui_print "  × Dynamic Tweaks (Auto Disable If There's No Need) "
sleep 1.4
ui_print "  " 
ui_print "  × Credits: @HafizZiq, @akira_vishal & @NotZeeTaa     "
sleep 1.5  
ui_print "  " 
ui_print "  × Use At Your Own Risk xD                          "
ui_print "  " 
ui_print "*****************************************************"
sleep 0.9  

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
}

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'em/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
postfs=$TMPDIR/post-fs-data.sh
. $TMPDIR/functions.sh

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases


