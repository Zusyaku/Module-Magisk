#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
# This script will be executed in late_start service mode
#!/system/bin/sh

sleep 50
# Log
if [ -e /storage/emulated/0/BeastMode_ON.log ]; then
rm /storage/emulated/0/BeastMode_ON.log
fi

if [ -e "/sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker" ]; then
    write /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker "wlan_pno_wl;wlan_ipa;wcnss_filter_lock;[timerfd];hal_bluetooth_lock;IPA_WS;sensor_ind;wlan;netmgr_wl;qcom_rx_wakelock;wlan_wow_wl;wlan_extscan_wl;NETLINK"
fi

# Google Services Drain fix by @Alcolawl @Oreganoian thanks to both of them
su -c pm enable com.google.android.gms/.update.SystemUpdateActivity 
su -c pm enable com.google.android.gms/.update.SystemUpdateService
su -c pm enable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver 
su -c pm enable com.google.android.gms/.update.SystemUpdateService$Receiver 
su -c pm enable com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver 
su -c pm enable com.google.android.gsf/.update.SystemUpdateActivity 
su -c pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService$Receiver 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService$SecretCodeReceiver

#Kernel Tweak ( Lil Perf Gain )
echo 0 > /proc/sys/kernel/panic
echo 0 > /proc/sys/kernel/panic_on_oops
echo 0 > /proc/sys/kernel/compat-log
echo 0 > /proc/sys/kernel/sched_tunable_scaling
echo "955000" > /proc/sys/kernel/sched_rt_runtime_us

# Reducing Some System load
echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/time
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo "0 0 0 0" > /proc/sys/kernel/printk

#Disable CPU & Touch Boost (Just incase ur kernel have that shi*)
if [ -e "/sys/module/cpu_boost/parameters/boost_ms" ]; then
	echo "0" > /sys/module/cpu_boost/parameters/boost_ms
fi
if [ -e "/sys/module/msm_performance/parameters/touchboost" ]; then
	echo "0" > /sys/module/msm_performance/parameters/touchboost
fi
if [ -e /sys/power/pnpmgr/touch_boost ]; then
	echo "0" > /sys/power/pnpmgr/touch_boost
fi

if [ -e /sys/module/mmc_core/parameters/use_spi_crc ]; then
 echo '1' > /sys/module/mmc_core/parameters/use_spi_crc
fi

# For thermal
echo 0 > /sys/module/msm_thermal/parameters/enabled
echo 0 > /sys/module/msm_thermal/vdd_restriction/enable

# Sched Tweaks
echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 1000000 > /proc/sys/kernel/sched_migration_cost_ns
echo 0 > /proc/sys/kernel/sched_schedstats
echo 5000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 0 > /proc/sys/fs/dir-notify-enable

# VM Tweaks
echo 100 > /proc/sys/vm/vfs_cache_pressure
echo 100 > /proc/sys/vm/swappiness
echo 6651 > /proc/sys/vm/min_free_kbytes
echo 29615 > /proc/sys/vm/extra_free_kbytes
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 20 > /proc/sys/vm/dirty_ratio
echo 10 > /proc/sys/vm/stat_interval
echo 0 > /proc/sys/vm/oom_dump_tasks
echo 1 > /proc/sys/vm/reap_mem_on_sigkill

# TCP
echo 1 > /proc/sys/net/ipv4/tcp_ecn
echo 3 > /proc/sys/net/ipv4/tcp_fastopen
echo 0 > /proc/sys/net/ipv4/tcp_syncookies

if [ -e /sys/kernel/debug/sched_features ]; then
	echo NEXT_BUDDY > /sys/kernel/debug/sched_features
	echo NO_STRICT_SKIP_BUDDY > /sys/kernel/debug/sched_features
	echo NO_NONTASK_CAPACITY > /sys/kernel/debug/sched_features
	echo TTWU_QUEUE > /sys/kernel/debug/sched_features 
fi

for queue in /sys/block/*/queue; do
   echo 0 > "${queue}"/add_random
   echo 0 > "${queue}"/iostats
   echo 2 > "${queue}"/nomerges
   echo 0 > "${queue}"/rotational
   echo 0 > "${queue}"/iosched/slice_idle
   echo 0 > "${queue}"/iosched/low_latency
   echo 1 > "${queue}"/iosched/group_idle
done 

# Entropy (Stock bess)
echo 64 > /proc/sys/kernel/random/read_wakeup_threshold
echo 896 > /proc/sys/kernel/random/write_wakeup_threshold

# init.d enabler
if [ "$1" == "-ls" ]; then LS=true; else LS=false; fi
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh) $LS && if [ -f "$i" -a -x "$i" ]; then $i & fi;;
    *) $LS || if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done


