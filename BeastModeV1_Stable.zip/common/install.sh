ui_print ""
ui_print "- Startin Module Installation -"
sleep 0.5
ui_print ""
ui_print "- Do You Want Thermal? -️"
ui_print ""
sleep 0.5
ui_print "- ( Vol -Down Select / Vol +Up Next )"
sleep 0.2
ui_print ""
ui_print " 1. Yes."
sleep 0.2
ui_print " 2. No."
sleep 0.2
ui_print ""
sleep 0.2
ui_print " Select: "
TH=1
while true; do
 ui_print "  $TH"
 if $VKSEL; then
  TH=$((TH + 1))
 else 
  break
 fi
 if [ $TH -gt 2 ]; then
  TH=1
 fi
done
ui_print " Selected: $TH "
#
case $TH in
 1 ) FCTEXTAD2="Enabled"; cp -af $TMPDIR/em/t/* $MODPATH/system/vendor/etc;;
 2 ) FCTEXTAD2="Disabled"; rm -rf $TMPDIR/em/t;;
esac
ui_print "- Custom Thermal: $FCTEXTAD2 "
ui_print ""
sleep 0.5
ui_print "- Checking Kernel -"
sleep 0.9
if [ -d /sys/devices/system/cpu/cpu0/cpufreq/interactive ]; then
 echo "- HMP Kernel Detected! -"
sleep 0.5 
 echo "- Installating Custom HMP PerfHal -" 
 rm -rf $MODPATH/em/perf
elif [ -d /sys/devices/system/cpu/cpu0/cpufreq/schedutil ]; then
 echo "- EAS Kernel Detected! -"
sleep 0.5 
 echo "- Installating Custom EAS PerfHal -"
 rm -rf $MODPATH/system/vendor/etc/perf/*
 cp -af $MODPATH/em/perf $MODPATH/system/vendor/etc
fi 
sleep 0.5