###Last Time i checked, me the one who was here so wtf are you doing here 🙂??
####----------------------------------------------------------####
###----------------------------------------------------------###
##----------------------------------------------------------##
#----------------------------------------------------------#
SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'iUnlockerSystem/iUnlocker.sh' -d $TMPDIR >&2
. $TMPDIR/iUnlocker.sh
#----------------------------------------------------------#
##----------------------------------------------------------##
###----------------------------------------------------------###
####----------------------------------------------------------####



#Customize.sh is Not encrypted because its nothing in it 

##install.sh is encrypted with high level encryption so you can't steal my codes or my work.
##You don't know how i spent a lot of time making iUnlocker.