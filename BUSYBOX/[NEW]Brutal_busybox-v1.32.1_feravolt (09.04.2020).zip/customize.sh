#!/system/bin/sh
### FeraVolt. 2020 ###

deploy(){
A=$(getprop ro.product.cpu.abi);
set_perm_recursive $MODPATH/system/xbin/ 0 0 0755 0777;
chmod -R 755 $MODPATH/system/xbin;
if [ "$A" = "$(echo "$A"|grep "arm64")" ]; then
mv -f $MODPATH/system/xbin/busybox64 $MODPATH/system/xbin/busybox;
rm -Rf $MODPATH/system/xbin/busybox32;
rm -Rf $MODPATH/system/xbin/busybox86;
ui_print "- 64 bit ARM arch detected.";
elif [ "$A" = "$(echo "$A"|grep "armeabi")" ]; then
mv -f $MODPATH/system/xbin/busybox32 $MODPATH/system/xbin/busybox;
rm -Rf $MODPATH/system/xbin/busybox64;
rm -Rf $MODPATH/system/xbin/busybox86;
ui_print "- 32bit ARM arch detected.";
elif [ "$A" = "$(echo "$A"|grep "x86_64")" ]; then
mv -f $MODPATH/system/xbin/busybox86 $MODPATH/system/xbin/busybox;
rm -Rf $MODPATH/system/xbin/busybox64;
rm -Rf $MODPATH/system/xbin/busybox86;
ui_print "- x86_64 arch detected.";
else
abort "Can't detect arch of device!";
fi;
};

if [ -d /data/adb/modules/busybox-brutal ]; then
deploy;
else
if [ -d /data/adb/modules/busybox-ndk ]; then
rm -rf $MODPATH
abort "- Please uninstall another busybox and reboot."
elif [ -e /system/xbin/busybox ]; then
rm -rf $MODPATH
abort "- Please uninstall another busybox and reboot."
elif [ -e /system/bin/busybox ]; then
rm -rf $MODPATH
abort "- Please uninstall another busybox and reboot."
elif [ -e /vendor/bin/busybox ]; then
rm -rf $MODPATH
abort "- Please uninstall another busybox and reboot."
else
deploy;
if [ ! -d /system/xbin ]; then
mkdir $MODPATH/system/bin;
set_perm_recursive $MODPATH/system/bin/ 0 0 0755 0777;
chmod -R 755 $MODPATH/system/bin;
mv -f $MODPATH/system/xbin/busybox $MODPATH/system/bin/busybox;
rm -Rf $MODPATH/system/xbin;
ui_print "- Installing to /system/bin/..";
fi;
ui_print "- Brutal busybox by FeraVolt installed.";
fi;
fi;

