#MagiskGamingModule

Module Link : T.ME/V9Y_7V3

### Description ###

› iUnlocker is a magisk module thats give you permission to unlock highest graphics for most games.

*********

⚠ ️› ATTENTION: iUnlocker Not responsible of any banned you get This Mod is 100% Safe*


 - If you don't wanna get banned of any game then follow my steps:

1) - go to magisk manager then Go to settings then Go to hide magisk manager.

2) - in settings hide magisk enable it and hide all games like pubg, cod, etc.

And that's it.

