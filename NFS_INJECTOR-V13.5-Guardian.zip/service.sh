/system/etc/injector/injector1 2>/dev/null && /system/etc/injector/injector2 2>/dev/null && /system/etc/injector/injector3 2>/dev/null
exit 0
