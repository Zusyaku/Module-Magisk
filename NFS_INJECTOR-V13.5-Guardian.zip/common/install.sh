#!/system/bin/sh
SKIPUNZIP=1
unzip -oq "$ZIPFILE" 'com.nfs.nfsmanager.apk' -d /data/local/tmp 2>/dev/null
unzip -oq "$ZIPFILE" -x 'com.nfs.nfsmanager.apk' -d $MODPATH 2>/dev/null
ui_print "___  | / /__  ____/_  ___/"
ui_print "__   |/ /__  /_   _____ "
ui_print "_  /|  / _  __/   ____/ /"
ui_print "/_/ |_/  /_/      /____/"           
ui_print ""
ui_print "* ϟ NFS-INJECTOR ϟ *"
ui_print ""
ui_print "* KING OF MODS *"
ui_print ""
ui_print "* Module For Forcefulness & Energy Aware *"
ui_print ""
ui_print "* Flash , Reboot And Forget *"
ui_print ""
ui_print "* Official Telegram Group @nfsinjector *"
ui_print "" 
ui_print "* By K1KS & Team *"
ui_print ""
nfs=$MODPATH/system/etc/injector
bun=$MODPATH/system/bin
MDP=/data/adb/modules
UDP=/data/adb/modules_update
tmp=/data/local/tmp
apk=$tmp/com.nfs.nfsmanager.apk

rm -rf $MDP/nfsinjector
rm -rf $UDP/nfsinjector
rm -rf /data/INJECTOR
if [ "$(getprop ro.product.cpu.abi)" == "$(getprop ro.product.cpu.abi | grep "arm")" ];then
 mv -f $nfs/arm/injector1 $nfs
 mv -f $nfs/arm/injector2 $nfs
 mv -f $nfs/arm/injector3 $nfs
 mkdir -p $bun
 mv -f $nfs/arm/injectorkey $bun
 rm -rf $nfs/arm
 for i in $apk; do
  if [ -e $apk ]; then
   ui_print "Installing NFS Manager"
   pm install -r $i
   ui_print "NFS Manager Installed"
   ui_print ""
  else
   ui_print "NFS Manager Is Missing!!!"
   ui_print ""
  fi;
 done
else
 rm -rf $MODPATH
 abort "$(getprop ro.product.cpu.abi) NOT SUPPORTED"
fi;
rm -f $apk
rm -f $MODPATH/com.nfs.nfsmanager.apk
