Creator
 - ArilSetiawan

# Qualcomm DROID V1
## Description
build.prop tweaked for much better game performance.