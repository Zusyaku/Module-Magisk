#!/sbin/sh

ui_print() {
  echo "ui_print $1" > "$OUTFD";
  echo "ui_print" > "$OUTFD";
}

set_progress() { echo "set_progress $1" > "$OUTFD"; }

recovery_actions() {
  OLD_LD_LIB=$LD_LIBRARY_PATH
  OLD_LD_PRE=$LD_PRELOAD
  OLD_LD_CFG=$LD_CONFIG_FILE
  unset LD_LIBRARY_PATH
  unset LD_PRELOAD
  unset LD_CONFIG_FILE
}

recovery_cleanup() {
  [ -z $OLD_LD_LIB ] || export LD_LIBRARY_PATH=$OLD_LD_LIB
  [ -z $OLD_LD_PRE ] || export LD_PRELOAD=$OLD_LD_PRE
  [ -z $OLD_LD_CFG ] || export LD_CONFIG_FILE=$OLD_LD_CFG
}

unmount_all() {
  ui_print " ";
  ui_print "- Unmounting $mounts";
  ui_print " ";
  for m in $mounts; do
    umount "$m"
  done
}

clean_up() {
  rm -rf /tmp/adreno
  rm -rf /tmp/adreno_addon.prop
}

path_info() {
  ls / >> $root_info
  ls -R $SYSTEM/system/vendor $SYSTEM/vendor >> $system_info
}

abort() {
  sleep 1;
  ui_print "- Aborting...";
  sleep 3;
  path_info;
  unmount_all;
  take_logs;
  clean_up;
  recovery_cleanup;
  exit 1;
}

exit_all() {
  sleep 0.5;
  path_info;
  unmount_all;
  sleep 0.5;
  take_logs;
  set_progress 0.90;
  clean_up;
  recovery_cleanup;
  sleep 0.5;
  ui_print "Adreno Team Cache Cleaner Successfully Installed!";
  ui_print " ";
  set_progress 1.00;
  exit 0;
}

# Pre-mount process
for p in "/system" "/system_root" "/vendor"; do
  if [ -d $p ]; then
    umount "$p"
  fi
done

# Detect A/B partition layout https://source.android.com/devices/tech/ota/ab_updates
# and system-as-root https://source.android.com/devices/bootloader/system-as-root
active_slot=`getprop ro.boot.slot_suffix`
if [ ! -z "$active_slot" ]; then
  device_abpartition=true
  if [ -n "$(cat /etc/fstab | grep /system_root)" ];
  then
    MOUNT_POINT=/system_root
  else
    MOUNT_POINT=/system
  fi
elif [ -n "$(cat /etc/fstab | grep /system_root)" ];
then
  device_abpartition=false
  MOUNT_POINT=/system_root
else
  device_abpartition=false
  MOUNT_POINT=/system
fi

mounts=""
for p in "/cache" "/data" "$MOUNT_POINT" "/vendor"; do
  if [ -d "$p" ] && grep -q "$p" "/etc/fstab" && ! mountpoint -q "$p"; then
    mounts="$mounts $p"
  fi
done

# Mount partitions
set_progress 0.10;
ui_print "- Mounting $mounts";
for m in $mounts; do
  mount "$m"
done

# Remount $MOUNT_POINT RW
mount -o rw,remount $MOUNT_POINT;

# Try to detect system-as-root through /system/init.rc like Magisk does
# Remount /system to /system_root if we have system-as-root and bind /system to /system_root/system (like Magisk does)
# For reference, check https://github.com/topjohnwu/Magisk/blob/master/scripts/util_functions.sh
sleep 0.3;
if [ -f /system/init.rc ]; then
  ui_print "- System is /system/system";
  ui_print "- Device is system-as-root";
  [ -L /system_root ] && rm -f /system_root
  mkdir /system_root 2>/dev/null
  mount --move /system /system_root
  mount -o bind /system_root/system /system
  SYSTEM=/system_root/system
  mounts="$mounts /system_root";
elif [ -f /system_root/init.rc ]; then
  ui_print "- System is /system_root/system";
  ui_print "- Device is system-as-root";
  SYSTEM=system_root/system
else
  ui_print "- System is /system";
  SYSTEM=/system
fi

ui_print " ";

TMP="/tmp"

recovery_actions;

PROPFILES="$SYSTEM/build.prop $SYSTEM/vendor/build.prop $TMP/adreno_addon.prop"

get_file_prop() {
  grep -m1 "^$2=" "$1" | cut -d= -f2
}

get_prop() {
  #check known .prop files using get_file_prop
  for f in $PROPFILES; do
    if [ -e "$f" ]; then
      prop="$(get_file_prop "$f" "$1")"
      if [ -n "$prop" ]; then
        break #if an entry has been found, break out of the loop
      fi
    fi
  done
  #if prop is still empty; try to use recovery's built-in getprop method; otherwise output current result
  if [ -z "$prop" ]; then
    getprop "$1" | cut -c1-
  else
    printf "$prop"
  fi
}

log_folder="$(dirname "$ZIPFILE")";
mkdir -p $TMP/adreno/logs
log_dir="$TMP/adreno/logs"
adreno_log="$log_dir/installation_log.txt"
adreno_prop="$TMP/adreno_addon.prop"
build_prop="$SYSTEM/build.prop"
vendor_build_prop="$SYSTEM/vendor/build.prop"
details_log="$log_dir/details.txt"
root_info="$log_dir/rootpathinfo.txt"
system_info="$log_dir/systempathinfo.txt"

take_logs() {
  ui_print "- Copying logs to $log_folder";
  ui_print " ";
  cp -f $TMP/recovery.log $log_dir/recovery.log
  cd $log_dir
  tar -cz -f "$TMP/adreno_addon_debug_logs.tar.gz" *
  cp -f $TMP/adreno_addon_debug_logs.tar.gz $log_folder/adreno_addon_debug_logs.tar.gz
  cd /
  rm -rf $TMP/adreno_addon_debug_logs.tar.gz
}

echo "  " >> $adreno_log;
echo "***********************************************" >> $adreno_log;
echo "               Installation Logs               " >> $adreno_log;
echo "***********************************************" >> $adreno_log;
echo "  " >> $adreno_log;
echo "- Mount Point: $MOUNT_POINT" >> $adreno_log;
echo "- Current slot is: $active_slot" >> $adreno_log;
echo "  " >> $adreno_log;

# Get ROM, Device & Package information
adreno_android="$(get_prop "ro.adreno.android")"
adreno_sdk="$(get_prop "ro.adreno.sdk")"
adreno_arch="$(get_prop "ro.adreno.arch")"
addon_edition_type="$(get_prop "ro.adreno.addon.edition")"
package_version="$(get_prop "ro.adreno.version")"
rom_version="$(get_prop "ro.build.version.release")"
rom_sdk="$(get_prop "ro.build.version.sdk")"
device_architecture="$(get_prop "ro.product.cpu.abilist")"

if [ -z "$device_architecture" ]; then
  device_architecture="$(get_prop "ro.product.cpu.abi")"
fi

case "$device_architecture" in
  *x86_64*) arch="x86_64"
    ;;
  *x86*) arch="x86"
    ;;
  *arm64*) arch="arm64"
    ;;
  *armeabi*) arch="arm"
    ;;
  *) arch="unknown"
    ;;
esac

echo "***********************************************" >> $adreno_log;
echo "  " >> $adreno_log;
echo "# Device And Adreno Addon Information" >> $adreno_log;
echo "  " >> $adreno_log;
echo "- Adreno VER    : $adreno_android" >> $adreno_log;
echo "- Adreno SDK    : $adreno_sdk" >> $adreno_log;
echo "- Adreno ARCH   : $adreno_arch" >> $adreno_log;
echo "  " >> $adreno_log;
echo "- Edition type  : $addon_edition_type" >> $adreno_log;
echo "- Package VER   : $package_version" >> $adreno_log;
echo "  " >> $adreno_log;
echo "- ROM VER       : $rom_version" >> $adreno_log;
echo "- ROM SDK       : $rom_sdk" >> $adreno_log;
echo "- Device ARCH   : $device_architecture" >> $adreno_log;
echo "  " >> $adreno_log;
echo "# End Device And Adreno Addon Information" >> $adreno_log;
echo "  " >> $adreno_log;

# Get prop details before compatibility checks
cat $build_prop >> $details_log;
cat $adreno_prop >> $details_log;

# Prepare msgs
wrong_version="! Wrong Android Version Detected"
wrong_arch="! Wrong Device Architecture Detected"
pkg_details="! This Package is For Android: $adreno_android Only"
rom_ver_info="Your ROM is Android: $rom_version"
pkg_details_arch="! This Package is For Device: $adreno_arch Only"
edition_detection_failed="! Failed to detect Adreno Addon Edition type"

set_progress 0.20;
sleep 1;
ui_print "- Android: $rom_version, SDK: $rom_sdk, ARCH: $arch";
sleep 1;

if [ "$rom_sdk" -lt "$adreno_sdk" ]; then
  ui_print " ";
  ui_print "                    WARNING                    ";
  ui_print " ";
  ui_print "$wrong_version ";
  sleep 0.5;
  ui_print "$pkg_details ";
  sleep 0.5;
  ui_print "$rom_ver_info ";
  sleep 0.5;
  ui_print " ";
  ui_print "              Installation Failed              ";
  ui_print " ";
  abort;
fi

if [ ! "$arch" = "$adreno_arch" ]; then
  ui_print " ";
  ui_print "                    WARNING                    ";
  ui_print " ";
  ui_print "$wrong_arch ";
  sleep 0.5;
  ui_print "$pkg_details_arch ";
  sleep 0.5;
  ui_print "Your Device is: $arch ";
  sleep 0.5;
  ui_print " ";
  ui_print "              Installation Failed              ";
  ui_print " ";
  abort;
fi

set_progress 0.30;
sleep 1;
ui_print " ";
ui_print "- Adreno VER    : $adreno_android";
ui_print "- Adreno SDK    : $adreno_sdk";
ui_print "- Adreno ARCH   : $adreno_arch";
ui_print " ";
ui_print "- Edition type  : $addon_edition_type";
ui_print "- Package VER   : $package_version";
ui_print "  ";
ui_print "- ROM VER       : $rom_version";
ui_print "- ROM SDK       : $rom_sdk";
ui_print "- Device ARCH   : $device_architecture";
ui_print " ";
ui_print "***********************************************";
sleep 1;

echo "- Compatibility checks completed" >> $adreno_log;
echo "  " >> $adreno_log;
echo "***********************************************" >> $adreno_log;
echo "             Starting Installation             " >> $adreno_log;
echo "***********************************************" >> $adreno_log;

ui_print " ";
if [ "$addon_edition_type" = "Cache Cleaner" ]; then
  ui_print "- Preparing Cache Cleaner Addon package";
  set_progress 0.30;
  sleep 1.5;
  echo "- Preparing Cache Cleaner Addon package" >> $adreno_log;
else
  # Abort the installation if the installer failed to detect edition type
  ui_print "                    WARNING                    ";
  ui_print " ";
  sleep 0.5;
  echo "- Failed to detect edition type" >> $adreno_log;
  ui_print "$edition_detection_failed";
  sleep 0.5;
  ui_print " ";
  ui_print "              Installation Failed              ";
  abort;
fi

cache_cleaner() {
  set_progress 0.50;
  ui_print " ";
  ui_print "- Cleaning OpenGL and Vulkan shader caches";
  sleep 1.5;
  for i in "$(find /data -type f -name '*shader*')"; do
    rm -f $i
  done
}

# remove_line <file> <line match string>
# By osm0sis @xda-developers
# For reference, check https://github.com/osm0sis/AnyKernel3/blob/master/tools/ak3-core.sh
remove_line() {
  if grep -q "$2" $1; then
    local line=$(grep -n "$2" $1 | head -n1 | cut -d: -f1);
    sed -i "${line}d" $1;
  fi;
}

# Clean shader caches
echo "  " >> $adreno_log;
echo "- Cleaning OpenGL and Vulkan shader caches" >> $adreno_log;
echo "# " >> $adreno_log;
echo "  " >> $adreno_log;
cache_cleaner >> $adreno_log;
# End

echo "***********************************************" >> $adreno_log;
echo "             Installation Finished             " >> $adreno_log;
echo "***********************************************" >> $adreno_log;

sleep 0.5;
set_progress 0.80;

exit_all;

# Installation completed
