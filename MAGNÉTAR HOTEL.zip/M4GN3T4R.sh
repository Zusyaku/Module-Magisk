#   _____ __________ _____ ____ _____ _________  
#  |     | _  |   __|   | |  __|_   _| _  | __ | 
#  | | | |    |  |  | | | |  __| | | |    |   -| 
#  |_|_|_|_|__|_____|_|___|____| |_| |_|__|_|__| 
#                           by Kyliekyler © 2019

#===========================================================================//
# GIVE PROPER CREDITS IF YOU USE THE PART OF IT IN YOUR WORK, THANKS!
#===========================================================================//

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" '.M4GN3T4R/M4GN3T4R_FUNCTIONS.sh' -d $TMPDIR >&2
. $TMPDIR/M4GN3T4R_FUNCTIONS.sh
