rm -f /data/adb/service.d/opt.sh

