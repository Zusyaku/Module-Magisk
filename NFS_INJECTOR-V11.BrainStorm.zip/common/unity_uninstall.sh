if [ -d /dev/nfs ]; then
 rm -rf /dev/nfs
fi;