#!/system/bin/sh
# Written by Draco (tytydraco @ GitHub)
# Modded By @NotZeetaa

ui_print "[*] Setting executable permissions..."
ui_print "Thx to all Beta Testers ♥️"
ui_print "  __________ ____  "
ui_print " |__  /_   _/ ___| "
ui_print "   / /  | | \___ \ "
ui_print "  / /_  | |  ___) |"
ui_print " /____| |_| |____/ "
ui_print "                           "
ui_print "𝗭𝗲𝗲𝘁𝗮𝗮𝗧𝘄𝗲𝗮𝗸𝘀 𝗩9 𝗠𝗮𝗱𝗲 𝗯𝘆 @NotZeeta"
ui_print "The ZeetaaTweaks unlocks the full power ⚡ of all SnapDragon Devices"
ui_print "🕒 sᴇᴛᴛɪɴɢ ᴛᴡᴇᴀᴋs"


                   
set_perm_recursive "$MODPATH/system/bin" root root 0777 0755

# Do install-time script execution
sh "$MODPATH/system/bin/zeetaatweaks"
echo "[*] Executed service script during live boot. Reboot is not needed."

ui_print "🔥 𝗣𝗲𝗿𝗳𝗼𝗿𝗺𝗮𝗻𝗰𝗲 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗱"
ui_print " "
ui_print "🔋 𝗕𝗮𝘁𝘁𝗲𝗿𝘆 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗱"
ui_print " "
ui_print "🎮 𝗚𝗮𝗺𝗶𝗻𝗴 𝗮𝗻𝗱 𝗦𝗲𝗻𝘀𝗶𝘃𝗶𝘁𝘆 𝗶𝗺𝗽𝗿𝗼𝘃𝗲𝗱"
ui_print " "
ui_print "✨ 𝗞𝗰𝗮𝗹 𝗖𝗼𝗻𝗳𝗶𝗴 𝗔𝗽𝗽𝗹𝗶𝗲𝗱"
ui_print " "
ui_print "🔊 𝗦𝗼𝘂𝗻𝗱 𝗜𝗺𝗽𝗿𝗼𝘃𝗲𝗱"
ui_print " "
ui_print "✅ 𝗘𝗻𝘁𝗿𝗼𝗽𝘆 𝗔𝗽𝗽𝗹𝗶𝗲𝗱"