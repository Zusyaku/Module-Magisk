#!/system/bin/sh
# by @NotZeetaa

# Wait for boot to finish completely
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# Sleep an additional 90s to ensure init is finished
sleep 90

# Setup tweaks
zeetaatweaks
