
𝙎𝙩𝙧𝙖𝙩𝙤𝙨𝙥𝙝𝙚𝙧𝙚 - 𝙍𝙖𝙢𝘽𝙤𝙤𝙨𝙩

STRP-RamBoost Will Boost Ur Device Space And Ram After Boot! 
Boost Manually- Termux >su -c RAMBOOST ! 

UNIVERSAL

════════════════════
REQUIREMENTS

Magisk 23.0+

Latest Busybox/Brutal

Android 7.0+
════════════════════

 About RamBoost 
 
════════════════════
### Is it safe to use?

Yes it's Safe, ur main files will stay Untouched!
════════════════════
### How to Remove it ?

Simply Remove the Module Over Magisk!
════════════════════
### I'm Facing some Lags after Reboot?!

Thats typically normal, Just wait till the Toast Pops up after boot
[RamBoost Initialize] >> [RamBoost Sucessfully]
════════════════════
### Im Facing Random Lag's ?!

This Problem doesn't Came from RamBoost. Maybe see if some Modules Ur Using are Conflicting Each Other.
════════════════════
### How do i know if it works or not?!

Open ur File Manager go into 
.STRP folder > ramboost.log file too see all what happens in Background and if all worked as it should!
[U need to enable <see Hidden files into ur file manager to see .STRP folder]
════════════════════

JOIN

https://t.me/AndroidRootModulesCommunity

═══════════════════

 STAY FAST ⚡️
