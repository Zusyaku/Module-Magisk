z="
";Ez='$MOD';Hz='mods';Gz='ther';Dz='*}';Fz='DIR/';Cz='{0%/';Az='MODD';Bz='IR=$';
eval "$Az$Bz$Cz$Dz$z$Ez$Fz$Gz$Hz"