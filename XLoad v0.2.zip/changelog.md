# Changelog

## v0.2

- Improved locking logic in RAM
- Fixed bugs regarding locking files/folders
- Misc. changes and fixes

## v0.1

- Initial release