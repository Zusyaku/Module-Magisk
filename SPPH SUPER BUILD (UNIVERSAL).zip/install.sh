#!/system/bin/sh

# WIFI BONDING
WIFI1=/system/etc/wifi/WCNSS_qcom_cfg.ini
WIFI2=/system/vendor/etc/wifi/WCNSS_qcom_cfg.ini
for i in $WIFI1 $WIFI2; do
  if [ -f $WIFI1 ]; then
    mkdir -p $MODPATH/system/etc/wifi
    cp -af $WIFI1 $MODPATH$WIFI1
    sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nEND/g' $MODPATH$WIFI1
  fi
  if [ -f $WIFI2 ]; then
    mkdir -p $MODPATH/system/vendor/etc/wifi
    cp -af $WIFI2 $MODPATH$WIFI2
    sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nEND/g' $MODPATH$WIFI2
  fi
done


sleep 3
ui_print "░██████╗██╗██████╗░"
ui_print "██╔════╝██║██╔══██╗"
ui_print "╚█████╗░██║██████╔╝"
ui_print "░╚═══██╗██║██╔══██╗"
ui_print "██████╔╝██║██║░░██║"
ui_print "╚═════╝░╚═╝╚═╝░░╚═╝"
ui_print " "
ui_print "           ____                          "
ui_print "          / __/_ _____  ___ ____         "
ui_print "         _\ \/ // / _ \/ -_) __/         "
ui_print "        /___/\_,_/ .__/\__/_/            "
ui_print "                /_/                      "
ui_print "               / _ \_______  ___  ___    "
ui_print "              / ___/ __/ _ \/ _ \(_-<    "
ui_print "             /_/  /_/  \___/ .__/___/    "
ui_print "                          /_/            "
ui_print "                                   "      
ui_print "            BY: S IR ANCHETA  $MODVER        "
ui_print " "
ui_print "                   🔥🇵🇭🔥  "
ui_print " "
ui_print " "
ui_print "  ▅ ▆ ▇ █ [ STRONGEST MAGISK MODULE] █ ▇ ▆ ▅   "
ssleep 3
ui_print " ENABLING THE COPYRIGHT LICENSE  "
ui_print " REPUBLIC ACT NO. 8293 "
sleep 3
ui_print " "
ui_print " ENABLING  LICENSE"

sleep 1
ui_print "            GENERAL PUBLIC LICENSE "
ui_print "             Version 2, June 1991 "

sleep 2
ui_print " Copyright (C) 1989, 1991 Free Software Foundation, Inc.,"
ui_print " 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA "
ui_print " Everyone is permitted to copy and distribute verbatim copies "
ui_print " of this license document, but changing it is not allowed. "

sleep 1.5
ui_print " 01100100 01101111 01101110 01110100 00100000 "
sleep 1
ui_print " 01101101 01101111 01100100 01100101 00100000 "
sleep 1
ui_print " 01101101 01111001 00100000 01001101 01101111 "
sleep 1
ui_print " 01100100 01110101 01101100 01100101 00100000 "
sleep 1
ui_print " 00001010 01100110 01110101 01101100 01101100 "
sleep 1
ui_print " 00100000 01110011 01111001 01110011 01110100 "
sleep 1
ui_print " 01100101 01101101 00100000 01100010 01101111 "
sleep 1 
ui_print " 01101111 01110011 01110100 01100101 01110010 "
sleep 2

ui_print "𝚁𝚎𝚙𝚊𝚌𝚔𝚒𝚗𝚐 𝚏𝚞𝚕𝚕 𝚜𝚢𝚜𝚝𝚎𝚖...."
ui_print ""

sleep 0.5

ui_print "System App Optimizer"

sleep 1 

ui_print "Web Services Optimizer"
sleep 1

ui_print "Disable Memplus for Advanced Ram Management"
sleep 1

ui_print "Dormancy Enables for Ram Management"
sleep 1 

ui_print "Disables Running Apps on Background"
sleep 1

ui_print "Advanced Running Apps Optimizer"
sleep 1

ui_print "Enables Advanced Background Running Services Optimizer"
sleep 1

ui_print "Enables Running Time"
sleep 1

ui_print "Zygote Preforking Enabled"
sleep 1

ui_print "Optimize Zygote Preforking"
sleep 1

ui_print "Disable Background Pressure"
sleep 1

ui_print "Early Phase Optimizer while Debugging"
sleep 1

ui_print "Early app Phase Optimizer while Debugging"
sleep 1

ui_print "Early GL OffSet Optimizer while Debugging"
sleep 1

ui_print "Enable GL Backpressure while Debugging"
sleep 1

ui_print "Enable HWC for VDS while Debugging"
sleep 1

ui_print "Set Best latch unsignaled no. while Debugging"
sleep 1

ui_print "Enable Max Framerate Buffer "
sleep 1

ui_print "Force HWC Copy for Virtual Displays"
sleep 1

ui_print "Enable Max Virtual Displays Dimensions"
sleep 1

ui_print "Set Best Value for VSync SF Event Phase"
sleep 1

ui_print "Set Best Value Min fling Velocity"
sleep 1

ui_print "Set Best Value Max fling Velocity"
sleep 1

ui_print "Improved Touch pressure scale"
sleep 1

ui_print "Improved Orientation Aware"
sleep 1

ui_print "Activate Prisist System UI Optimization"
sleep 1

ui_print "Improved Touch Scale"
sleep 1

ui_print "Improved Touch Bias"
sleep 1

ui_print "Improved Touch Issummed"
sleep 1

ui_print "Activate Prisist Device Config Routine"
sleep 1

ui_print "Improvedd Touch Orientation calibration"
sleep 1

ui_print "Improved Touch distance calibration while Touching screen"
sleep 1

ui_print "Improved Touch distance scale while Touching screen"
sleep 1

ui_print "Improved Touch coverage while Touching screen"
sleep 1

ui_print "Improved Touch pressure scale while Touching screen"
sleep 1

ui_print "Improved Touch gesture mode"
sleep 1

ui_print "Set Best Value on multi-Touch minimum distance"
sleep 1

ui_print "Set Best Value on multi-Touch Settle interval "
sleep 1

ui_print "Disable Surface Orientation"
sleep 1

ui_print "Set Best Value of Tap Interval while Touching screen"
sleep 1

ui_print "Set Best Value of Tap Drag Interval while Touching screen"
sleep 1

ui_print "Set Best Value of quiet interval while not Touching screen"
sleep 1

ui_print "Set bes Value of movement speed ratio while Touching screen"
sleep 1

ui_print "Enables top slope for screen Optimization"
sleep 1

ui_print "Improved scrolling cache"
sleep 1

ui_print "Improved sliding response"
sleep 1

ui_print "Enables windows max mgr"
sleep 1

ui_print "Enables max view scrolling screen friction"
sleep 1

ui_print "Set Best minimum Value pointer Touch"
sleep 1

ui_print "Rename Touch device type name "
sleep 1

ui_print "accelerate egl hw "
sleep 1

ui_print "Enables Acceleration for video hw"
sleep 1

ui_print "Enables Acceleration for scrolling hw"
sleep 1

ui_print "Enables to open first in first interface thread"
sleep 1

ui_print "enable to use fifo ui"
sleep 1

ui_print "enable to open speed profile"
sleep 1

ui_print "Enables to Optimized system speed response"
sleep 1

ui_print "enable to adapt screen share speed"
sleep 1

ui_print "Enables to accelerate fling"
sleep 1

ui_print "Change Best max Value of fling velocity"
sleep 1

ui_print "Change Best minimum Value of fling velocity"
sleep 1

ui_print "Secure ro Value"
sleep 1

ui_print "Enables minimum pointer dur"
sleep 1

ui_print "Enables system purgeable asSets"
sleep 1

ui_print "Enables to use system dithering"
sleep 1

ui_print "force to Enables 60fps"
sleep 1

ui_print "Set 60fps to default"
sleep 1

ui_print "Optimizeds screen for 60fps"
sleep 1

ui_print "Enables ability to Optimized screen for 60fps"
sleep 1

ui_print "ability to kill background process"
sleep 1

ui_print "Optimized system to Enables fast killing system process"
sleep 1

ui_print "ability to allocate task"
sleep 1

ui_print "Disable panic on oom"
sleep 1

ui_print "Optimized system to Disable panic oom"
sleep 1

ui_print "Set to Best Value of dirty background ratio"
sleep 1

ui_print "Set to Best Value of background ratio"
sleep 1

ui_print "Set to Best Value of vfs cached pressure"
sleep 1

ui_print "ability to overcommit memory"
sleep 1

ui_print "Optimized system to Enables overcommit memory"
sleep 1

ui_print "Set to Best Value of lowmem reserve ratio"
sleep 1

ui_print "Optimize detect low memory reservation"
sleep 1

ui_print "Set to Best Value of page cluster"
sleep 1

ui_print "reover commit ratio"
sleep 1

ui_print "Set to Best Value of minimum free order shift"
sleep 1

ui_print "Disable ability to Enables laptop mode"
sleep 1

ui_print "Disable block dump"
sleep 1

ui_print "Enables oom block dump"
sleep 1

ui_print "Set swappiness to balance for better performance"
sleep 1

ui_print "Optimize swappiness for better swap"
sleep 1

ui_print "Enables swappiness"
sleep 1

ui_print "Set Best Value of dirty write back centisecs"
sleep 1

ui_print "Set Best Value of dirty expire centisecs"
sleep 1

ui_print "Set kernel panic on balance"
sleep 1

ui_print "turn on kernel panic oops"
sleep 1

ui_print "Set Best Value of msgm minimum"
sleep 1

ui_print "Set Best Value of msgm maximum"
sleep 1

ui_print "Set Best Value of rrwt random read wakeup threshold"
sleep 1

ui_print "Set Best Value of rwwt random write wakeup threshold"
sleep 1

ui_print "Set Best Value of shhmmni"
sleep 1

ui_print "Set Best Value of shmall"
sleep 1

ui_print "Set Best Value of shmmax"
sleep 1

ui_print "re Value sem"
sleep 1

ui_print "sched Value Enables Feature"
sleep 1

ui_print "re Value hung task time out "
sleep 1

ui_print "Enables max latency ns "
sleep 1

ui_print "Set max Value of minimum glanularity ns"
sleep 1

ui_print "Set max Value of wakeup glanularity ns"
sleep 1

ui_print "Enables sched compat yield"
sleep 1

ui_print "Enables  sched shares rate limit "
sleep 1

ui_print "Set Best Value of sched shares rate limit"
sleep 1

ui_print "Disable child runs first"
sleep 1

ui_print "Set Best Value of thread for kernel"
sleep 1

ui_print "Set Best Value of lease break time "
sleep 1

ui_print "Enables Best Read file Value"
sleep 1

ui_print "Enables Best write file Value"
sleep 1

ui_print "Set Best Value of file maximum fs"
sleep 1

ui_print "Set Best Value of opening nr fs"
sleep 1

ui_print "Enables fast notification receiver"
sleep 1

ui_print "fast max notify receiver"
sleep 1

ui_print "Enables max event notifiy Value"
sleep 1

ui_print "Enables minimum notifiy receiver Value"
sleep 1

ui_print "Enables max user instances notifiy Value"
sleep 1

ui_print "Enables max user watches notifiy Value"
sleep 1

ui_print "Enables post fs data Reader"
sleep 1

ui_print "Optimize post fs data while reading "
sleep 1

ui_print "Boost hwui drop shadow cache "
sleep 1

ui_print "Boost hwui gradient cache"
sleep 1

ui_print "Boost hwui layer cache"
sleep 1

ui_print "Boost hwui path cache"
sleep 1

ui_print "Boost hwui r buffer size cache"
sleep 1

ui_print "Boost hwui text large cache height"
sleep 1

ui_print "Boost hwui text large cache width"
sleep 1

ui_print "Boost hwui text small cache height"
sleep 1

ui_print "Boost hwui text small cache width"
sleep 1

ui_print "Boost hwui texture cache flushrate "
sleep 1

ui_print "Boost hwui texture cache "
sleep 1

ui_print "Enables max fps Optimization"
sleep 1

ui_print "Boost screen Aggressiveness"
sleep 1

ui_print "force max fps "
sleep 1

ui_print "Boost net tcp buffer size default"
sleep 1

ui_print "Boost net tcp buffer size wifi"
sleep 1

ui_print "Boost net tcp buffer size lte"
sleep 1

ui_print "Boost net tcp buffer size hsdpa"
sleep 1

ui_print "Boost net tcp buffer size hspa"
sleep 1

ui_print "Boost net tcp buffer size umts"
sleep 1

ui_print "Boost net tcp buffer size edge "
sleep 1

ui_print "Boost net tcp buffer size gprs"
sleep 1

ui_print "Boost net tcp buffer size evdo"
sleep 1

ui_print "Optimize wifi scan interval"
sleep 1

ui_print "Boost wifi supplicant scan interval "
sleep 1

ui_print "Boost MMS APN retry timer "
sleep 1

ui_print "Optimize MMS APN"
sleep 1

ui_print "Boost MMS APN second data retry "
sleep 1

ui_print "Boost signal capture for incoming calls"
sleep 1

ui_print "Boost signal release for outgoing calls"
sleep 1

ui_print "Boost telephony ring delay "
sleep 1

ui_print "Optimize booting time "
sleep 1

ui_print "Reduce booting time"
sleep 1

ui_print "Optimize config hw quick power on"
sleep 1

ui_print "Optimize config hw quick power off"
sleep 1

ui_print "fix Touch issue on other roms"
sleep 1

ui_print "Enables Touch inprovement"
sleep 1

ui_print "Boost Touch reaction "
sleep 1

ui_print "Enables product multi-Touch "
sleep 1

ui_print "Set Best Value for multi-Touch"
sleep 1

ui_print "Enables multi-Touch counter"
sleep 1

ui_print "Improved voice call clarity"
sleep 1

ui_print "ril Enables amr wide band "
sleep 1

ui_print "Boost config vc call steps"
sleep 1

ui_print "Boost voice call clarity catcher"
sleep 1

ui_print "Improved panorama shots"
sleep 1

ui_print "Boost media panorama defres"
sleep 1

ui_print "Optimize panorama shots"
sleep 1

ui_print "Improved caching shots one by one for panorama"
sleep 1

ui_print "Boost media panorama frameres"
sleep 1

ui_print "Boost streaming videos load faster"
sleep 1

ui_print "Boost media stage fright for player"
sleep 1

ui_print "Boost media stage fright for meta"
sleep 1

ui_print "Boost media stage fright for scan "
sleep 1

ui_print "Boost media stage fright for http"
sleep 1

ui_print "Boost media stage fright for rtsp"
sleep 1

ui_print "Boost media stage fright for record"
sleep 1

ui_print "Reduce animation on players for faster load videos"
sleep 1

ui_print "Reduce time opening sound while on player"
sleep 1

ui_print "Reduce time closing sound while on player"
sleep 1

ui_print "Gives support on ipv6"
sleep 1

ui_print "Gives support on ipv4"
sleep 1

ui_print "Boost capturing sig for ipv6"
sleep 1

ui_print "Boost capturing sig for ipv4"
sleep 1

ui_print "Enables telephony sup ipv6"
sleep 1

ui_print "Enables telephony sup ipv4"
sleep 1

ui_print "Boost full media"
sleep 1

ui_print "Boost jpeg quality"
sleep 1

ui_print "Boost jpeg memcap "
sleep 1

ui_print "Boost hprof vid vps"
sleep 1

ui_print "Enables aud wma"
sleep 1

ui_print "Boost aud wma" 
sleep 1

ui_print "Enables vid wmv" 
sleep 1

ui_print "Boost cam pr view"
sleep 1

ui_print "Enables codec priority thumb"
sleep 1


#NASA UI AND GPU NAAKO 

#REMAINING FEATURES SOON 100+ FEATURES NOT included 


ui_print "OPTIMIZING SYSTEM...."
sleep 5
ui_print "ENABLING ALL RESOURCES...."
ui_print ""
sleep 3
ui_print "REMOVING UNNEEDED FILES...."
sleep 2
ui_print "OPERATION COMPLETE"
sleep 1

ui_print "dont do any operation...."
ui_print ""
ui_print ""
ui_print "Loading…"
ui_print ""
sleep 5
ui_print "█▒▒▒▒▒▒▒▒▒"
ui_print ""
sleep 4
ui_print ""
ui_print "10%"
ui_print "███▒▒▒▒▒▒▒"
ui_print ""
sleep 6
ui_print ""
ui_print "30%"
ui_print "█████▒▒▒▒▒"
sleep 4
ui_print ""
ui_print "50%"
ui_print "███████▒▒▒"
ui_print ""
sleep 3
ui_print ""
ui_print "100%"
ui_print "██████████"
sleep 2
ui_print ""
sleep 10
ui_print "done"


