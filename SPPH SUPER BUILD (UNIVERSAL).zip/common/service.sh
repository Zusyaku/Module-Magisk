#!/system/bin/sh
write()
  # Check the file if existing to avoid error writes
  if [ -f "$1" ]; then
    # Make the file writable if it wasn't
    chmod +w "$1" 2>/dev/null
    # Set the parameter
    echo "$2" > "$1"
  fi
}

append() {
  # Check the file if existing to avoid error writes
  if [ -f "$1" ]; then
    # Make the file writable if it wasn't
    chmod +w "$1" 2>/dev/null
    # Append to file
    echo "$2" >> "$1"
  fi
}

# Setup and use magisk busybox
BB=/data/adb/magisk/busybox

# charging service 2750mA / 46°C 
sleep 10
chmod 777 /sys/class/power_supply/*/*
chmod 777 /sys/module/qpnp_smbcharger/*/*
chmod 777 /sys/module/dwc3_msm/*/*
chmod 777 /sys/module/phy_msm_usb/*/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '150' > /sys/class/power_supply/bms/temp_cool
echo '460' > /sys/class/power_supply/bms/temp_hot
echo '460' > /sys/class/power_supply/bms/temp_warm
echo '2750000' > /sys/class/power_supply/usb/current_max
echo '2750000' > /sys/class/power_supply/usb/hw_current_max
echo '2750000' > /sys/class/power_supply/usb/pd_current_max
echo '2750000' > /sys/class/power_supply/usb/ctm_current_max
echo '2750000' > /sys/class/power_supply/usb/sdp_current_max
echo '2750000' > /sys/class/power_supply/main/current_max
echo '2750000' > /sys/class/power_supply/main/constant_charge_current_max
echo '2750000' > /sys/class/power_supply/battery/current_max
echo '2750000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '4600000' > /sys/class/qcom-battery/restricted_current
echo '2750000' > /sys/class/power_supply/pc_port/current_max
echo '2750000' > /sys/class/power_supply/constant_charge_current__max

# Disable collective Device administrators
pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver

# Disable GMS and IMS run in startup and restart it on boot
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore

# Disable GMS and IMS run in startup and restart it on boot (custom permissions for Oxygen OS)
cmd appops set com.google.android.gms AUTO_START ignore
cmd appops set com.google.android.ims AUTO_START ignore

# DNS [CloudFlare]
resetprop net.rmnet0.dns1 1.1.1.1
resetprop net.rmnet0.dns2 1.0.0.1
resetprop net.rmnet1.dns1 1.1.1.1
resetprop net.rmnet1.dns2 1.0.0.1
resetprop net.dns1 1.1.1.1
resetprop net.dns2 1.0.0.1
resetprop net.wcdma.dns1 1.1.1.1
resetprop net.wcdma.dns2 1.0.0.1
resetprop net.hspa.dns1 1.1.1.1
resetprop net.hspa.dns2 1.0.0.1
resetprop net.lte.dns1 1.1.1.1
resetprop net.lte.dns2 1.0.0.1
resetprop net.ltea.dns1 1.1.1.1
resetprop net.ltea.dns2 1.0.0.1
resetprop net.ppp0.dns1 1.1.1.1
resetprop net.ppp0.dns2 1.0.0.1
resetprop net.pdpbr1.dns1 1.1.1.1
resetprop net.pdpbr1.dns2 1.0.0.1
resetprop net.wlan0.dns1 1.1.1.1
resetprop net.wlan0.dns2 1.0.0.1
resetprop 2606:4700:4700::1111
resetprop 2606:4700:4700::1001

$BB mkdir -p $MODDIR/system/etc
append $MODDIR/system/etc/resolv.conf "nameserver 1.1.1.1"
append $MODDIR/system/etc/resolv.conf "nameserver 1.0.0.1"

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53

# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 75
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor performance
write /sys/class/kgsl/kgsl-3d0/devfreq/governor msm-adreno-tz
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /dev/cpuset/foreground/cpus 0-3,4-7
write /dev/cpuset/foreground/boost/cpus 4-7
write /dev/cpuset/top-app/cpus 0-7

#Turn Off Swap
swapoff /dev/block/zram0
#
# Resetting ZRAM
echo 1 > /sys/block/zram0/reset
#
# Setting 4 GB ZRAM
echo 4192000000 > /sys/block/zram0/disksize
#
# Making ZRAM Swapable
mkswap /dev/block/zram0
#
# Starting Swap On ZRAM
swapon /dev/block/zram0
#
# Setting Low Memory Killer Parameters According To Total Memory
echo "256,10240,32000,34000,36000,38000" > /sys/module/lowmemorykiller/parameters/minfree
#
# Setting Swappiness To 100
echo 100 > /proc/sys/vm/swappiness
#
# done
#
free

cat /sys/module/lowmemorykiller/parameters/minfree

# Always end with success status
exit 0
