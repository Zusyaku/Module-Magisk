echo ". ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "             © ASMODEUS      ™       GOD ©"
echo ".━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"
echo "           ♛ WE OPTIMIZE YOUR GAME 4 YOU♛"
echo "             ♛ TELEGRAM : @IWillBanYou♛ "
echo "                 ♛ MODDER :ASMODEUS♛            "
echo "               ♛ TELEGRAM CHANNEL : @AsmodeusFiles♛
"
echo ".━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "            © ASMODEUS       ™       GOD ©"
echo ".━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 2

sleep 3
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config
echo "
START PATCHING PUBG MOBILE KOREA"
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config
echo "[/Script/ShadowTrackerExtra.UAETriggerFuncLib.Object]
+ClassItemList=0x0
+DataSet=0x0
+GetLastIteratorActor=0x0
[/Script/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*]
16384=0
nill
null
exit
exits
[/Script/UAE.Client.BuildConfig]
branch_name=trunk
[/Script/Client.TssManager]
!TssHostInfo=
TssBuildInIpInfo="127.0.0.1"
TssBuildInIpInfo="111.111.111"
TssBuildInIpInfo="8080"
[/Script/ShadowTrackerExtra.MoveAntiCheatComponent]
bIsForceAdjustZWhenExceed = False
[/Script/ShadowTrackerExtra.STCharacterMovementComponent]
bServerMoveCheckPassWall = False
[/Script/LuaDebugger.DebuggerSetting]
bOpenHotUpdate=True
[/Script/Client.LuaClassObj]
bClearSourceCodeAfterInitialized=False
[/Script/Gameplay.UAEAdvertisementActor]
NetCullDistance=False "> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/UserUAE.ini
echo "[SystemSettings]
r.AllowHDR
r.Vsync=0
r.PUBGMaxSupportQualityLevel=3
r.PUBGDeviceFPSLow=90
r.PUBGDeviceFPSMid=90
r.PUBGDeviceFPSHigh=90
r.PUBGDeviceFPSHDR=90
r.PUBGDeviceFPSUltraHDR=90
r.UserQualitySetting=2
r.UserShadowSwitch=1
r.ShadowQuality=1
r.MobileContentScaleFactor=1
r.UserVulkanSetting=0
r.MobileHDR=0.0
r.Mobile.SceneColorFormat=0.0
r.UserHDRSetting=2
r.ACESStyle=2
r.UserMSAASetting=0
r.DefaultFeature.AntiAliasing=0.0
r.MobileMSAA=1.0
r.MSAACount=4.0
r.MaterialQualityLevel=1
r.Shadow.MaxCSMResolution=1024
r.Shadow.CSM.MaxMobileCascades=2
r.Shadow.DistanceScale=0.5
r.Mobile.DynamicObjectShadow=1
r.DepthOfFieldQuality=0
r.RefractionQuality=0
r.StaticMeshLODDistanceScale=0.8
foliage.LODDistanceScale=1.0
foliage.MinLOD=0
r.DetailMode=2
r.MaxAnisotropy=4
r.Streaming.PoolSize=300
r.EmitterSpawnRateScale=1.0
r.ParticleLODBias=0
r.MobileNumDynamicPointLights=1
diy.SetDecalBakingRTSizeInLobby=1024
r.PUBGVersion=5
r.MobileSimpleShader=0
[ScalabilityGroups]
sg.ResolutionQuality=90
sg.ViewDistanceQuality=4
sg.AntiAliasingQuality=4
sg.ShadowQuality=1
sg.PostProcessQuality=3
sg.TextureQuality=5
sg.EffectsQuality=2
sg.FoliageQuality=2
sg.TrueSkyQuality=1
sg.GroundClutterQuality=1
sg.IBLQuality=0
sg.FrameRateLimit=55
sg.FrameRateCap=1
sg.MSAA.CompositingSampleCount=1
[/Script/Engine.RendererOverrideSettings]
r.CapsuleShadows
r.CapsuleMinSkyAngle "> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/UserEngine.ini
echo "[/Script/lib/LibUE4.so]
byte ClientHitPartJudgment;//[Offset: 99999 , Size: 1] "> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/UserLibUE4.so.ini
echo "[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
sizeofFPlayerHitInfo=Max
static_assert(FPlayerHitInfo)=0
FPlayerHitInfo_Hits_Offset=Max
static_assert(FPlayerHitInfo_Hits_Offset)=Max
FPlayerHitInfo_Damages_Offset=Max
static_assert(FPlayerHitInfo_Damages_Offset)=Max
FPlayerHitInfo_Kills_Offset=Max
FPlayerHitInfo_Kills_Offset=8
ShootMode(Damage)=7.4
CurShootID(ID)=5
CurBulletNumInClip(Damage)=5
(float)StartFireTime=Max
(double)StartFireSysTime=910
WeaponHitDisanceSectionArray=6
BulletFireSpeed=9.0F
[/Script/ShadowTrackerExtra.SettingConfig_C.SaveGame]
r.CrossHairColor=0x21
r.AimAssist=Max
r.HitFeedBack=4
r.LeftRightShoot=4
r.IntelligentDrugs=0
r.LeftHandFire=3
r.3DTouchSwitcher=0
r.3DTouchValue=0
r.TurboLastQuality=0
FString[]=ExcludeComponentsList_DS=0
FString[]=ExcludeComponentsList_Autonomous=0
FString[]=ExcludeComponentsList_Team=0
FString[]=ExcludeComponentsList_NonTeam=0
FString[]=ExcludeComponentsList_DSAI=0
FString[]=ExcludeComponentsList_ClientAI=0
FString[]=ExcludeComponentsList_Standalone=0
FString[]=ExcludeComponentsList_StandaloneAI=0
BulletFireSpeed=9.0F
[/Script/ShadowTrackerExtra.STExtraFireBalloon]
MovementSmoothMode=9.0
MovementSmoothAlpha=9.0
BulletFireSpeed=9.0
[ShootTimeData]
ShootPos=0
CapsuleHalfHeight=0
ShootTimeConDelta=9.4F
[WeaponAttrReloadTableStruct]
AccessoriesVRecoilFactor=0
AccessoriesHRecoilFactor=0
(float)HitPartCoffHead=4F
(float)HitPartCoffBody=4F
(float)HitPartCoffLimbs=4F
(float)MaxBulletNumInOneClip=Max
BulletFireSpeed=9F
[SeekAndLockRPGBulletUploadData]
SeekAndLockStageType=94.5
SeekAndLockTarget=0x51
[DeviceInfo]
GPUFamily=0
GLVersion=1.1.0
OSVersion=0
DeviceMake=0
DeviceModel=0
VulkanVersion=0
MemorySizeInGB=0
[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
sbc.ClientHitPartJudgment=Max
[ClientSettingBaseOnGameMode]
r.bEnableBulletImpactFXTargetCullingByQualityLevel=0
r.BulletImpactFXTargetCullingByQualityLeveConfigItem=1
bBulletImpactFXAttachToTarget=3
[SceneCaptureComponent2D]
ProjectionType=2
CaptureSource=5
CompositeMode=7
[WeaponAnimAsset]
WeaponName=0
---------------------------------------------------
(Class)UAELobbyGameMode.UAEClientGameMode.GameMode.GameModeBase.Info.Actor.Object=0
---------------------------------------------------
(Class)UAEClientGameMode.GameMode.GameModeBase.Info.Actor.Object=0
---------------------------------------------------
(Class)AbstractNavData.NavigationData.Actor.Object=0
---------------------------------------------------"> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/UserGame.ini

echo " 
You patched PUBG MOBILE KOREA"
sleep 2
echo "
BROUGHT TO YOU BY @AsmodeusFiles"
sleep 3
echo "
CRACKERS FUCK OFF,NEXT TIME I ENCRYPT BASH SCRIPT"
sleep 2
echo "
ASMODEUS YOUR GOD"
sleep 2
echo ".           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                        © ASMODEUS      ™       GOD ©"
echo ".           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"
echo "                         ♛ WE OPTIMIZE YOUR GAME 4 YOU♛"
echo "                         ♛ TELEGRAM : @IWillBanYou♛ "
echo "                         ♛ MODDER :ASMODEUS♛            "
echo "                         ♛ TELEGRAM CHANNEL : @AsmodeusFiles♛
"
echo ".           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                         © ASMODEUS       ™       GOD ©"
echo ".           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
