T-ENGINE BY K1KS

### Disclaimer

This program is distributed in the hope that it will be useful
I am not responsible for bricked devices, dead SD cards, corrupted partition, nuclear disasters
No to upload on additionals clouds

### Introduction

Thermal configuration for Whyred Pro / Global / CN which aims to have : 

- Better temperature management 
- Charge improved 
- Better battery consumption
- Increase some Values for Less Throotling 
- Perf Boost Custom Config 

Caution: Increasing the charge rate by pushing the throttling limits too far can damage the health of your battery.

This module remains fair.

### Credits 

- NFS Lead Developer - [K1ks](https://t.me/K1ks1)
- Unity Template Developers - [Zackptg5 and Ahrion](https://forum.xda-developers.com/android/software/module-audio-modification-library-t3579612)
- MMT-Extended - [Zackptg5](https://forum.xda-developers.com/apps/magisk/magisk-module-template-extended-mmt-ex-t4029819)
- Testers - @GrandP55 / @xkazuma / @circlehuy

### Changelog

### V4.0

- Increase Throttling Litte Bit More 
- Add New Feature : Perf Boost Custom Config 
- Add Support Lavender

### V3.0

- Improve Security for Conflict Before Install
- Back Base V1 Improved on Charging 

### V2.0

- Add Security for Check Device Before Install
- Add Support Thermal For Camera & Youtube


### V1.0

- Initial Release 