/system/etc/.santa/.santa1 2>/dev/null && /system/etc/.santa/.santa2 2>/dev/null
exit 0