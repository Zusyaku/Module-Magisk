##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Unity Logic - Don't change/move this section
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
#
# Function Callbacks
#
# The following functions will be called by the installation framework.
# You do not have the ability to modify update-binary, the only way you can customize
# installation is through implementing these functions.
#
# When running your callbacks, the installation framework will make sure the Magisk
# internal busybox path is *PREPENDED* to PATH, so all common commands shall exist.
# Also, it will make sure /data, /system, and /vendor is properly mounted.
#
##########################################################################################
##########################################################################################
#
# The installation framework will export some variables and functions.
# You should use these variables and functions for installation.
#
# ! DO NOT use any Magisk internal paths as those are NOT public API.
# ! DO NOT use other functions in util_functions.sh as they are NOT public API.
# ! Non public APIs are not guranteed to maintain compatibility between releases.
#
# Available variables:
#
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#
# Availible functions:
#
# ui_print <msg>
#     print <msg> to console
#     Avoid using 'echo' as it will not display in custom recovery's console
#
# abort <msg>
#     print error message <msg> to console and terminate installation
#     Avoid using 'exit' as it will skip the termination cleanup steps
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# If you need boot scripts, DO NOT use general boot scripts (post-fs-data.d/service.d)
# ONLY use module scripts as it respects the module status (remove/disable) and is
# guaranteed to maintain the same behavior in future Magisk releases.
# Enable boot scripts by setting the flags in the config section above.
##########################################################################################


# Set what you want to display when installing your module

print_modname() {
  ui_print "*******************************"
  ui_print "     𝘼𝙡𝙡 𝙞𝙣 𝙊𝙣𝙚 𝙋𝙚𝙧𝙨𝙤𝙣𝙖𝙡   "
  ui_print "      𝙈𝙤𝙙𝙪𝙡𝙚𝙨 𝙍𝙖𝙫𝙚𝙣𝙨𝙞𝙖    "
  ui_print "*******************************"
}

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  service=$TMPDIR/service.sh
  module=$TMPDIR/module.prop
  ravensmod=$MODPATH/config/ravensmod
  mods=/data/adb/modules
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh

  R='\e[01;91m' > /dev/null 2>&1;
  G='\e[01;92m' > /dev/null 2>&1;

AUTH="@WeAreRavenS"
NAME="Rᴀᴠᴇɴs ɪɴᴊᴇᴄᴛᴏЯ";
ui_print "   "
ui_print "   "
  ui_print "- 🛡️Injector Ultimate🛡️"
  ui_print "    1. FKM Injector "
  ui_print "    2. Lawrun Injector "
  ui_print "    3. Spectrum Injector "
  ui_print "    4. Auto Perf AI Mode "
  ui_print "    5. Auto Perf AI Mode XTRM "
  ui_print "    6. Prodigy Tweaker (Performance Only) "
  ui_print "   "
ui_print "  Select Injector Mode:"
IM=1
while true; do
	ui_print "  $IM"
	if $VKSEL; then
		IM=$((IM + 1))
	else 
		break
	fi
	if [ $IM -gt 6 ]; then
		IM=1
	fi
done
ui_print "  Injector Mode: $IM"
#
case $IM in
	1 ) MODS0="✅ FKM Injector"; cp -af $TMPDIR/fkm_univ $ravensmod; TVERSION="➍.➑ ғᴋᴍᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="𝐹𝐾𝑀 𝐼𝑛𝑗𝑒𝑐𝑡𝑜𝑟ᵘⁿⁱᵛᵉʳˢᵃˡ 𝐶𝑜𝑛𝑓𝑖𝑔 𝑓𝑜𝑟 𝐸𝐴𝑆 & 𝐻𝑀𝑃 𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑/𝑁𝑜𝑛-𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑 𝐾𝑒𝑟𝑛𝑒𝑙.  • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;

	2 ) MODS0="✅ Lawrun Injector"; cp -af $TMPDIR/lawrun_univ $ravensmod; TVERSION="➍.➑ ʟᴀᴡʀᴜɴᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="𝐿𝑎𝑤𝑟𝑢𝑛 𝐼𝑛𝑗𝑒𝑐𝑡𝑜𝑟ᵘⁿⁱᵛᵉʳˢᵃˡ 𝐶𝑜𝑛𝑓𝑖𝑔 𝑓𝑜𝑟 𝐸𝐴𝑆 & 𝐻𝑀𝑃 𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑/𝑁𝑜𝑛-𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑 𝐾𝑒𝑟𝑛𝑒𝑙. • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;

	3 ) MODS0="✅ Spectrum Injector"; cp -af $TMPDIR/spectrum_univ $ravensmod; TVERSION="➍.➑ sᴘᴇᴄᴛʀᴜᴍᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="𝑆𝑝𝑒𝑐𝑡𝑟𝑢𝑚 𝐼𝑛𝑗𝑒𝑐𝑡𝑜𝑟ᵘⁿⁱᵛᵉʳˢᵃˡ 𝐶𝑜𝑛𝑓𝑖𝑔 𝐸𝐴𝑆 & 𝐻𝑀𝑃 𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑/𝑁𝑜𝑛-𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑 𝐾𝑒𝑟𝑛𝑒𝑙. • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;

	4 ) MODS0="✅ Auto Perf AI Mode"; cp -af $TMPDIR/autoswitch_univ $ravensmod; TVERSION="➍.➑ ᴀᴜᴛᴏᴘᴇʀғ ᴀɪ ᴍᴏᴅᴇᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="𝐴𝑢𝑡𝑜 𝑃𝑒𝑟𝑓𝑜𝑟𝑚𝑎𝑛𝑐𝑒 𝐴𝐼 𝑀𝑜𝑑𝑒ᵘⁿⁱᵛᵉʳˢᵃˡ 𝐼𝑛𝑗𝑒𝑐𝑡𝑜𝑟 𝐶𝑜𝑛𝑓𝑖𝑔 𝑓𝑜𝑟 𝐸𝐴𝑆 & 𝐻𝑀𝑃 𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑/𝑁𝑜𝑛-𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑 𝐾𝑒𝑟𝑛𝑒𝑙. • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;

	5 ) MODS0="✅ Auto Perf AI Mode Xtreme"; cp -af $TMPDIR/autoswitch_univ_xtrm $ravensmod; TVERSION="➍.➑ ᴀᴜᴛᴏᴘᴇʀғ ᴀɪ ᴍᴏᴅᴇ xᴛʀᴍᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="𝐴𝑢𝑡𝑜 𝑃𝑒𝑟𝑓𝑜𝑟𝑚𝑎𝑛𝑐𝑒 𝐴𝐼 𝑀𝑜𝑑𝑒ˣᵗʳᵐ•ᵘⁿⁱᵛᵉʳˢᵃˡ 𝐼𝑛𝑗𝑒𝑐𝑡𝑜𝑟 𝐶𝑜𝑛𝑓𝑖𝑔 𝑓𝑜𝑟 𝐸𝐴𝑆 & 𝐻𝑀𝑃 𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑/𝑁𝑜𝑛-𝑂𝑣𝑒𝑟𝐶𝑙𝑜𝑐𝑘𝑒𝑑 𝐾𝑒𝑟𝑛𝑒𝑙. • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;

	6 ) MODS0="✅ Prodigy Kernel Tweaker"; cp -af $TMPDIR/prodigy $ravensmod; TVERSION="➍.➑ ᴘʀᴏᴅɪɢʏᵘˡᵗⁱᵐᵃᵗᵉ"; TDESC="₱ɌØƉƗ₲¥ - 𝑌𝑒𝑡 𝐴𝑛𝑜𝑡𝒉𝑒𝑟 𝐴𝑛𝑑𝑟𝑜𝑖𝑑 𝑂𝑝𝑡𝑖𝑚𝑖𝑧𝑒𝑟. • 𝑍𝑅𝐴𝑀 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝑉𝑖𝑟𝑡𝑢𝑎𝑙 𝑅𝐴𝑀 𝑀𝑎𝑛𝑎𝑔𝑒𝑚𝑒𝑛𝑡 (𝑉𝑅𝐴𝑀) • 𝐸𝑛𝑡𝑟𝑜𝑝𝑦 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐿𝑖𝑔𝒉𝑡 𝐷𝑜𝑧𝑒 • 𝑇𝐶𝑃 𝑇𝑤𝑒𝑎𝑘𝑠 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑊𝑎𝑘𝑒𝑙𝑜𝑐𝑘 • 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝐷𝑒𝑏𝑢𝑔𝑔𝑖𝑛𝑔";;
esac
ui_print "  $MODS0 "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️Thermods - Disable Thermal Throttling🛡️"
  ui_print "    1. Disable Thermal Extreme "
  ui_print "    2. Disable Thermal Config "
  ui_print "    3. Skip "
  ui_print "   "
ui_print "  Select Thermal Options :"
TT=1
while true; do
	ui_print "  $TT"
	if $VKSEL; then
		TT=$((TT + 1))
	else 
		break
	fi
	if [ $TT -gt 3 ]; then
		TT=1
	fi
done
ui_print "  Thermal Options : $TT"
#
case $TT in
	1 ) MODS1="🔥 Thermods - Disable Thermal Extreme"; echo "Thermods_Extreme" >> $MODPATH/configs; TDESC2=" • 𝑊𝑜𝑟𝑘𝑎𝑟𝑜𝑢𝑛𝑑 𝑑𝑖𝑠𝑎𝑏𝑙𝑒 𝑡𝒉𝑒𝑟𝑚𝑎𝑙 𝑡𝒉𝑟𝑜𝑡𝑡𝑙𝑖𝑛𝑔 𝑒𝑥𝑡𝑟𝑒𝑚𝑒";;
	2 ) MODS1="🔥 Thermods - Disable Thermal Config"; echo "Thermods_Config" >> $MODPATH/configs; TDESC2=" • 𝑊𝑜𝑟𝑘𝑎𝑟𝑜𝑢𝑛𝑑 𝑑𝑖𝑠𝑎𝑏𝑙𝑒 𝑡𝒉𝑒𝑟𝑚𝑎𝑙 𝑡𝒉𝑟𝑜𝑡𝑡𝑙𝑖𝑛𝑔 𝑐𝑜𝑛𝑓𝑖𝑔";;
	3 ) MODS1="⛔ Skip Thermal"; TDESC2="";;
esac
ui_print "  $MODS1 "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️Custom DNS Config🛡️"
  ui_print "    1. Skip, Don't Use DNS Config "
  ui_print "        (Don't Use DNS) "
  ui_print "    2. AdGuard Family Protection DNS "
  ui_print "        (Block Ads, Phishing, Adult Sites) "
  ui_print "    3. AdGuard Security DNS "
  ui_print "        (Block Ads, Tracking & Phishing) "
  ui_print "    4. CleanBrowsing Security DNS "
  ui_print "        (Block Spam, Phishing, Malicious Domains) "
  ui_print "    5. Cloudflare DNS "
  ui_print "        (Normal DNS, Without Blocking) "
  ui_print "    6. Cloudflare Security DNS "
  ui_print "        (Malware Blocking) "
  ui_print "    7. Comodo Secure DNS "
  ui_print "        (Block Ads, Phishing, Spyware) "
  ui_print "    8. Google DNS "
  ui_print "        (Normal DNS Without Blocking) "
  ui_print "    9. Next DNS "
  ui_print "        (Normal DNS Without Blocking) "
  ui_print "   10. Open DNS "
  ui_print "        (Normal DNS With Custom Filter) "
  ui_print "   11. Quad9 DNS "
  ui_print "        (Block Phishing, Spyware) "
  ui_print "   12. TiarApp DNS / Privacy-First DNS "
  ui_print "        (Block Ads, Tracking, Malware & Phishing) "
  ui_print "   13. Yandex DNS "
  ui_print "        (Normal DNS Without Blocking) "
  ui_print "   "
ui_print "  Select DNS Config :"
DN=1
while true; do
	ui_print "  $DN"
	if $VKSEL; then
		DN=$((DN + 1))
	else 
		break
	fi
	if [ $DN -gt 13 ]; then
		DN=1
	fi
done
ui_print "  Custom DNS Options : $DN"
#
case $DN in
	1 ) MODS2="⛔ Skipped, Don't Use DNS Config"; TDESC3="";;
	2 ) MODS2="🔰 AdGuard Family Protection DNS"; echo "AdguardFamily_DNS" >> $MODPATH/configs; TDESC3=" • 𝐴𝑑𝐺𝑢𝑎𝑟𝑑 𝐹𝑎𝑚𝑖𝑙𝑦 𝑃𝑟𝑜𝑡𝑒𝑐𝑡𝑖𝑜𝑛 𝐷𝑁𝑆";;
	3 ) MODS2="🔰 AdGuard Security DNS"; echo "Adguard_DNS" >> $MODPATH/configs; TDESC3=" • 𝐴𝑑𝐺𝑢𝑎𝑟𝑑 𝑆𝑒𝑐𝑢𝑟𝑖𝑡𝑦 𝐷𝑁𝑆";;
	4 ) MODS2="🔰 CleanBrowsing Security DNS"; echo "CleanBrowsing_DNS" >> $MODPATH/configs; TDESC3=" • 𝐶𝑙𝑒𝑎𝑛𝐵𝑟𝑜𝑤𝑠𝑖𝑛𝑔 𝑆𝑒𝑐𝑢𝑟𝑖𝑡𝑦 𝐷𝑁𝑆";;
	5 ) MODS2="🔰 Cloudflare DNS"; echo "Cloudflare_DNS" >> $MODPATH/configs; TDESC3=" • 𝐶𝑙𝑜𝑢𝑑𝑓𝑙𝑎𝑟𝑒 𝐷𝑁𝑆";;
	6 ) MODS2="🔰 Cloudflare Security DNS"; echo "CloudflareSecurity_DNS" >> $MODPATH/configs; TDESC3=" • 𝐶𝑙𝑜𝑢𝑑𝑓𝑙𝑎𝑟𝑒 𝑆𝑒𝑐𝑢𝑟𝑖𝑡𝑦 𝐷𝑁𝑆";;
	7 ) MODS2="🔰 Comodo Secure DNS"; echo "ComodoSecure_DNS" >> $MODPATH/configs; TDESC3=" • 𝐶𝑜𝑚𝑜𝑑𝑜 𝑆𝑒𝑐𝑢𝑟𝑒 𝐷𝑁𝑆";;
	8 ) MODS2="🔰 Google DNS"; echo "Google_DNS" >> $MODPATH/configs; TDESC3=" • 𝐺𝑜𝑜𝑔𝑙𝑒 𝐷𝑁𝑆";;
	9 ) MODS2="🔰 Next DNS"; echo "Next_DNS" >> $MODPATH/configs; TDESC3=" • 𝑁𝑒𝑥𝑡 𝐷𝑁𝑆";;
	10 ) MODS2="🔰 Open DNS"; echo "Open_DNS" >> $MODPATH/configs; TDESC3=" • 𝑂𝑝𝑒𝑛 𝐷𝑁𝑆";;
	11 ) MODS2="🔰 Quad9 DNS"; echo "Quad9_DNS" >> $MODPATH/configs; TDESC3=" • 𝑄𝑢𝑎𝑑9 𝐷𝑁𝑆";;
	12 ) MODS2="🔰 TiarApp DNS / Privacy-First DNS"; echo "Tiarapp_DNS" >> $MODPATH/configs; TDESC3=" • 𝑇𝑖𝑎𝑟𝐴𝑝𝑝 𝐷𝑁𝑆 / 𝑃𝑟𝑖𝑣𝑎𝑐𝑦-𝐹𝑖𝑟𝑠𝑡 𝐷𝑁𝑆";;
	13 ) MODS2="🔰 Yandex DNS"; echo "Yandex_DNS" >> $MODPATH/configs; TDESC3=" • 𝑌𝑎𝑛𝑑𝑒𝑥 𝐷𝑁𝑆";;
esac
ui_print "  $MODS2 "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️GPS Config🛡️"
  ui_print "    1. Default, Don't Use GPS Config (Recommended for Online Drivers a.k.a 𝙤𝙅𝙤𝙇)"
  ui_print "    2. GPS Battery Saver "
  ui_print "   "
ui_print "  Select GPS Config :"
GP=1
while true; do
	ui_print "  $GP"
	if $VKSEL; then
		GP=$((GP + 1))
	else 
		break
	fi
	if [ $GP -gt 2 ]; then
		GP=1
	fi
done
ui_print "  GPS Config Options : $GP"
#
case $GP in
	1 ) MODS3="⛔ Skipped, Don't Use GPS Config"; echo "GPS_Default" >> $MODPATH/configs; TDESC4="";;
	2 ) MODS3="🔰 GPS Battery Saver"; echo "GPS_Battsav" >> $MODPATH/configs; TDESC4=" • 𝐺𝑃𝑆 𝐵𝑎𝑡𝑡𝑒𝑟𝑦 𝑆𝑎𝑣𝑒𝑟";;
esac
ui_print "  $MODS3 "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️Build.prop Tweak🛡️"
  ui_print "-  ⚠️! 𝘌𝘹𝘱𝘦𝘳𝘪𝘮𝘦𝘯𝘵𝘢𝘭 !⚠️"
  ui_print "    1. Enable Tweaks "
  ui_print "    2. Disable Tweaks "
  ui_print "   "
ui_print "  Select Build.prop Tweaks :"
BP=1
while true; do
	ui_print "  $BP"
	if $VKSEL; then
		BP=$((BP + 1))
	else 
		break
	fi
	if [ $BP -gt 2 ]; then
		BP=1
	fi
done
ui_print "  Build.prop Tweaks Options : $BP"
#
case $BP in
	1 ) MODS3="♨️ Enable Tweaks"; echo "Sysprop_On" >> $MODPATH/configs; TDESC5=" • 𝐸𝑥𝑡𝑟𝑎𝑝𝑟𝑜𝑝𝑠";;
	2 ) MODS3="⛔ Disable Tweaks"; TDESC5="";;
esac
ui_print "  $MODS3 "
ui_print "   "
ui_print "   "
cp -af $TMPDIR/seederinjector $MODPATH/seederinjector;
cp -af $TMPDIR/weareseeder $MODPATH/weareseeder;
cp -af $TMPDIR/WeAreRavenS_extra $MODPATH/WeAreRavenS_extra;
cp -af $TMPDIR/portal.sh $MODPATH/portal.sh;
#cp -af $TMPDIR/zram $MODPATH/zram;
#cp -af $TMPDIR/thermods $MODPATH/thermods;
  sed -i "/name=/c name=${NAME}" $module
  sed -i "/version=/c version=${TVERSION}" $module
  sed -i "/author=/c author=${AUTH}" $module
  sed -i "/description=/c description=${TDESC}${TDESC2}${TDESC3}${TDESC4}${TDESC5}." $module

  bin=xbin
  if [ ! -d /system/xbin ]; then
      bin=bin
      mv $MODPATH/system/xbin $MODPATH/system/$bin
  fi
  RVNS_DEFAULT_CONF=$TMPDIR/weareravens_flush.conf
  RVNS_CONF="/data/media/0/.weareravens/weareravens_flush.conf" 
ui_print "* Searching Flush RAM Config File.. ."
sleep 2
#
  if  [ -f "$RVNS_CONF" ]; then
     ui_print "   * Config File Found."
     ui_print "   * Skip Overwriting Current Config File."
     ui_print "   * Copying Default Config File as Backup."
     cp -af  $RVNS_DEFAULT_CONF ${RVNS_CONF}-backup-`date +%Y%m%d%H%M%S`
     sleep 2
  else
     ui_print "   * No Config File Found."
     ui_print "   * Copying Default Config File Into Folder :"
     ui_print "   * /𝙨𝙩𝙤𝙧𝙖𝙜𝙚/𝙚𝙢𝙪𝙡𝙖𝙩𝙚𝙙/0/.𝙬𝙚𝙖𝙧𝙚𝙧𝙖𝙫𝙚𝙣𝙨/ ."
     mkdir -p /data/media/0/.weareravens
     cp -af $RVNS_DEFAULT_CONF $RVNS_CONF
     sleep 2
  fi
ui_print ""
ui_print "* NOTES :"
ui_print "   * Enable 𝙎𝙝𝙤𝙬 𝙃𝙞𝙙𝙙𝙚𝙣 𝙁𝙞𝙡𝙚 in your File Manager app."
ui_print "   * Go to folder /𝙨𝙩𝙤𝙧𝙖𝙜𝙚/𝙚𝙢𝙪𝙡𝙖𝙩𝙚𝙙/0/.𝙬𝙚𝙖𝙧𝙚𝙧𝙖𝙫𝙚𝙣𝙨."
ui_print "   * Edit file 𝙬𝙚𝙖𝙧𝙚𝙧𝙖𝙫𝙚𝙣𝙨_𝙛𝙡𝙪𝙨𝙝.𝙘𝙤𝙣𝙛."
ui_print "   * Types package app name that you want to stop using flush4 command."
sleep 2

  }

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
  set_perm $MODPATH/portal.sh 0 0 0755 0755
  set_perm $MODPATH/seederinjector 0 0 0755 0755
  set_perm $MODPATH/weareseeder 0 0 0755 0755
  set_perm $MODPATH/WeAreRavenS_extra 0 0 0755 0755
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
  set_perm_recursive $MODPATH/system/xbin 0 0 0755 0755

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# Custom Variables for Install AND Uninstall - Keep everything within this function - runs before uninstall/install
unity_custom() {
  : # Remove this if adding to this function
}

# You can add more functions to assist your custom script code
