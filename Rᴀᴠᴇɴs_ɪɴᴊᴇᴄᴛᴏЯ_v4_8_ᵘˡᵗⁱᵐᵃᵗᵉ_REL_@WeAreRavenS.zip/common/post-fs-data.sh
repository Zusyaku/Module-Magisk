z="
";Gz='$MOD';Ez='if [';Pz='a';Fz=' -e ';Az='MODD';Oz='n';Qz='fi';Hz='DIR/';Mz='a ];';Kz='enS_';Cz='{0%/';Dz='*}';Lz='extr';Nz=' the';Jz='eRav';Bz='IR=$';Iz='WeAr';
eval "$Az$Bz$Cz$Dz$z$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$z$Gz$Hz$Iz$Jz$Kz$Lz$Pz$z$Qz"