## Increase Volume Steps (MAGISK!!)
Increase Volume Steps like a boss!
Default volume steps value in this mod will be 30
You can customize your volume steps by doing this command in Terminal Emulator:

	vol_magisk

Which will then present you a menu and you can change it from there.
Rebooting is a must to make the change.