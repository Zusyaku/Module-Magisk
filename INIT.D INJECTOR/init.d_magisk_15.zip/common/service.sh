#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Simple init.d enabler by RXSMB Team - @korom42
# Init.d support
INITPATH=system/etc/init.d
sleep 5
mount -o rw,remount /system
mount -o rw,remount /system /system
if [ ! -d $INITPATH ] ; then
    mkdir $INITPATH
fi
chmod 755 $INITPATH
chmod 755 $INITPATH/*
busybox run-parts $INITPATH
umount /system