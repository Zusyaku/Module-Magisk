#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
##########################################################################################
# ⚡FusionTweaks⚡
# 1.0 (stable)
# by Hardro
##########################################################################################

# Schedutil Tweaks
if [ -f /sys/kernel/debug/sched_features ];
then
	echo 'NEXT_BUDDY' > /sys/kernel/debug/sched_features;
	echo 'TTWU_QUEUE' > /sys/kernel/debug/sched_features;
fi

# Virtual Memory Tweaks Set Config
stop perfd
echo '1' > /proc/sys/vm/reap_mem_on_sigkill;
echo '1' > /sys/module/lowmemorykiller/parameters/enable_lmk;
echo '1' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
echo '60' > /proc/sys/vm/vfs_cache_pressure;
echo '29615' > /proc/sys/vm/extra_free_kbytes;
echo '64' > /sys/block/loop0/queue/read_ahead_kb;
echo '64' > /sys/block/loop1/queue/read_ahead_kb;
echo '64' > /sys/block/loop2/queue/read_ahead_kb;
echo '64' > /sys/block/loop3/queue/read_ahead_kb;
echo '64' > /sys/block/loop4/queue/read_ahead_kb;
echo '64' > /sys/block/loop5/queue/read_ahead_kb;
echo '64' > /sys/block/loop6/queue/read_ahead_kb;
echo '64' > /sys/block/loop7/queue/read_ahead_kb;
echo '64' > /sys/block/loop8/queue/read_ahead_kb;
echo '64' > /sys/block/loop9/queue/read_ahead_kb;
echo '64' > /sys/block/loop10/queue/read_ahead_kb;
echo '64' > /sys/block/loop11/queue/read_ahead_kb;
echo '64' > /sys/block/loop12/queue/read_ahead_kb;
echo '64' > /sys/block/loop13/queue/read_ahead_kb;
echo '64' > /sys/block/loop14/queue/read_ahead_kb;
echo '64' > /sys/block/loop15/queue/read_ahead_kb;
echo '64' > /sys/block/mmcblk0/queue/read_ahead_kb;
echo '64' > /sys/block/mmcblk1/queue/read_ahead_kb;
echo '64' > /sys/block/ram0/queue/read_ahead_kb;
echo '64' > /sys/block/ram1/queue/read_ahead_kb;
echo '64' > /sys/block/ram2/queue/read_ahead_kb;
echo '64' > /sys/block/ram3/queue/read_ahead_kb;
echo '64' > /sys/block/ram4/queue/read_ahead_kb;
echo '64' > /sys/block/ram5/queue/read_ahead_kb;
echo '64' > /sys/block/ram6/queue/read_ahead_kb;
echo '64' > /sys/block/ram7/queue/read_ahead_kb;
echo '64' > /sys/block/ram8/queue/read_ahead_kb;
echo '64' > /sys/block/ram9/queue/read_ahead_kb;
echo '64' > /sys/block/ram10/queue/read_ahead_kb;
echo '64' > /sys/block/ram11/queue/read_ahead_kb;
echo '64' > /sys/block/ram12/queue/read_ahead_kb;
echo '64' > /sys/block/ram13/queue/read_ahead_kb;
echo '64' > /sys/block/ram14/queue/read_ahead_kb;
echo '64' > /sys/block/ram15/queue/read_ahead_kb;
echo '64' > /sys/block/vnswap0/queue/read_ahead_kb;
echo '64' > /sys/block/zram0/queue/read_ahead_kb;
echo '0' > /sys/block/loop0/queue/iostats;
echo '0' > /sys/block/loop1/queue/iostats;
echo '0' > /sys/block/loop2/queue/iostats;
echo '0' > /sys/block/loop3/queue/iostats;
echo '0' > /sys/block/loop4/queue/iostats;
echo '0' > /sys/block/loop5/queue/iostats;
echo '0' > /sys/block/loop6/queue/iostats;
echo '0' > /sys/block/loop7/queue/iostats;
echo '0' > /sys/block/loop8/queue/iostats;
echo '0' > /sys/block/loop9/queue/iostats;
echo '0' > /sys/block/loop10/queue/iostats;
echo '0' > /sys/block/loop11/queue/iostats;
echo '0' > /sys/block/loop12/queue/iostats;
echo '0' > /sys/block/loop13/queue/iostats;
echo '0' > /sys/block/loop14/queue/iostats;
echo '0' > /sys/block/loop15/queue/iostats;
echo '0' > /sys/block/mmcblk0/queue/iostats;
echo '0' > /sys/block/mmcblk1/queue/iostats;
echo '0' > /sys/block/ram0/queue/iostats;
echo '0' > /sys/block/ram1/queue/iostats;
echo '0' > /sys/block/ram2/queue/iostats;
echo '0' > /sys/block/ram3/queue/iostats;
echo '0' > /sys/block/ram4/queue/iostats;
echo '0' > /sys/block/ram5/queue/iostats;
echo '0' > /sys/block/ram6/queue/iostats;
echo '0' > /sys/block/ram7/queue/iostats;
echo '0' > /sys/block/ram8/queue/iostats;
echo '0' > /sys/block/ram9/queue/iostats;
echo '0' > /sys/block/ram10/queue/iostats;
echo '0' > /sys/block/ram11/queue/iostats;
echo '0' > /sys/block/ram12/queue/iostats;
echo '0' > /sys/block/ram13/queue/iostats;
echo '0' > /sys/block/ram14/queue/iostats;
echo '0' > /sys/block/ram15/queue/iostats;
echo '0' > /sys/block/zram0/queue/iostats;
echo '0' > /sys/block/vnswap0/queue/iostats;
echo '64' > /sys/block/mmcblk0/queue/nr_requests;
echo '64' > /sys/block/mmcblk1/queue/nr_requests;
echo '64' > /sys/block/loop0/queue/nr_requests;
echo '64' > /sys/block/loop1/queue/nr_requests;
echo '64' > /sys/block/loop2/queue/nr_requests;
echo '64' > /sys/block/loop3/queue/nr_requests;
echo '64' > /sys/block/loop4/queue/nr_requests;
echo '64' > /sys/block/loop5/queue/nr_requests;
echo '64' > /sys/block/loop6/queue/nr_requests;
echo '64' > /sys/block/loop7/queue/nr_requests;
echo '64' > /sys/block/loop8/queue/nr_requests;
echo '64' > /sys/block/loop9/queue/nr_requests;
echo '64' > /sys/block/loop10/queue/nr_requests;
echo '64' > /sys/block/loop11/queue/nr_requests;
echo '64' > /sys/block/loop12/queue/nr_requests;
echo '64' > /sys/block/loop13/queue/nr_requests;
echo '64' > /sys/block/loop14/queue/nr_requests;
echo '64' > /sys/block/loop15/queue/nr_requests;
echo '64' > /sys/block/ram0/queue/nr_requests;
echo '64' > /sys/block/ram1/queue/nr_requests;
echo '64' > /sys/block/ram2/queue/nr_requests;
echo '64' > /sys/block/ram3/queue/nr_requests;
echo '64' > /sys/block/ram4/queue/nr_requests;
echo '64' > /sys/block/ram5/queue/nr_requests;
echo '64' > /sys/block/ram6/queue/nr_requests;
echo '64' > /sys/block/ram7/queue/nr_requests;
echo '64' > /sys/block/ram8/queue/nr_requests;
echo '64' > /sys/block/ram9/queue/nr_requests;
echo '64' > /sys/block/ram10/queue/nr_requests;
echo '64' > /sys/block/ram11/queue/nr_requests;
echo '64' > /sys/block/ram12/queue/nr_requests;
echo '64' > /sys/block/ram13/queue/nr_requests;
echo '64' > /sys/block/ram14/queue/nr_requests;
echo '64' > /sys/block/ram15/queue/nr_requests;
echo '64' > /sys/block/vnswap0/queue/nr_requests;
echo '64' > /sys/block/zram0/queue/nr_requests;
echo '7686' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '30' > /proc/sys/vm/dirty_ratio;
echo '10' > /proc/sys/vm/dirty_background_ratio;
sleep 30
chmod 666 /sys/module/lowmemorykiller/parameters/minfree;
chown root /sys/module/lowmemorykiller/parameters/minfree;
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree;
rm /data/system/perfd/default_values;
start perfd

# Caf Cpu Boost
if [ -d /sys/module/cpu_boost/parameters ];
then
	echo '0:1600000' > /sys/module/cpu_boost/parameters/input_boost_freq;
	echo '64' > /sys/module/cpu_boost/parameters/input_boost_ms;
fi

# Other CPU Tweaks
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;

# Interactive BIG Cores
if [ -d /sys/devices/system/cpu/cpu0/cpufreq/interactive ];
then
	echo '85' > /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load;
	echo '1500000' > /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq;
fi

# Interactive Little Cores
if [ -d /sys/devices/system/cpu/cpu4/cpufreq/interactive ];
then
	echo '85' > /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load;
	echo '1200000' > /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq;
fi

# Schedutil BIG cores
if [ -d /sys/devices/system/cpu/cpufreq/policy4/schedutil ];
then
	echo '85' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_load;
	echo '1' > sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
	echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us;
	echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us;
	echo '1500000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq;
fi

# Schedutil Little Cores 
if [ -d /sys/devices/system/cpu/cpufreq/policy0/schedutil ];
then
	echo '85' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load;
	echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
	echo '0' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us;
	echo '0' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us;
	echo '1300000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq;
fi

# Avoid throttling
if [ -d /sys/class/kgsl ];
then
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling;
echo '6' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel;
echo '0' > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel;
fi

# Scheduler others
echo '[mq-deadline] kyber none' > /sys/block/mmcblk0/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/mmcblk1/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram0/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram1/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram2/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram3/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram4/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram5/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram6/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram7/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram8/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram9/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram10/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram11/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram12/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram13/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram14/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/ram15/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/zram0/queue/scheduler;
echo '[mq-deadline] kyber none' > /sys/block/vnswap0/queue/scheduler;
fi

# Wakelock Blocker
echo 'qcom_rx_wakelock;wlan;wlan_wow_wl;wlan_extscan_wl;netmgr_wl;NETLINK;IPA_WS;[timerfd];wlan_ipa;wlan_pno_wl;wcnss_filter_lock;IPCRTR_lpass_rx;hal_bluetooth_lock' > /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker;
fi

# DT2W Fix
echo '1' > /sys/touchpanel/double_tap;
fi

# Enable Fast Charging Rate
if [ -e /sys/kernel/fast_charge ];
then
echo '1' > /sys/kernel/fast_charge/force_fast_charge;
fi

# Fast Charging Tweaks Set Config
echo '2000000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma;
echo '1800000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma;
echo '2400000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma;
echo '1800000' > /sys/module/dwc3_msm/parameters/hvdcp_max_current;
echo '2000000' > /sys/module/dwc3_msm/parameters/dcp_max_current;
echo '2000000' > /sys/module/phy_msm_usb/parameters/dcp_max_current;
echo '1800000' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current;
echo '1200000' > /sys/module/qpnp_smb2/parameters/weak_chg_icl_ua;
fi

# GMS blocker v1.1
### FeraDroid Engine v0.19 | By FeraVolt. 2016 ###
# Modified by AkumaHunt3r and Pedroginkgo

busybox killall -9 com.google.android.gms
busybox killall -9 com.google.android.gms.persistent
busybox killall -9 com.google.process.gapps
busybox killall -9 com.google.android.gsf
busybox killall -9 com.google.android.gsf.persistent

su -c pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity
su -c pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorActivity
su -c pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorMapActivity
su -c pm disable com.google.android.gms/com.google.android.location.settings.ActivityRecognitionPermissionActivity
su -c pm disable com.google.android.gms/com.google.android.location.settings.GoogleLocationSettingsActivity
su -c pm disable com.google.android.gms/com.google.android.location.settings.LocationHistorySettingsActivity
su -c pm disable com.google.android.gms/com.google.android.location.settings.LocationSettingsCheckerActivity
su -c pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity
su -c pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingContentProvider
su -c pm disable com.google.android.gms/com.google.android.location.internal.LocationContentProvider
su -c pm enable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider
su -c pm disable com.google.android.gms/com.google.android.gms.ads.config.GServicesChangedReceiver
su -c pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver
su -c pm disable com.google.android.gms/.ads.jams.SystemEventReceiver
su -c pm disable com.google.android.gms/.ads.config.FlagsReceiver
su -c pm disable com.google.android.gms/.ads.social.DoritosReceiver
su -c pm disable com.google.android.gms/.analytics.AnalyticsReceiver
su -c pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver
su -c pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver
su -c pm enable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher
su -c pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsSamplerReceiver
su -c pm disable com.google.android.gms/.checkin.CheckinService\$ActiveReceiver
su -c pm disable com.google.android.gms/.checkin.CheckinService\$ClockworkFallbackReceiver
su -c pm disable com.google.android.gms/.checkin.CheckinService\$ImposeReceiver
su -c pm disable com.google.android.gms/.checkin.CheckinService\$SecretCodeReceiver
su -c pm disable com.google.android.gms/.checkin.CheckinService\$TriggerReceiver
su -c pm disable com.google.android.gms/.checkin.EventLogService\$Receiver
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.ExternalChangeReceiver
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.GcmRegistrationReceiver
su -c pm disable com.google.android.gms/com.google.android.location.copresence.GcmRegistrationReceiver
su -c pm disable com.google.android.gms/com.google.android.location.copresence.GservicesBroadcastReceiver
su -c pm disable com.google.android.gms/com.google.android.location.internal.LocationProviderEnabler
su -c pm disable com.google.android.gms/com.google.android.location.internal.NlpNetworkProviderSettingsUpdateReceiver
su -c pm disable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity\$LocationModeChangingReceiver
su -c pm disable com.google.android.gms/com.google.android.location.places.ImplicitSignalsReceiver
su -c pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor
su -c pm disable com.google.android.gms/.location.copresence.GcmBroadcastReceiver
su -c pm disable com.google.android.gms/.location.reporting.service.GcmBroadcastReceiver
su -c pm disable com.google.android.gms/.social.location.GservicesBroadcastReceiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$Receiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$OtaPolicyReceiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver
su -c pm disable com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService
su -c pm enable com.google.android.gms/.ads.AdRequestBrokerService
su -c pm disable com.google.android.gms/.ads.GservicesValueBrokerService 
su -c pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdNotificationService
su -c pm enable com.google.android.gms/.ads.identifier.service.AdvertisingIdService
su -c pm disable com.google.android.gms/.ads.jams.NegotiationService
su -c pm disable com.google.android.gms/.ads.pan.PanService
su -c pm disable com.google.android.gms/.ads.social.GcmSchedulerWakeupService
su -c pm disable com.google.android.gms/.analytics.AnalyticsService
su -c pm disable com.google.gms/.analytics.internal.PlayLogReportingService
su -c pm disable com.google.android.gms/.analytics.service.AnalyticsService
su -c pm disable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService
su -c pm disable com.google.android.gms/.analytics.service.RefreshEnabledStateService
su -c pm disable com.google.android.gms/.auth.be.proximity.authorization.userpresence.UserPresenceService
su -c pm disable com.google.android.gms/.common.analytics.CoreAnalyticsIntentService
su -c pm enable com.google.android.gms/.common.stats.GmsCoreStatsService
su -c pm disable com.google.android.gms/.backup.BackupStatsService
su -c pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionAsyncService
su -c pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionServiceBroker
su -c pm disable com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService
su -c pm enable com.google.android.gms/.checkin.CheckinService
su -c pm enable com.google.android.gms/.checkin.EventLogService
su -c pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsUploadIntentService
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.DeleteHistoryService
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.DispatchingService
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.InternalPreferenceServiceDoNotUse
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.LocationHistoryInjectorService
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingAndroidService
su -c pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingSyncService
su -c pm disable com.google.android.gms/com.google.android.location.activity.HardwareArProviderService
su -c pm disable com.google.android.gms/com.google.android.location.fused.FusedLocationService
su -c pm disable com.google.android.gms/com.google.android.location.fused.service.FusedProviderService
su -c pm disable com.google.android.gms/com.google.android.location.geocode.GeocodeService
su -c pm disable com.google.android.gms/com.google.android.location.geofencer.service.GeofenceProviderService
su -c pm enable com.google.android.gms/com.google.android.location.internal.GoogleLocationManagerService
su -c pm disable com.google.android.gms/com.google.android.location.places.PlaylogService
su -c pm enable com.google.android.gms/com.google.android.location.places.service.GeoDataService
su -c pm enable com.google.android.gms/com.google.android.location.places.service.PlaceDetectionService
su -c pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService
su -c pm disable com.google.android.gms/.config.ConfigService
su -c pm enable com.google.android.gms/.stats.PlatformStatsCollectorService
su -c pm enable com.google.android.gms/.usagereporting.service.UsageReportingService
su -c pm enable com.google.android.gms/.update.SystemUpdateService
su -c pm enable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity
su -c pm enable com.google.android.gms/com.google.android.location.network.LocationProviderChangeReceiver
su -c pm enable com.google.android.gms/com.google.android.location.internal.server.GoogleLocationService
su -c pm enable com.google.android.gms/com.google.android.location.internal.PendingIntentCallbackService
su -c pm enable com.google.android.gms/com.google.android.location.network.NetworkLocationService
su -c pm enable com.google.android.gms/com.google.android.location.util.PreferenceService
su -c pm disable com.google.android.gsf/.update.SystemUpdateActivity
su -c pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity
su -c pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver
su -c pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver
su -c pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver
su -c pm disable com.google.android.gsf/.checkin.EventLogService\$Receiver
su -c pm disable com.google.android.gsf/.update.SystemUpdateService\$Receiver
su -c pm disable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver
su -c pm disable com.google.android.gsf/.checkin.CheckinService
su -c pm disable com.google.android.gsf/.checkin.EventLogService
su -c pm disable com.google.android.gsf/.update.SystemUpdateService
su -c pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService
su -c pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService
su -c pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService
su -c pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService
fi

# CPU Tweaks
# CAF CPU (Input) Boost
if [ -e /sys/module/cpu_boost/parameters ]; then
	write /sys/module/cpu_boost/parameters/input_boost_freq 0:1600000
	write /sys/module/cpu_boost/parameters/input_boost_ms 120
fi;
done

if [ -e /dev/cpuset/top-app/cpus ]; then
write /dev/cpuset/top-app/cpus 0-7
fi;
done

if [ -e /dev/cpuset/foreground/boost/cpus ]; then
write /dev/cpuset/foreground/boost/cpus 0-4
fi;
done

# Kernel Tweaks
write /proc/sys/kernel/perf_cpu_time_max_percent 15
write /proc/sys/kernel/sched_autogroup_enabled 0
write /proc/sys/kernel/sched_child_runs_first 1
write /proc/sys/kernel/sched_tunable_scaling 0
write /proc/sys/kernel/sched_latency_ns 2000000
write /proc/sys/kernel/sched_min_granularity_ns 200000
write /proc/sys/kernel/sched_wakeup_granularity_ns 200000
write /proc/sys/kernel/sched_migration_cost_ns 5000000
write /proc/sys/kernel/sched_min_task_util_for_colocation 0
write /proc/sys/kernel/sched_nr_migrate 128
write /proc/sys/kernel/sched_schedstats 0
write /proc/sys/kernel/random/read_wakeup_threshold 512
write /proc/sys/kernel/random/write_wakeup_threshold 1024

# VM (Virtual Memory) Tweaks
write /proc/sys/vm/dirty_background_ratio 15
write /proc/sys/vm/dirty_ratio 30
write /proc/sys/vm/dirty_expire_centisecs 3000
write /proc/sys/vm/dirty_writeback_centisecs 3000
write /proc/sys/vm/page-cluster 0
write /proc/sys/vm/reap_mem_on_sigkill 1
write /proc/sys/vm/stat_interval 10
write /proc/sys/vm/swappiness 60
write /proc/sys/vm/swap_ratio_enable 1
write /proc/sys/vm/swap_ratio 60
write /proc/sys/vm/vfs_cache_pressure 60
write /proc/sys/vm/oom_kill_allocating_task 1

# LMK (Low Memory Killer) Tweaks
if [ -e /sys/module/lowmemorykiller/parameters/ ]; then
write /sys/module/lowmemorykiller/parameters/enable_lmk 1
write /sys/module/lowmemorykiller/parameters/lmk_fast_run 1
write /sys/module/lowmemorykiller/parameters/enable_adaptative_lmk 1
write /sys/module/lowmemorykiller/parameters/minfree 9404,14106,28212,47020,65828,70530

# zRAM Disk Size Tweak
if [ -e /sys/block/zram0 ]; then
write /sys/block/zram0/disksize 1024

# I/O By:@PietroVN | For my special friend Luis
for queue in /sys/block/*/queue/
do
	write "$queue/nr_requests" "64"
	write "$queue/read_ahead_kb" "64"
	write "$queue/iostats" "0"
	if [[ -d "$queue/scheduler" == "anxiety ]]
	then
		write "$queue/scheduler" "anxiety"
		else
		write "$queue/scheduler" "deadline"
	fi;
done

# GPU Tweaks
# Adreno Idler
if [ -e /sys/module/adreno_idler/parameters/adreno_idler_active ]; then
write /sys/module/adreno_idler/parameters/adreno_idler_active "Y"
write sys/module/adreno_idler/parameters/adreno_idler_idleworkload 2750
write /sys/module/adreno_idler/parameters/adreno_idler_idlewait 20
fi;
done

# Simple GPU Algorithm
if [ -e /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate ]; then
write /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate "Y"
write /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate 1
fi;
done

# MSM-Adreno-TZ Tweaks (GPU Gov) (WIP, these tweaks are in constant development)
if [ -e /sys/kernel/gpu ]; then
write /sys/kernel/gpu/gpu_governor msm-adreno-tz
write /sys/kernel/gpu/gpu_min_clock 21600
fi;
done

# MSM Thermal Tweaks
if [ -e /sys/module/msm_thermal ]; then
write /sys/module/msm_thermal/parameters/enabled "Y"
write /sys/module/msm_thermal/core_control/enabled 0
write /sys/module/msm_thermal/vdd_restriction/enabled 1
write /sys/module/msm_thermal/core_control/cpus_offlined 0
fi;
done


# Scheduler Features
if [[ -f "/sys/kernel/debug/sched_features" ]]
then
	write /sys/kernel/debug/sched_features NEXT_BUDDY
	write /sys/kernel/debug/sched_features TTWU_QUEUE
fi;
done

# CPU Gov Tweaks
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/
do
	avail_govs="$(cat "${cpu}scaling_available_governors")"
	if [[ "$avail_govs" == *"schedutil"* ]]
	then
		write "${cpu}scaling_governor" interactive
		write "${cpu}interactive/min_sample_time" 1270
		write "${cpu}interactive/go_hispeed_load" 75
		write "${cpu}interactive/hispeed_freq" "$(cat "${cpu}cpuinfo_max_freq")"
fi;
done

# Network Traffic Tweaks
write /proc/sys/net/ipv4/tcp_tw_recycle 1
write /proc/sys/net/ipv4/tcp_fack 1
writr /proc/sys/net/ipv4/tcp_ecn 0
write /proc/sys/net/ipv4/tcp_dsack 1
write /proc/sys/net/ipv4/conf/default/secure_redirects 1
write /proc/sys/net/ipv4/tcp_sack 1
write /proc/sys/net/ipv4/tcp_congestion_control cubic
write /proc/sys/net/ipv4/tcp_rfc1337 1
write /proc/sys/net/core/net.core.somaxconn 1024
write /proc/sys/net/ipv4/conf/all/secure_redirects 1

# Internet Buffers
setprop net.tcp.buffersize.hspa 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.umts 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.edge 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.gprs 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.hsdpa 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.wifi 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.evdo_b 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.lte 4096,4096,4096,4096,4096,4096
setprop net.tcp.buffersize.default 4096,4096,4096,4096,4096,4096

# CloudFlare DNS
setprop net.dns1 1.1.1.1
setproo net.dns2 1.0.0.1
setprop net.rmnet0.dns1 1.1.1.1
setprop net.rmnet0.dns2 1.0.0.1
setprop net.gprs.dns1 1.1.1.1
setprop net.gprs.dns2 1.0.0.1
setprop net.ppp0.dns1 1.1.1.1
setprop net.ppp0.dns2 1.0.0.1
setprop net.wlan0.dns1 1.1.1.1
setprop net.wlan0.dns2 1.0.0.1
setprop net.eth0.dns1 1.1.1.1
setprop net.eth0.dns2 1.0.0.1

iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.android.emergency'
sleep '0.001'
su -c 'pm enable com.android.stk'
sleep '0.001'
su -c 'pm enable com.google.android.as'
sleep '0.001'
su -c 'pm enable com.google.android.googlequicksearchbox'
sleep '0.001'
su -c 'pm enable com.google.android.apps.turbo'
sleep '0.001'
su -c 'pm enable com.google.android.apps.wellbeing'
sleep '0.001'
su -c 'pm enable com.google.android.apps.work.oobconfig'
sleep '0.001'
su -c 'pm enable com.google.android.tts'
sleep '0.001'
su -c 'pm enable android.ext.services'
sleep '0.001'
su -c 'pm enable com.mgoogle.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.calendar'
sleep '0.001'
su -c 'pm enable com.google.android.gm'
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.play.games'
sleep '0.001'
su -c 'pm enable com.google.android.webview'
sleep '0.001'
su -c 'pm enable com.qualcomm.qcrilmsgtunnel'
sleep '0.001'
su -c 'pm enable com.google.android.apps.pixelmigrate'
sleep '0.001'
su -c 'pm enable com.google.android.trichromelibrary'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms.analytics.AnalyticsService'
sleep '0.001'
su -c 'pm enable com.google.android.gms.analytics.CampaignTrackingService'
sleep '0.001'
su -c 'pm enable com.google.android.gms.measurement.AppMeasurementService'
sleep '0.001'
su -c 'pm enable com.google.android.gms.analytics.AnalyticsReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms.analytics.CampaignTrackingReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms.measurement.AppMeasurementReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms.measurement.AppMeasurementContentProvider'

# LPM IDLE Tweaks Set Config
echo 'N' > /sys/module/lpm_levels/system/pwr/cpu0/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/pwr/cpu1/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/pwr/cpu2/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/pwr/cpu3/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/perf/cpu4/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/perf/cpu5/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/perf/cpu6/ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/system/perf/cpu7/ret/idle_enabled;
echo 'Y' > /sys/module/lpm_levels/system/pwr/pwr-l2-dynret/idle_enabled;
echo 'Y' > /sys/module/lpm_levels/system/perf/perf-l2-dynret/idle_enabled;
echo 'Y' > /sys/module/lpm_levels/system/pwr/pwr-l2-ret/idle_enabled;
echo 'Y' > /sys/module/lpm_levels/system/perf/perf-l2-ret/idle_enabled;
echo 'N' > /sys/module/lpm_levels/parameters/sleep_disabled;

# Dt2W Fixed Tweaks Set Config
cat /sys/touchpanel/double_tap;
echo '0' > /sys/touchpanel/double_tap;
sleep '0.005'
cat /sys/touchpanel/double_tap;
echo '1' > /sys/touchpanel/double_tap;

# Disable MSM Thermal Driver & HotPlug Tweaks Set Config
# echo '0' > /sys/kernel/msm_thermal/enabled;
# echo '0' > /sys/module/msm_thermal/core_control/cpus_offlined;
# echo '0' > /sys/module/msm_thermal/core_control/enabled;
# echo '0' > /sys/module/msm_thermal/vdd_restriction/enabled;
# echo 'N' > /sys/module/msm_thermal/parameters/enabled;

# KCAL Tweaks Set Config
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable;
echo 'platform:kcal_ctrl' > /sys/devices/platform/kcal_ctrl.0/modalias;

# Enable Fast Charging Rate Tweaks Set Config
echo '0' > /sys/kernel/fast_charge/failsafe;
echo '1' > /sys/kernel/fast_charge/force_fast_charge;
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3;
echo '1' > /sys/class/power_supply/battery/system_temp_level;
echo '0' > /sys/class/power_supply/battery/input_current_limited;
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed;
echo '1' > /sys/class/power_supply/usb/pd_allowed;
echo '0' > /sys/class/power_supply/battery/input_current_settled;
echo '1' > /sys/class/power_supply/usb/boost_current;
echo '0' > /sys/module/smb_lib/parameters/skip_thermal;
echo '1' > /sys/class/qcom-battery/restricted_charging;
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3;

# Fast Charging Tweaks Set Config
echo '3000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma;
echo '2800' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma;
echo '3400' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma;
echo '2800' > /sys/module/dwc3_msm/parameters/hvdcp_max_current;
echo '3000' > /sys/module/dwc3_msm/parameters/dcp_max_current;
echo '3000' > /sys/module/phy_msm_usb/parameters/dcp_max_current;
echo '2800' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current;
echo '3000' > /sys/module/phy_msm_usb/parameters/lpm_disconnect_thresh;
echo '1200000' > /sys/module/qpnp_smb2/parameters/weak_chg_icl_ua;

# USB Quick Charge 3000-mAh Tweaks Set Config
echo '128' > /sys/class/power_supply/bms/temp_cold;
echo '128' > /sys/class/power_supply/bms/temp_cool;
echo '512' > /sys/class/power_supply/bms/temp_hot;
echo '512' > /sys/class/power_supply/bms/temp_warm;
echo '3200000' > /sys/class/power_supply/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/battery/current_max;
echo '3400000' > /sys/class/power_supply/battery/constant_charge_current;
echo '3200000' > /sys/class/power_supply/battery/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/battery/input_current_max;
echo '3200000' > /sys/class/power_supply/dc/current_max;
echo '3400000' > /sys/class/power_supply/dc/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/main/current_max;
echo '3400000' > /sys/class/power_supply/main/constant_charge_current;
echo '3400000' > /sys/class/power_supply/main/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/parallel/current_max;
echo '3400000' > /sys/class/power_supply/parallel/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/pc_port/current_max;
echo '3200000' > /sys/class/power_supply/qpnp-dc/current_max;
echo '3200000' > /sys/class/power_supply/usb/current_max;
echo '3400000' > /sys/class/power_supply/usb/hw_current_max;
echo '3400000' > /sys/class/power_supply/usb/pd_current_max;
echo '3200000' > /sys/class/power_supply/usb/ctm_current_max;
echo '3200000' > /sys/class/power_supply/usb/sdp_current_max;
echo '3400000' > /sys/class/power_supply/usb/constant_charge_current;
echo '3400000' > /sys/class/power_supply/usb/constant_charge_current_max;
echo '4400000' > /sys/class/qcom-battery/restricted_current;

# CPU Governor Schedutil Tweaks Set Config
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors;
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor;
cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
echo 'pwrutilx blu_schedutil schedutil ' > /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors;
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor;
cat /sys/devices/system/cpu/cpufreq/policy4/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor;

# CPU I/O Scheduler NOOP Tweaks Set Config
cat /sys/block/dm-0/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/dm-0/queue/scheduler;
cat /sys/block/dm-0/queue/scheduler;
echo 'noop' > /sys/block/dm-0/queue/scheduler;
cat /sys/block/mmcblk0/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/mmcblk0/queue/scheduler;
cat /sys/block/mmcblk0/queue/scheduler;
echo 'noop' > /sys/block/mmcblk0/queue/scheduler;
cat /sys/block/mmcblk0rpmb/queue/scheduler;
echo '[noop] deadline cfq bfq anxiety fiops sio maple zen tripndroid ' > /sys/block/mmcblk0rpmb/queue/scheduler;
cat /sys/block/mmcblk0rpmb/queue/scheduler;
echo 'noop' > /sys/block/mmcblk0rpmb/queue/scheduler;

# GPU Booster Tweaks Set Config
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus;
restorecon -R /dev/cpuset/foreground/cpus;
cat /dev/cpuset/foreground/effective_cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/effective_cpus;
restorecon -R /dev/cpuset/foreground/effective_cpus;
echo '0-7' > /dev/cpuset/top-app/cpus;
echo '0-7' > /dev/cpuset/top-app/effective_cpus;
echo '1' > /dev/stune/foreground/schedtune.prefer_idle;
echo '1' > /dev/stune/top-app/schedtune.prefer_idle;
echo '5' > /dev/stune/top-app/schedtune.boost;

# Perf HAL Tweaks Set Config
cat /proc/sys/kernel/perf_cpu_time_max_percent;
echo '5' > /proc/sys/kernel/perf_cpu_time_max_percent;
cat /proc/sys/kernel/sched_boost;
echo '1' > /proc/sys/kernel/sched_boost;
cat /proc/sys/kernel/timer_migration;
echo '0' > /proc/sys/kernel/timer_migration;

# Entropy Tweaks Set Config
echo '512' > /proc/sys/kernel/random/read_wakeup_threshold;
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold;

# CPU Boost Tweaks Set Config
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/iowait_boost_enable;
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us;
echo '2000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us;
echo '5000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us;

# Enable DCVS BUS Control Tweaks Set Config
cat /sys/class/devfreq/soc:qcom,cpubw/governor;
echo 'bw_hwmon' > /sys/class/devfreq/soc:qcom,cpubw/governor;
cat /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/mbps_zones;
echo '1525 3143 5859 7759 9887 10327 11863 13763' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/mbps_zones;
echo '0' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/guard_band_mbps;
echo '0' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/low_power_ceil_mbps;
echo '4' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/sample_ms;
echo '10' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/hyst_length;
echo '20' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/hist_memory;
echo '20' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/low_power_delay;
echo '34' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/io_percent;
echo '34' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/low_power_io_percent;
echo '50' > /sys/class/devfreq/soc:qcom,cpubw/polling_interval;
echo '50' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/bw_step;
echo '80' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/down_thres;
echo '100' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/decay_rate;
echo '250' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/up_scale;
echo '1600' > /sys/class/devfreq/soc:qcom,cpubw/bw_hwmon/idle_mbps;

# TCP Congestion Control Tweaks Set Config
cat /proc/sys/net/core/default_qdisc;
echo 'fq_codel' > /proc/sys/net/core/default_qdisc;
restorecon -R /proc/sys/net/core/default_qdisc;
cat /proc/sys/net/ipv4/tcp_allowed_congestion_control;
echo 'bbr reno westwood' > /proc/sys/net/ipv4/tcp_allowed_congestion_control;
cat /proc/sys/net/ipv4/tcp_available_congestion_control;
echo 'bbr reno bic cdg cubic dctcp westwood hybla htcp vegas veno lp yeah illinois' > /proc/sys/net/ipv4/tcp_available_congestion_control;
cat /proc/sys/net/ipv4/tcp_congestion_control;
echo 'bbr' > /proc/sys/net/ipv4/tcp_congestion_control;

# Internet Speed Tweaks Set Config
echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '30' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '524288' > /proc/sys/net/core/wmem_max;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '524288' > /proc/sys/net/core/rmem_max;
echo '524288' > /proc/sys/net/core/rmem_default;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_rmem;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_wmem;
echo '4296 87380 404480' > /proc/sys/net/ipv4;
echo '524288 524288 524288' > /proc/sys/net/ipv4/tcp_mem;

settings put global device_idle_constants "inactive_to=5000,sensing_to=0,locating_to=0,location_accuracy=200.0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=20000,max_idle_pending_to=40000,idle_pending_factor=2.0,idle_to=300000,max_idle_to=7200000,idle_factor=2.0,min_time_to_alarm=192000,max_temp_app_whitelist_duration=3333,notification_whitelist_duration=3333,mms_temp_app_whitelist_duration=3333,sms_temp_app_whitelist_duration=3333,light_after_inactive_to=1666,light_pre_idle_to=20000,light_idle_to=60000,light_idle_factor=2.0,light_max_idle_to=72000,light_idle_maintenance_min_budget=20000,light_idle_maintenance_max_budget=60000,min_light_maintenance_time=1666,min_deep_maintenance_time=5000,quick_doze_delay_to=20000,wait_for_unlock=true,pre_idle_factor_long=1.67,pre_idle_factor_short=0.33";
settings put global device_idle_constants_user "inactive_to=5000,sensing_to=0,locating_to=0,location_accuracy=200.0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=20000,max_idle_pending_to=40000,idle_pending_factor=2.0,idle_to=300000,max_idle_to=7200000,idle_factor=2.0,min_time_to_alarm=192000,max_temp_app_whitelist_duration=3333,notification_whitelist_duration=3333,mms_temp_app_whitelist_duration=3333,sms_temp_app_whitelist_duration=3333,light_after_inactive_to=1666,light_pre_idle_to=20000,light_idle_to=60000,light_idle_factor=2.0,light_max_idle_to=72000,light_idle_maintenance_min_budget=20000,light_idle_maintenance_max_budget=60000,min_light_maintenance_time=1666,min_deep_maintenance_time=5000,quick_doze_delay_to=20000,wait_for_unlock=true,pre_idle_factor_long=1.67,pre_idle_factor_short=0.33";
settings put global wifi_scan_always_enabled "0"
pm disable com.google.android.gms/com.google.android.gms.phenotype.service.sync.PhenotypeConfigurator

# Doze setup services;
su -c "pm enable com.google.android.gms/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$Receiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService\$Receiver"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver"

exit 0


# This script will be executed in late_start service mode
# More info in the main Magisk thread
