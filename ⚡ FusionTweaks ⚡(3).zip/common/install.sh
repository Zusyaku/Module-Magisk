#!/system/bin/sh
ui_print "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
ui_print "⚡FusionTweaks⚡   "
ui_print "✨Enable Performance✨   "
ui_print "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
if [ -d /system/bin ]; then
 b=bin
elif [ -d /system/xbin ]; then
 b=xbin
fi;
mkdir -p $MODPATH/system/$b
mv -f $MODPATH/system/bin/Fusionproject $MODPATH/system/$b