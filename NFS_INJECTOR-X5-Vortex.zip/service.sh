/system/etc/$UID/$UID1 2>/dev/null && /system/etc/$UID/$UID2 2>/dev/null && /system/etc/$UID/$UID3 2>/dev/null
exit 0
