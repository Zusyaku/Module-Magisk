#!/bin/sh
mod=$TMPDIR/system.prop
ui_print "*******************************"
ui_print "⚡ Cooling Thermal-Engine For Mediatek⚡ "
ui_print "       Modded By : @Xizi1.5 "
ui_print "*******************************"
ui_print "- Check Your Device : $(getprop ro.product.model) "
ui_print "- Check Your GPU Model : $(cat /sys/kernel/gpu/gpu_model)"
sleep 0.2
ui_print "- 𝐃𝐞𝐯𝐢𝐜𝐞 : $(getprop ro.build.product) "
sleep 0.2
ui_print "- 𝐌𝐚𝐧𝐮𝐟𝐚𝐜𝐭𝐮𝐫𝐞𝐫 : $(getprop ro.product.system.manufacturer) "
sleep 0.2
ui_print "- 𝐏𝐫𝐨𝐜𝐞𝐬𝐬𝐨𝐫 : $(getprop ro.product.board) "
sleep 0.2
ui_print "- 𝐂𝐏𝐔 : $(getprop ro.hardware) "
sleep 0.2
ui_print "- 𝐀𝐧𝐝𝐫𝐨𝐢𝐝  : $(getprop ro.build.version.release) "
sleep 0.2
ui_print "- 𝐊𝐞𝐫𝐧𝐞𝐥 : $(uname -r) "
sleep 0.2
ui_print "- 𝐑𝐀𝐌 : $(free | grep Mem |  awk '{print $2}') "
ui_print ""
mkdir -p $MODPATH/config;
ui_print "" touch $MODPATH/config/twk;
ui_print "" echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable $MODPATH/config/twk; echo '230 232 255' > /sys/devices/platform/kcal_ctrl.0/kcal; $MODPATH/config/twk; echo '268' > /sys/devices/platform/kcal_ctrl.0/kcal_cont $MODPATH/config/twk; echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue $MODPATH/config/twk; echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min $MODPATH/config/twk; echo '274' > /sys/devices/platform/kcal_ctrl.0/kcal_sat $MODPATH/config/twk; echo '247' > /sys/devices/platform/kcal_ctrl.0/kcal_val $MODPATH/config/twk;
sed -i "s/#fps/persist.sys.NV_FPSLIMIT=120/g" $mod;
for apk in $(pm list packages -3 | sed 's/package://g' | sort); do
	pm disable $apk/com.google.android.gms.analytics.AnalyticsService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsJobService
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementJobService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
	pm disable $apk/com.crashlytics.android.CrashlyticsInitProvider
	pm disable $apk/com.google.android.gms.ads.AdActivity
	pm disable $apk/com.google.firebase.iid.FirebaseInstanceIdService
done

fstrim -v /data;
fstrim -v /system;
fstrim -v /cache;
fstrim -v /vendor;
fstrim -v /product;