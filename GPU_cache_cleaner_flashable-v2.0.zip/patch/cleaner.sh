#!/sbin/sh
#
#Adreno Drivers
#
for i in "$(find /data -type f -name '*shader*')"; do
 rm -f $i
done
