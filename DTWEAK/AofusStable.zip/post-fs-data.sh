#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
busybox run-parts $MODDIR/system/etc/init.d
setprop ro.vendor.qti.config.zram true
echo '0' > /sys/kernel/power_suspend/power_suspend_mode
echo '3' > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo '1' > /sys/module/cpu_boost/parameters/sched_boost_on_input
echo '100' > /sys/kernel/mm/uksm/max_cpu_percentage
echo '0' > /sys/kernel/mm/uksm/sleep_millisecs
echo 'noop' > /sys/block/mmcblk0/queue/scheduler                
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'N' > /sys/module/workqueue/parameters/power_efficient
echo 'performance' > /sys/kernel/mm/uksm/cpu_governor
echo '1' > /sys/kernel/mm/uksm/run
echo 'lz4' > /sys/block/zram1/comp_algorithm
echo '8' > /sys/block/zram1/max_comp_streams
echo '134217728' > /sys/block/zram1/disksize
mkswap /dev/block/zram1 > /dev/null 2>&1
swapon /dev/block/zram1 > /dev/null 2>&1
echo 'lz4' > /sys/block/zram2/comp_algorithm
echo '8' > /sys/block/zram2/max_comp_streams
echo '134217728' > /sys/block/zram2/disksize
mkswap /dev/block/zram2 > /dev/null 2>&1
swapon /dev/block/zram2 > /dev/null 2>&1
echo 'lz4' > /sys/block/zram3/comp_algorithm
echo '8' > /sys/block/zram3/max_comp_streams
echo '134217728' > /sys/block/zram3/disksize
echo '4' /sys/block/zram0/max_comp_streams 
mkswap /dev/block/zram3 > /dev/null 2>&1
swapon /dev/block/zram3 > /dev/null 2>&1
setprop debug.sf.gpu_comp_tiling 0
setprop debug.sf.recomputecrop 0
setprop debug.cpurend.vsync false
setprop debug.enabletr true
setprop debug.performance.tuning 1
setprop ro.sf.compbypass.enable 0
setprop debug.overlayui.enable 1
setprop ro.product.gpu.driver 1
setprop debug.oculus.refreshRate 60
setprop debug.oculus.textureHeight 540
setprop debug.oculus.textureWidth 1080
setprop ro.surface_flinger.support_kernel_idle_timer true
setprop ro.surface_flinger.set_display_power_timer_ms 10000
setprop ro.surface_flinger.set_touch_timer_ms 5000
setprop ro.surface_flinger.set_idle_timer_ms 9000
setprop ro.zygote.disable_gl_preload true
setprop vendor.perf.gestureflingboost.enable true
setprop vendor.iop.enable_iop 0
setprop vendor.iop.enable_uxe 0
setprop vendor.perf.iop_v3.enable 0
setprop vendor.perf.iop_v3.enable.debug 0
setprop vendor.enable.prefetch 0
setprop vendor.iop.enable_prefetch_ofr 0
setprop dalvik.vm.dex2oat-swap true
setprop debug.hwui.renderer skiagl
setprop debug.egl.swapinterval -60
setprop vendor.debug.egl.swapinterval -60
setprop debug.sf.latch_unsignaled 1
setprop wifi.supplicant_scan_interval 200
setprop dalvik.vm.gc.overwritefree true
setprop debug.egl.buffcount 3
setprop ADRENO_PROFILER_ENABLE_OPENCL 1
setprop ADRENO_PROFILER_ENABLE_BLOCKING 1
setprop dalvik.vm.dex2oat-filter speed
setprop dalvik.vm.image-dex2oat-filter --no-watch-dog
setprop dalvik.vm.dexopt-data-only 1
setprop dalvik.vm.verify-bytecode false
setprop dalvik.vm.execution-mode intjit
setprop dalvik.vm.stack-trace-file /data/anr/traces.txt
setprop dalvik.vm.jmiopts forcecopy
setprop dalvik.vm.check-dex-sum false
setprop dalvik.vm.deadlock-predict off
setprop dalvik.vm.dex2oat-minidebuginfo false
setprop dalvik.vm.usejit true
setprop dalvik.vm.dex2oat-flags --no-watch-dog
setprop dalvik.vm.dexopt.secondary true
setprop pm.dexopt.first-boot speed
setprop pm.dexopt.boot speed
setprop pm.dexopt.install quicken
setprop pm.dexopt.inactive speed
setprop persist.sys.dalvik.multithread true
setprop persist.sys.dalvik.hyperthreading true
setprop pm.dexopt.bg-dexopt speed
setprop pm.dexopt.shared speed
setprop persist.ims.disableDebugLogs 1
setprop persist.radio.oem_socket false
setprop debug.atrace.tags.enableflags 0
setprop profiler.force_disable_ulog true
setprop profiler.force_disable_err_rpt true
setprop profiler.force_disable_ulog 1
setprop profiler.force_disable_err_rpt 1
setprop ro.config.nocheckin 1
setprop debugtool.anrhistory 0
setprop ro.com.google.locationfeatures 0
setprop ro.com.google.networklocation 0
setprop profiler.debugmonitor false
setprop profiler.launch false
setprop profiler.hung.dumpdobugreport false
setprop persist.service.pcsync.enable 0
setprop persist.service.lgospd.enable 0
setprop persist.sys.purgeable_assets 1
setprop ro.kernel.android.checkjni 0
setprop ro.debuggable 1
setprop setprop dalvik.vm.checkjni false
setprop profiler.hung.dumpdobugreport false
setprop trustkernel.log.state disable
setprop persist.sys.ssr.enable_ramdumps 0
setprop persist.vendor.sys.ssr.enable_ramdumps 0
setprop persist.traced.enable 0
setprop ro.lmk.log_stats 0
setprop persist.radio.ramdump 0
setprop debug.mdpcomp.logs 0
setprop logd.logpersistd.enable false
setprop persist.sys.ssr.enable_ramdumps 0
setprop persist.vendor.sys.ssr.enable_ramdumps 0
setprop persist.traced.enable 0
setprop persist.wpa_supplicant.debug false
setprop vidc.debug.level 0
setprop debug.sqlite.journalmode WAL
setprop debug.sqlite.syncmode 1
setprop pm.sleep_mode 1
setprop ro.sys.fw.bg_apps_limit 60
setprop ro.hwui.patch_cache_size 384
setprop ro.hwui.drop_shadow_cache_size 18
setprop ro.hwui.layer_cache_size 90
setprop ro.hwui.path_cache_size 36
setprop ro.hwui.r_buffer_cache_size 18
setprop ro.hwui.texture_cache_size 183
setprop dalvik.vm.boot-dex2oat-threads 8
setprop dalvik.vm.dex2oat-threads 8
setprop dalvik.vm.image-dex2oat-threads 8
setprop ro.sys.fw.dex2oat_thread_count 8
setprop mot.proximity.distance 0
setprop debug.gr.swapinterval -60
setprop debug.gr.numframebuffers 3
setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3
setprop persist.device_config.runtime_native.usap_pool_enabled true
setprop ro.ril.disable.power.collapse 0
setprop ro.floatingtouch.available 1
setprop ro.audio.flinger_standbytime_ms 300
setprop ro.boot.warranty_bit 0
setprop ro.warranty_bit 0
setprop ro.vendor.gt_library libqti-gt.so
setprop ro.vendor.at_library libqti-at.so
setprop ro.vendor.extension_library libqti-perfd-client.so
setprop ro.vendor.scroll.preobtain.enable false
echo '1' > /sys/module/mdss_fb/parameters/srgb_enabled
echo '2' > /sys/class/graphics/fb0/msm_fb_srgb



