#!/system/bin/sh
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh);;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done
# Wait for boot to finish completely
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done
# Magisk Busybox Symlink for Apps
ln -s /sbin/.magisk/busybox/*
# Google Service Config Reduce Drain
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'
# Edit the resolv conf file if it exist
if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 1.1.1.1\nnameserver 1.0.0.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi
#KCAL For Fix Screen Retention
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '223 228 235' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '270' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '13' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '255' > /sys/devices/platform/kcal_ctrl.0/kcal_val
echo '255' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
#CPU 
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
#Charging Tweaks
chmod 777 /sys/class/power_supply/*/*
chmod 777 /sys/module/qpnp_smbcharger/*/*
chmod 777 /sys/module/dwc3_msm/*/*
chmod 777 /sys/module/phy_msm_usb/*/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '150' > /sys/class/power_supply/bms/temp_cool
echo '460' > /sys/class/power_supply/bms/temp_hot
echo '460' > /sys/class/power_supply/bms/temp_warm
echo '4000000' > /sys/class/power_supply/usb/current_max
echo '4000000' > /sys/class/power_supply/usb/hw_current_max
echo '4000000' > /sys/class/power_supply/usb/pd_current_max
echo '4000000' > /sys/class/power_supply/usb/ctm_current_max
echo '4000000' > /sys/class/power_supply/usb/sdp_current_max
echo '4000000' > /sys/class/power_supply/main/current_max
echo '4000000' > /sys/class/power_supply/main/constant_charge_current_max
echo '4000000' > /sys/class/power_supply/battery/current_max
echo '4000000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '4600000' > /sys/class/qcom-battery/restricted_current
echo '4000000' > /sys/class/power_supply/pc_port/current_max
echo '4000000' > /sys/class/power_supply/constant_charge_current__max
sleep 1
done
# Setting Correct Permission
chmod 755 /system/xbin/haveged;
chown root /system/xbin/haveged;
chmod 500 /data/rngd.pid;
chown 0:0 /data/rngd.pid;
chmod 777 /system/usr/idc;
chown root /system/usr/idc;
chmod 777 /system/xbin/sqlite3;
chown root /system/xbin/sqlite3;
chmod 755 /system/bin/haveged;
chown root /system/bin/haveged;
chmod 755 /system/bin/sqlite3;
chown root /system/bin/sqlite3;
chmod 755 /system/bin/tune2fs;
chown root /system/bin/tune2fs;
chmod 777 /system/lib/libncurses.so;
chown root /system/lib/libncurses.so;
chmod 777 /system/etc/init.d/02Zipalign;
chown root /system/etc/init.d/02Zipalign;
chmod 777 /system/etc/init.d/03Remount_Full_Ext4;
chown root /system/etc/init.d/03Remount_Full_Ext4;
chmod 777 /system/etc/init.d/04Net_Speed_Tweak;
chown root /system/etc/init.d/04Net_Speed_Tweak;
chmod 777 /system/etc/init.d/05Ext4_Lag_Fix;
chown root /system/etc/init.d/05Ext4_Lag_Fix;
chmod 777 /system/etc/init.d/06System_Tweak;
chown root /system/etc/init.d/06System_Tweak;
chmod 777 /system/etc/init.d/07Sqlite_Optimize;
chown root /system/etc/init.d/07Sqlite_Optimize;
chmod 777 /system/etc/init.d;
chown root /system/etc/init.d;
chmod 755 /system/etc/init.d/sysctl_enable;
chown root /system/etc/init.d/sysctl_enable;
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo 'deadline' > /sys/block/mmcblk0/queue/scheduler
echo 'deadline' > /sys/block/mmcblk1/queue/scheduler
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 
If [[ -d "/sys/touchpanel/double_tap" ]]
then
  write "/sys/touchpanel/double_tap" 1
fi
stop perfd
while true; do
echo "3" > /proc/sys/vm/drop_caches
echo "0" > /proc/sys/vm/compact_unevictable_allowed
echo "70" > /proc/sys/vm/dirty_background_ratio
echo "500" > /proc/sys/vm/dirty_expire_centisecs
echo "0" > /proc/sys/vm/page-cluster
echo "1" > /proc/sys/vm/reap_mem_on_sigkill
echo "90" > /proc/sys/vm/dirty_ratio
echo "0" > /proc/sys/vm/laptop_mode
echo "0" > /proc/sys/vm/block_dump
echo "1" > /proc/sys/vm/compact_memory
echo "0" > /proc/sys/vm/dirty_writeback_centisecs
echo "750" > /proc/sys/vm/extfrag_threshold
echo "0" > /proc/sys/vm/oom_dump_tasks
echo "0" > /proc/sys/vm/oom_kill_allocating_task
echo "4" > /proc/sys/vm/min_free_order_shift;
echo "0" > /proc/sys/vm/laptop_mode;
echo "0" > /proc/sys/vm/block_dump;
echo "1" > /proc/sys/vm/oom_dump_tasks;
echo "5" > /proc/sys/vm/stat_interval
echo "0" > /proc/sys/vm/panic_on_oom
echo "80" > /proc/sys/vm/swappiness
echo "200" > /proc/sys/vm/vfs_cache_pressure
echo "100" > /proc/sys/vm/watermark_scale_factor
echo "80" > /proc/sys/vm/overcommit_ratio
echo "24300" > /proc/sys/vm/extra_free_kbytes
echo "512" > /proc/sys/kernel/random/read_wakeup_threshold
echo "1024" > /proc/sys/kernel/random/write_wakeup_threshold
echo "1024" > /sys/block/mmcblk0/queue/read_ahead_kb
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0/queue/add_random
echo "1024" > /sys/block/mmcblk1/queue/read_ahead_kb
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/add_random
if [ -d /sys/module/lowmemorykiller/parameters ]; then
     chmod 0644 sys/module/lowmemorykiller/parameters/*
     echo "1" > /sys/module/lowmemorykiller/parameters/oom_reaper
     echo "0" > /sys/module/lowmemorykiller/parameters/enable_lmk
     echo "0,258,417,676,824,1000" > /sys/module/lowmemorykiller/parameters/adj
     echo "0" > /sys/module/lowmemorykiller/parameters/enable_simple_lmk
     echo "6999,13998,20997,27996,34955,41994" > /sys/module/lowmemorykiller/parameters/minfree
     echo "0" > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
     echo "1" > /sys/module/lowmemorykiller/parameters/lmk_fast_run
fi
echo "0" > /d/tracing/tracing_on;
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level;
if [ -e /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd ];then
     echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd;
     echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt;
     echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv;
     echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem;
     echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr;
fi;
done
echo 100 > /sys/module/cpu_boost/parameters/input_boost_ms
echo 0-7 > /dev/cpuset/top-app/cpus
echo 0-7 > /dev/cpuset/game/cpus
echo 0-7 > /dev/cpuset/gamelite/cpus
echo "4-7" > /dev/cpuset/foreground/cpus
echo 0-7 > /dev/cpuset/background/cpus
echo 0-7 > /dev/cpuset/system-background/cpus
echo 1 > /dev/stune/top-app/schedtune.colocate
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled
echo 1 > /dev/stune/top-app/schedtune.sched_boost_no_override
echo 0 > /dev/stune/top-app/schedtune.prefer_idle
echo 100 > /dev/stune/top-app/schedtune.boost
echo 0 > /dev/stune/foreground/schedtune.colocate
echo 1 > /dev/stune/foreground/schedtune.sched_boost_enabled
echo 1 > /dev/stune/foreground/schedtune.sched_boost_no_override
echo 0 > /dev/stune/foreground/schedtune.prefer_idle
echo 100 > /dev/stune/foreground/schedtune.boost
echo 0 > /dev/stune/background/schedtune.colocate
echo 1 > /dev/stune/background/schedtune.sched_boost_enabled
echo 1 > /dev/stune/background/schedtune.sched_boost_no_override
echo 0 > /dev/stune/background/schedtune.prefer_idle
echo 100 > /dev/stune/background/schedtune.boost
echo 0 > /dev/stune/schedtune.colocate
echo 1 > /dev/stune/schedtune.sched_boost_enabled
echo 1 > /dev/stune/schedtune.sched_boost_no_override
echo 0 > /dev/stune/schedtune.prefer_idle
echo 100 > /dev/stune/schedtune.boost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/performance/up_rate_limit_us	
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/pl
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/performance/up_rate_limit_us
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/pl
if [ -e /sys/kernel/fast_charge/force_fast_charge ]; then
  echo "1" > /sys/kernel/fast_charge/force_fast_charge
fi
echo 'noop' > /sys/block/mmcblk0/queue/scheduler
echo 'noop' > /sys/block/mmcblk1/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '1024' > /sys/block/mmcblk1/queue/read_ahead_kb
echo "60" > /sys/devices/system/cpu/cpufreq/conservative/up_threshold
echo "40000" > /sys/devices/system/cpu/cpufreq/conservative/sampling_rate
echo "5" > /sys/devices/system/cpu/cpufreq/conservative/sampling_down_factor
echo "20" > /sys/devices/system/cpu/cpufreq/conservative/down_threshold
echo "25" > /sys/devices/system/cpu/cpufreq/conservative/freq_step/sys/class/kgsl/kgsl-3d0/devfreq/governor
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 
if [ -d /sys/module/adreno_idler/parameters ]; then
  echo "20" > /sys/module/adreno_idler/parameters/adreno_idler_downdifferential
  echo "99" > /sys/module/adreno_idler/parameters/adreno_idler_idlewait
  echo "5" > /sys/module/adreno_idler/parameters/adreno_idler_idleworkload
  echo "N" > /sys/module/adreno_idler/parameters/adreno_idler_active
fi
if [ -e /sys/module/msm_performance/parameters/touchboost ]; then
 echo "1" > /sys/module/msm_performance/parameters/touchboost
fi
if [ -e /sys/power/pnpmgr/touch_boost ]; then
  echo "1" > /sys/power/pnpmgr/touch_boost
fi
if [ -e /sys/module/msm_thermal/core_control/enabled ]; then
  echo "0" > /sys/module/msm_thermal/core_control/enabled
fi
if [ -d /proc/sys/fs ]; then
  echo "25" > /proc/sys/fs/lease-break-time
fi
if [ -e /sys/kernel/dyn_fsync/Dyn_fsync_active ]; then
  echo "0" > /sys/kernel/dyn_fsync/Dyn_fsync_active
fi
if [ -e /sys/module/mmc_core/parameters/use_spi_crc ]; then
  echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
fi
if [ -e /sys/devices/system/cpu/sched_mc_power_savings ]; then
  echo "0" > /sys/devices/system/cpu/sched_mc_power_savings
fi
pgrep android.process.media
killall -9 android.process.media	
pgrep mediaserver
killall -9 mediaserver
killall -9 com.google.android.gms
killall -9 com.google.android.gms.persistent
killall -9 com.google.process.gapps
killall -9 com.google.android.gsf
killall -9 com.google.android.gsf.persistent
settings delete global device_idle_constants
settings delete global device_idle_constants_user
dumpsys deviceidle enable light
dumpsys deviceidle enable deep
settings put global device_idle_constants light_after_inactive_to=30000,light_pre_idle_to=35000,light_idle_to=30000,light_idle_factor=1.7,light_max_idle_to=50000,light_idle_maintenance_min_budget=28000,light_idle_maintenance_max_budget=300000,min_light_maintenance_time=5000,min_deep_maintenance_time=10000,inactive_to=30000,sensing_to=0,locating_to=0,location_accuracy=2000,motion_inactive_to=86400000,idle_after_inactive_to=0,idle_pending_to=30000,max_idle_pending_to=60000,idle_pending_factor=2.1,quick_doze_delay_to=60000,idle_to=3600000,max_idle_to=21600000,idle_factor=1.7,min_time_to_alarm=1800000,max_temp_app_whitelist_duration=20000,mms_temp_app_whitelist_duration=20000,sms_temp_app_whitelist_duration=10000,notification_whitelist_duration=20000,wait_for_unlock=true,pre_idle_factor_long=1.67,pre_idle_factor_short=0.33
echo '0' > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo '0' > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo '0' > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo '0' > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
echo '0' > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus
restorecon -R /dev/cpuset/foreground/cpus
cat /dev/cpuset/foreground/effective_cpus
echo '4-7' > /dev/cpuset/foreground/effective_cpus
restorecon -R /dev/cpuset/foreground/effective_cpus
echo '0-7' > /dev/cpuset/top-app/cpus
echo '0-7' > /dev/cpuset/top-app/effective_cpus
cat /proc/sys/kernel/perf_cpu_time_max_percent
echo '100' > /proc/sys/kernel/perf_cpu_time_max_percent
cat /proc/sys/kernel/sched_boost
echo '1' > /proc/sys/kernel/sched_boost
cat /proc/sys/kernel/timer_migration
echo '0' > /proc/sys/kernel/timer_migration
service call SurfaceFlinger 1008 i32 1
stop logd
stop statsd
stop perfd
stop thermald
stop thermal-engine
stop mpdecision
chmod 0644 /sys/module/msm_thermal/core_control/enabled
echo '0' > /sys/module/msm_thermal/core_control/enabled
chmod 0644 /sys/module/msm_thermal/parameters/enabled
echo 'N' > /sys/module/msm_thermal/parameters/enabled
chmod 0644 /sys/module/msm_thermal/vdd_restriction/enabled
echo '0' > /sys/module/msm_thermal/vdd_restriction/enabled
echo '1' > /sys/class/kgsl/kgsl-3d0/bus_split
echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling
echo '0' > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_no_nap
echo '3' > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo '100' > /sys/module/msm_thermal/parameters/core_limit_temp_degC
echo '100' > /sys/module/msm_thermal/parameters/temp_threshold
echo 16266 > /proc/sys/vm/min_free_kbytes
echo 20960 > /sys/kernel/debug/tracing/buffer_size_kb
echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo 100 > /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 
echo 0 > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 
echo 100 > /sys/devices/system/cpu/cpufreq/performance/boost 
echo 1 > /sys/module/msm_performance/parameters/touchboost 
echo 1 > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 
echo 1 > /sys/devices/system/cpu/cpufreq/performance/align_windows 
echo performance > /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor
echo msm-adreno-tz > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo 1 > /sys/module/adreno_idler/parameters/adreno_idler_active 
echo 8 > /sys/module/lazyplug/parameters/nr_possible_cores 
echo "8" > $i/queue/iosched/lp_read_quantum;   
echo "10" > $i/queue/iosched/lp_write_quantum;   
echo "5" > $i/queue/iosched/read_idle;   
echo "15" > $i/queue/iosched/read_idle_freq;
if [ -e /sys/devices/virtual/bdi/179:0/read_ahead_kb ]; then
    echo "4096" > /sys/devices/virtual/bdi/179:0/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:0/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:0/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:1/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:1/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:2/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:2/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:3/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:3/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:4/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:4/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:5/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:5/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:6/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:6/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/7:7/read_ahead_kb ]; then
    echo "2048" > /sys/devices/virtual/bdi/7:7/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/default/read_ahead_kb ]; then
    echo "256" > /sys/devices/virtual/bdi/default/read_ahead_kb;
fi;
if [ -e /sys/module/lowmemorykiller/parameters/adj ]; then
	chown root:root /sys/module/lowmemorykiller/parameters/adj;
	echo "0,1,3,5,7,15" > /sys/module/lowmemorykiller/parameters/adj;
fi;
if [ -e /sys/module/lowmemorykiller/parameters/minfree ]; then
	chown root:root /sys/module/lowmemorykiller/parameters/minfree;
	echo "3584,4096,6144,16896,18944,24320" > /sys/module/lowmemorykiller/parameters/minfree;
fi;
echo "0" > /proc/sys/net/ipv4/tcp_timestamps;
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse;
echo "1" > /proc/sys/net/ipv4/tcp_sack;
echo "1" > /proc/sys/net/ipv4/tcp_dsack;
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle;
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling;
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout;
echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf;
echo "1" > /proc/sys/net/ipv4/route/flush;
echo "6144" > /proc/sys/net/ipv4/udp_rmem_min;
echo "6144" > /proc/sys/net/ipv4/udp_wmem_min;
echo "1" > /proc/sys/net/ipv4/tcp_rfc1337;
echo "0" > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo "0" > /proc/sys/net/ipv4/tcp_ecn;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_wmem;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_rmem;
echo "1" > /proc/sys/net/ipv4/tcp_fack;
echo "2" > /proc/sys/net/ipv4/tcp_synack_retries;
echo "2" > /proc/sys/net/ipv4/tcp_syn_retries;
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save;
echo "1800" > /proc/sys/net/ipv4/tcp_keepalive_time;
echo "0" > /proc/sys/net/ipv4/ip_forward;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/all/secure_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/secure_redirects;
echo "0" > /proc/sys/net/ipv4/ip_dynaddr;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "57344 57344 524288" > /proc/sys/net/ipv4/tcp_mem;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "2097152" > /proc/sys/net/core/rmem_max;
echo "2097152" > /proc/sys/net/core/wmem_max;
echo "262144" > /proc/sys/net/core/rmem_default;
echo "262144" > /proc/sys/net/core/wmem_default;
echo "20480" > /proc/sys/net/core/optmem_max;
echo "2500" > /proc/sys/net/core/netdev_max_backlog;
echo "50" > /proc/sys/net/unix/max_dgram_qlen;
echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
echo "NO_NEW_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
echo "NO_NORMALIZED_SLEEPER" > /sys/kernel/debug/sched_features;
busybox chmod -f 755 /system/xbin/rngd
busybox chmod -f 755 /system/xbin/entro
busybox chown -f 0.0 /system/xbin/rngd
busybox chown -f 0.0 /system/xbin/entro
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/hotplug/up_threshold ]; then
		echo "85" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/up_threshold;
		echo "40" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/down_threshold;
		echo "5" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/hotplug_in_sampling_periods;
		echo "20" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/hotplug_out_sampling_periods;
		echo "10" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/down_differential;
		#echo "1" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/io_is_busy;
		echo "20000" > /sys/devices/system/cpu/cpu0/cpufreq/hotplug/sampling_rate;
	fi;		
	if [ -e /sys/devices/system/cpu/cpu1/cpufreq/hotplug/up_threshold ]; then
		echo "85" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/up_threshold;
		echo "40" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/down_threshold;
		echo "5" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/hotplug_in_sampling_periods;
		echo "20" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/hotplug_out_sampling_periods;
		echo "10" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/down_differential;
		#echo "1" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/io_is_busy;
		echo "20000" > /sys/devices/system/cpu/cpu1/cpufreq/hotplug/sampling_rate;	
	fi;
	if [ -e /sys/devices/system/cpu/cpufreq/hotplug/up_threshold ]; then
echo "85" > /sys/devices/system/cpu/cpufreq/hotplug/up_threshold;
echo "40" > /sys/devices/system/cpu/cpufreq/hotplug/down_threshold;
echo "5" > /sys/devices/system/cpu/cpufreq/hotplug/hotplug_in_sampling_periods;
echo "20" > /sys/devices/system/cpu/cpufreq/hotplug/hotplug_out_sampling_periods;
echo "10" > /sys/devices/system/cpu/cpufreq/hotplug/down_differential;
echo "1" > /sys/devices/system/cpu/cpufreq/hotplug/io_is_busy;
echo "20000" > /sys/devices/system/cpu/cpufreq/hotplug/sampling_rate;
	fi;
#if [ -e /proc/sys/kernel/rr_interval ];
then
echo 6 > /proc/sys/kernel/rr_interval;
echo 75 > /proc/sys/kernel/iso_cpu;
else
echo 100000 > /proc/sys/kernel/sched_latency_ns;
echo 500000 > /proc/sys/kernel/sched_wakeup_granularity_ns	;
echo 750000 > /proc/sys/kernel/sched_min_granularity_ns; 
echo 200000 > /proc/sys/kernel/sched_min_granularity_ns; 
echo 400000 > /proc/sys/kernel/sched_latency_ns;
echo 100000 > /proc/sys/kernel/sched_wakeup_granularity_ns	; 
echo -1 > /proc/sys/kernel/sched_rt_runtime_us; 
echo 100000 > /proc/sys/kernel/sched_rt_period_us;
echo 95000 > /proc/sys/kernel/sched_rt_runtime_us;
fi;
for i in $STL $BML $MMC $TFSR; do
	echo 0 > $i/queue/rotational
	echo 1 > $i/queue/iosched/low_latency
	echo 1 > $i/queue/iosched/back_seek_penalty
	echo 1000000000 > $i/queue/iosched/back_seek_max #1024 
	echo 3 > $i/queue/iosched/slice_idle #0
	echo 16 > $i/queue/iosched/quantum #8
	echo 4 > $i/queue/iosched/fifo_batch #1
done
for i in $STL $BML $ZRM $MTD;
do
	if [ -e $i/queue/iosched/writes_starved ];
	then
		echo 2 > $i/queue/iosched/writes_starved;
	fi;
done;	
chown 0.0 /sys/kernel/mm/ksm/pages_to_scan;
chmod 664 /sys/kernel/mm/ksm/pages_to_scan;
chown 0.0 /sys/kernel/mm/ksm/sleep_millisecs;
chmod 664 /sys/kernel/mm/ksm/sleep_millisecs;
chown 0.0 /sys/kernel/mm/ksm/run;
chmod 664 /sys/kernel/mm/ksm/run;
echo "1" > /sys/kernel/mm/ksm/run;
echo "12800" > /sys/kernel/mm/ksm/pages_to_scan;
echo "15000" > /sys/kernel/mm/ksm/sleep_millisecs;
echo "524288" > /proc/sys/fs/file-max;
echo "32000" > /proc/sys/fs/inotify/max_queued_events;
echo "256" > /proc/sys/fs/inotify/max_user_instances;
echo "10240" > /proc/sys/fs/inotify/max_user_watches;
echo "1048576" > /proc/sys/fs/nr_open;
echo "4096" > /proc/sys/net/ipv4/udp_rmem_min; 
echo "4096" > /proc/sys/net/ipv4/udp_wmem_min; 
# Optimize non-rotating storage; 
for i in $STL $BML $MMC $ZRM $MTD $RAM;
do
	#IMPORTANT!
	if [ -e $i/queue/rotational ]; 
	then
		echo 0 > $i/queue/rotational; 
	fi;
	if [ -e $i/queue/nr_requests ];
	then
		echo 1024 > $i/queue/nr_requests; # for starters: keep it sane
	fi;
	if [ -e $i/queue/iosched/back_seek_penalty ];
	then 
		echo 1 > $i/queue/iosched/back_seek_penalty;
	fi;
	if [ -e $i/queue/iosched/low_latency ];
	then
		echo 1 > $i/queue/iosched/low_latency;
	fi;
	if [ -e $i/queue/iosched/slice_idle ];
	then 
		echo 1 > $i/queue/iosched/slice_idle; # previous: 1
	fi;
	if [ -e $i/queue/iosched/fifo_batch ];
	then
		echo 4 > $i/queue/iosched/fifo_batch;
	fi;
	if [ -e $i/queue/iosched/writes_starved ];
	then
		echo 4 > $i/queue/iosched/writes_starved;
	fi;
	if [ -e $i/queue/iosched/quantum ];
	then
		echo 16 > $i/queue/iosched/quantum;
	fi;
	if [ -e $i/queue/iosched/rev_penalty ];
	then
		echo 1 > $i/queue/iosched/rev_penalty;
	fi;
	if [ -e $i/queue/iosched/hp_read_quantum ];
	then
	echo "20"   >  $i/queue/iosched/hp_read_quantum;   
	fi;
	if [ -e $i/queue/iosched/rp_read_quantum ];
	then
	echo "20"   >  $i/queue/iosched/rp_read_quantum;   
	fi;
	if [ -e $i/queue/iosched/hp_write_quantum ];
	then
	echo "10"   >  $i/queue/iosched/hp_write_quantum;   
	fi;
	if [ -e $i/queue/iosched/rp_write_quantum ];
	then
	echo "10"   >  $i/queue/iosched/rp_write_quantum;   
	fi;
	if [ -e $i/queue/iosched/rp_write_quantum ];
	then
	echo "10"   >  $i/queue/iosched/rp_write_quantum;   
	fi;
	if [ -e $i/queue/iosched/lp_read_quantum ];
	then
	echo "8"   >  $i/queue/iosched/lp_read_quantum;   
	fi;
	if [ -e $i/queue/iosched/lp_swrite_quantum ];
	then
	echo "8"   >  $i/queue/iosched/lp_swrite_quantum;   
	fi;
	if [ -e $i/queue/iosched/read_idle ];
	then
	echo "5"   >  $i/queue/iosched/read_idle;   
	fi;
	if [ -e $i/queue/iosched/read_idle_freq ];
	then
	echo "15"   >  $i/queue/iosched/read_idle_freq;   
	fi;
	if [ -e $i/queue/iostats ];
	then
		echo "0" > $i/queue/iostats;
	fi;
	if [ -e $i/queue/rq_affinity ];
	then
	echo "2"   >  $i/queue/rq_affinity;   
	fi;
	if [ -e $i/queue/read_ahead_kb ];
	then
		echo "256" >  $i/queue/read_ahead_kb;
	fi;
echo "1"   >  $i/queue/nomerges
echo "128" >  $i/queue/max_sectors_kb
done;	
fstrim /cache
fstrim /system
fstrim /data