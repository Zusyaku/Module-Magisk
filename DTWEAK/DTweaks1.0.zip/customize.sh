#!/sbin/sh
 
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
ui_print " "
ui_print "     🌟 Dtweaks Tweaks 🌟"
ui_print "       🕶 INSTALLED 🕶"
ui_print " "
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"

unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
