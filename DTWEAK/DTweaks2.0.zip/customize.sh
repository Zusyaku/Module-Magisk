#!/sbin/sh
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
ui_print "      ×××××     ×××××"
ui_print "      |     ×     | "
ui_print "      |     ×     | "
ui_print "      ×××××       × "
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
ui_print " ✔️ Installation worked"
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°" 
ui_print " INFORMATION :"
ui_print " BUSYBOX NEEDED "
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
