#!/sbin/sh
 
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
ui_print "      ×××××     ×××××"
ui_print "      |     ×     | "
ui_print "      |     ×     | "
ui_print "      ×××××       × "
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°"
ui_print " ✔️ Installation worked"
ui_print " °°°°°°°°°°°°°°°°°°°°°°°°°" 

unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
