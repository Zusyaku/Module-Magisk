#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

#!/system/bin/sh
MODDIR=${0%/*}

sleep 30
# config enabler
# by Zackptg5
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh);;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done

# Wait for boot to finish completely
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

#CPU
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient

# LMK & Zram
stop perfd
echo '1' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '60' > /proc/sys/vm/swappiness
rm /data/system/perfd/default_values
start perfd

#I/O
echo 'deadline' > /sys/block/mmcblk0/queue/scheduler
echo 'deadline' > /sys/block/mmcblk1/queue/scheduler

# Google Service Config Reduce Drain
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService"
su -c "pm disable com.google.android.gms/NearbyMessagesService"
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService"
su -c "pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService"

# GMS
# & Other Apps Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.apps.turbo'
sleep '0.001'
su -c 'pm enable com.google.android.apps.wellbeing'
sleep '0.001'
su -c 'pm enable com.google.android.gm'
sleep '0.001'
su -c 'pm enable com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/com.google.android.gms.auth.frp.FactoryResetProtectionActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/com.google.android.gms.gcm.GcmDiagnostics'
sleep '0.001'
su -c 'pm enable com.google.android.gms/com.google.android.gms.mdm.LockscreenActivityPermissionTrampoline'
sleep '0.001'
su -c 'pm enable com.google.android.gms/com.google.android.gms.tapandpay.diagnostics.TapDiagnosticsActivity'
sleep '0.001'
su -c 'pm enable com.google.android.googlequicksearchbox'
sleep '0.001'
su -c 'pm enable com.google.android.play.games'
sleep '0.001'
su -c 'pm enable com.google.android.youtube/fi.razerman.youtube.XSettingActivity'
sleep '0.001'
su -c 'pm enable com.vanced.android.youtube/fi.razerman.youtube.XSettingActivity'
sleep '0.001'
su -c 'pm disable com.google.android.apps.messaging/.shared.analytics.recurringmetrics..AnalyticsAlarmReceiver'
sleep '0.001'
su -c 'pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService'
sleep '0.001'
su -c 'pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService'
sleep '0.001'
su -c 'pm disable com.google.android.calendar/com.google.android.calendar.ICalLauncher'
sleep '0.001'
su -c 'pm disable com.google.android.calendar/com.google.android.calendar.PrivacyPolicyActivity'
sleep '0.001'
su -c 'pm disable com.google.android.calendar/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'
su -c 'pm disable com.google.android.calendar/com.google.android.libraries.surveys.internal.view.SurveyActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.android.mail.ui.accountlayer.ShowPrivacyPolicyActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.google.android.libraries.hub.feedback.impl.ShowPrivacyPolicyActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.google.android.libraries.surveys.internal.view.SurveyActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.google.apps.tiktok.nav.gateway.GatewayActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gm/com.google.android.libraries.communications.conference.ui.intents.ConferenceGatewayActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.auth.managed.ui.SetupWorkProfileActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.auth.proximity.multidevice.SettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.auth.TokenActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.feedback.FeedbackActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.feedback.IntentListenerFeedbackActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.fitness.settings.FitnessSettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.googlehelp.contact.chat.ChatSupportRequestFormActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.googlehelp.helpactivities.DeviceSignalsExportActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.googlehelp.helpactivities.HelpActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.googlehelp.helpactivities.SystemAppTrampolineActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.locationsharing.activity.LocationSharingRedirectActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.locationsharing.updateshares.UpdateSharesActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.mobiledataplan.ui.MobileDataPlanSettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.mobiledataplan.ui.MobileDataPlanDetailActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.discovery.devices.DevicesListActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.exposurenotification.settings.SettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.messages.settings.NearbyMessagesAppOptInActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.sharing.ContactSelectActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.sharing.ReceiveSurfaceActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.sharing.SettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.sharing.SettingsActivityAlias'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.nearby.sharing.ShareSheetActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.tapandpay.settings.TapAndPaySettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.tapandpay.tokenization.AddNewCardThroughBrowserActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gms/com.google.android.gms.thunderbird.settings.ThunderbirdSettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.gsf/com.google.android.gsf.settings.SettingsTosActivity'
sleep '0.001'
su -c 'pm disable com.google.android.location.internal.UPLOAD_ANALYTICS'
sleep '0.001'
su -c 'pm disable com.google.android.youtube/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'
su -c 'pm disable com.google.android.inputmethod.latin/com.google.android.apps.inputmethod.latin.spelling.LatinSpellCheckerSettingsActivity'
sleep '0.001'
su -c 'pm disable com.google.android.inputmethod.latin/com.google.android.apps.inputmethod.latin.sharing.LinkReceivingLauncherActivity'
sleep '0.001'
su -c 'pm disable com.google.android.inputmethod.latin/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'
su -c 'pm disable com.google.android.youtube/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'
su -c 'pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.messenger.intents.SecureSameTaskIntentHandlerActivity'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.messenger.intents.SameTaskIntentHandlerActivity'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.messenger.intents.FamilyIntentHandlerActivity'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.quicksilver.shortcut.QuicksilverShortcutExternalActivity'
sleep '0.001'
su -c 'pm disable com.facebook.orca/com.facebook.quicksilver.QuicksilverShortcutExternalActivity'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.alex_veneno'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.clo_aestheticwalls_sj'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.clo_procons'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.clo_tinted'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.colorful'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.du_crot'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.got'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.idk_sumtim'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.ig_conejocelestial'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.nature'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.naturerandom'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.poly'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.purplegorilla'
sleep '0.001'
su -c 'pm disable org.omnirom.omnistyle/org.omnirom.omnistyle.wavvy'
sleep '0.001'
su -c 'pm disable com.spotify.music/com.spotify.magiclink.MagicLinkActivity'
sleep '0.001'
su -c 'pm disable com.spotify.music/com.spotify.mobile.android.sso.AuthorizationActivity'
sleep '0.001'
su -c 'pm disable com.spotify.music/com.spotify.music.features.waze.WazeReturnActivity'
sleep '0.001'
su -c 'pm disable com.vanced.android.youtube/com.google.android.libraries.social.licenses.LicenseMenuActivity'
sleep '0.001'

# Analytics Remover
rm -rf /data/data/com.rahul.videoderbeta/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.google.android.deskclock/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.google.android.play.games/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.digibites.accubattery/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.vanced.android.youtube/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.paget96.lsandroid/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.samsung.android.mobileservice/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/droom.sleepIfUCan/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.sec.android.app.samsungapps/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.digibites.accubattery/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.sec.android.daemonapp/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.osp.app.signin/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.google.android.googlequicksearchbox/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.core.lntmobile/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.samsung.android.dynamiclock/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/frc_1:633738944520:android:716b5964e99d2c3d_firebase_settings.xml
rm -f /data/data/com.camerasideas.instashot/shared_prefs/frc_1:1000386510336:android:ab5973db7e7e86ed_firebase_settings.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.firebase.common.prefs:W0RFRkFVTFRd+MTo1OTM5NTA2MDI0MTg6YW5kcm9pZDpjNGRhMWMwNTdjZjU3YmE4.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/frc_1:760348033671:android:f6afd7b67eae3860_firebase_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/frc_1:1002943954979:android:bfc8b0f2ed5f47a0_firebase_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/frc_1:275128417090:android:3dc63557758b5b0f_firebase_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/frc_1:757324348735:android:caaddb32e54f9271_firebase_settings.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/frc_1:76973129151:android:ab00156b263ee3195ef50a_firebase_settings.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.firebase.common.prefs:W0RFRkFVTFRd+MTo1OTM5NTA2MDI0MTg6YW5kcm9pZDpjNGRhMWMwNTdjZjU3YmE4.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/telemetry_service_key.xml
rm -f /data/data/com.samsung.android.biometrics.app.setting/shared_prefs/com.samsung.android.biometrics.app.setting_preferences.xml
rm -f /data/data/com.samsung.android.tadownloader/shared_prefs/tad_biometrics_info.xml
rm -f /data/data/com.google.android.gms/shared_prefs/GnssmetricsPH.xml
rm -f /data/data/com.google.android.gms/shared_prefs/com.google.android.metrics.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.samsung.android.game.gamehome/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.samsung.android.game.gamehome/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.sdk.android.crashlytics-core:com.crashlytics.android.core.CrashlyticsCore.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.hiya.star/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.hiya.star/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/ir.stsepehr.hamrahcard/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/ir.stsepehr.hamrahcard/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.intsig.camscanner/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.intsig.camscanner/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.samsung.android.mobileservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.appsedge/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.themestore/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.quicktool/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.contacts/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.calendar/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.samsungapps/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.routines/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.net.wifi.wifiguider/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.messaging/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.galaxyfinder/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dialer/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.daemonapp/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.social/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.applock/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.taskedge/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdecservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdx.quickboard/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.aodservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.storyservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dqagent/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.osp.app.signin/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs_runestone.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs_ad.xml
rm -f /data/data/com.samsung.android.allshare.service.fileshare/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.camera/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdx/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.game.gametools/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dynamiclock/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.simplesharing/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.lool/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.cocktailbarservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.myfiles/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.video/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.launcher/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.android.systemui/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.samsung.android.incallui/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.netflix.mediaclient/shared_prefs/com.netflix.mediaclient.client_cast_analytics_data.xml
rm -f /data/data/com.instagram.android/shared_prefs/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver.xml
rm -f /data/data/com.instagram.android/shared_prefs/analyticsprefs.xml
rm -f /data/data/com.instagram.android/shared_prefs/rti.mqtt.analytics.xml

# GMS blocker v1.1
#By FDE.AI 
busybox killall -9 com.google.android.gms
busybox killall -9 com.google.android.gms.persistent
busybox killall -9 com.google.process.gapps
busybox killall -9 com.google.android.gsf
busybox killall -9 com.google.android.gsf.persistent

su -c "pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorMapActivity"
sleep "0.001"
su -c  "pm disable com.google.android.gms/com.google.android.location.settings.ActivityRecognitionPermissionActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.GoogleLocationSettingsActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.LocationHistorySettingsActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.LocationSettingsCheckerActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingContentProvider"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.LocationContentProvider"
sleep "0.001"
su -c "pm enable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.gms.ads.config.GServicesChangedReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.jams.SystemEventReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.config.FlagsReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.social.DoritosReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.AnalyticsReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver"
sleep "0.001"
su -c "pm enable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsSamplerReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ActiveReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ClockworkFallbackReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ImposeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$SecretCodeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$TriggerReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.checkin.EventLogService\$Receiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ExternalChangeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.GcmRegistrationReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.copresence.GcmRegistrationReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.copresence.GservicesBroadcastReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.LocationProviderEnabler"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.NlpNetworkProviderSettingsUpdateReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity\$LocationModeChangingReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ImplicitSignalsReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor"
sleep "0.001"
su -c "pm disable com.google.android.gms/.location.copresence.GcmBroadcastReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.location.reporting.service.GcmBroadcastReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.social.location.GservicesBroadcastReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$Receiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$OtaPolicyReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.ads.AdRequestBrokerService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.GservicesValueBrokerService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdNotificationService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.ads.identifier.service.AdvertisingIdService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.jams.NegotiationService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.pan.PanService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.ads.social.GcmSchedulerWakeupService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.AnalyticsService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.internal.PlayLogReportingService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.service.AnalyticsService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.analytics.service.RefreshEnabledStateService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.auth.be.proximity.authorization.userpresence.UserPresenceService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.common.analytics.CoreAnalyticsIntentService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.common.stats.GmsCoreStatsService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.backup.BackupStatsService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionAsyncService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionServiceBroker"
sleep "0.001"
su -c "pm disable com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.checkin.CheckinService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.checkin.EventLogService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsUploadIntentService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.DeleteHistoryService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.DispatchingService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.InternalPreferenceServiceDoNotUse"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.LocationHistoryInjectorService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingAndroidService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingSyncService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.activity.HardwareArProviderService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.fused.FusedLocationService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.fused.service.FusedProviderService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.geocode.GeocodeService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.geofencer.service.GeofenceProviderService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.GoogleLocationManagerService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.location.places.PlaylogService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.places.service.GeoDataService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.places.service.PlaceDetectionService"
sleep "0.001"
su -c "pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService"
sleep "0.001"
su -c "pm disable com.google.android.gms/.config.ConfigService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.stats.PlatformStatsCollectorService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.usagereporting.service.UsageReportingService"
sleep "0.001"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.network.LocationProviderChangeReceiver"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.server.GoogleLocationService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.PendingIntentCallbackService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.network.NetworkLocationService"
sleep "0.001"
su -c "pm enable com.google.android.gms/com.google.android.location.util.PreferenceService"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateActivity"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity"
sleep "0.001"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.checkin.EventLogService\$Receiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService\$Receiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.checkin.CheckinService"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.checkin.EventLogService"
sleep "0.001"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService"
sleep "0.001"
su -c "pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService"
sleep "0.001"
su -c "pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService"
sleep "0.001"
su -c "pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService"
sleep "0.001"
su -c "pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService"
sleep "0.001"
su -c "pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService"
sleep "0.001"

#By Ravensia
su -c pm enable com.google.android.gms/.people.sync.PeopleSyncService
su -c pm enable com.google.android.gms/.people.sync.focus.ContactsSyncAdapterService
su -c pm enable com.google.android.gms/.fitness.sync.FitnessSyncAdapterService
su -c pm enable com.google.android.syncadapters.calendar/.CalendarSyncAdapterService
su -c pm enable com.google.android.calendar/com.google.android.syncadapters.calendar.CalendarSyncAdapterService
su -c pm enable com.google.android.gms/.smartdevice.setup.accounts.AccountsService
su -c pm enable com.google.android.gms/.auth.account.be.accountstate.AccountStateSyncService
su -c pm enable com.google.android.gms/.appstate.service.AppStateSyncService
su -c pm enable com.google.android.gms/.security.verifier.ApkUploadService
su -c pm enable com.google.android.gms/.icing.service.AppIndexingService
su -c pm enable com.google.android.gms/.photos.autobackup.service.AutoBackupService
su -c pm enable com.google.android.gms/.backup.BackupAccountManagerService
su -c pm enable com.google.android.gms/.people.service.BackupAndSyncOptInValidationService
su -c pm enable com.google.android.gms/.backup.stats.BackupStatsService
su -c pm enable com.google.android.gms/.backup.BackupTransportMigratorService
su -c pm enable com.google.android.gms/.backup.BackupTransportService
su -c pm enable com.google.android.gms/.backup.component.D2dMigrateHelperService
su -c pm enable com.google.android.gms/.nearby.exposurenotification.service.ExposureMatchingService
su -c pm enable com.google.android.gms/.deviceconnection.service.DeviceConnectionWatcherService
su -c pm enable com.google.android.gms/.fido.fido2.pollux.CableAuthenticatorService
su -c pm enable com.google.android.gms/.thunderbird.EmergencyPersistentService
su -c pm enable com.google.android.gms/.lockbox.LockboxService
su -c pm enable com.google.android.gms/.gcm.nts.SchedulerService
su -c pm enable com.google.android.gms/.clearcut.debug.ClearcutDebugDumpService
su -c pm enable com.google.android.gms/.icing.service.IndexWorkerService
su -c pm enable com.google.android.gms/.auth.setup.devicesignals.LockScreenService
su -c pm enable com.google.android.gms/com.google.android.location.reporting.service.DispatchingService
su -c pm enable com.google.android.gms/com.google.android.location.internal.PendingIntentCallbackService
su -c pm enable com.google.android.gms/com.google.android.location.internal.server.GoogleLocationService
su -c pm enable com.google.android.gms/com.google.android.location.internal.GoogleLocationManagerService
su -c pm enable com.google.android.gms/.location.persistent.LocationPersistentService
su -c pm enable com.google.android.gms/.nearby.bootstrap.service.NearbyBootstrapService
su -c pm enable com.google.android.gms/.nearby.connection.service.NearbyConnectionsAndroidService
su -c pm enable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
su -c pm enable com.google.android.gms/.nearby.messages.service.NearbyMessagesService
su -c pm enable com.google.android.gms/.checkin.CheckinService
su -c pm enable com.google.android.gms/.checkin.CheckinApiService
su -c pm enable com.google.android.gms/.checkin.EventLogService
su -c pm enable com.google.android.gms/.common.config.PhenotypeCheckinService

# WakeLock Profile Tweaks Set Config
if [ -e "/sys/class/misc/boeffla_wakelock_blocker" ]; then
    write /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker "qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;NETLINK;NETLINK;NETLINK;mpss_IPCRTR;NETLINK;eventpoll;NETLINK;IPCRTR_mpss_rx;NETLINK;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12"

sleep 0.5;

elif [ -e "/sys/devices/virtual/misc/boeffla_wakelock_blocker" ]; then
    write /sys/devices/virtual/misc/boeffla_wakelock_blocker/wakelock_blocker "qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;NETLINK;NETLINK;NETLINK;mpss_IPCRTR;NETLINK;eventpoll;NETLINK;IPCRTR_mpss_rx;NETLINK;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12"

#Charging Tweaks
chmod 777 /sys/class/power_supply/*/*
chmod 777 /sys/module/qpnp_smbcharger/*/*
chmod 777 /sys/module/dwc3_msm/*/*
chmod 777 /sys/module/phy_msm_usb/*/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '150' > /sys/class/power_supply/bms/temp_cool
echo '460' > /sys/class/power_supply/bms/temp_hot
echo '460' > /sys/class/power_supply/bms/temp_warm
echo '3000000' > /sys/class/power_supply/usb/current_max
echo '3000000' > /sys/class/power_supply/usb/hw_current_max
echo '3000000' > /sys/class/power_supply/usb/pd_current_max
echo '3000000' > /sys/class/power_supply/usb/ctm_current_max
echo '3000000' > /sys/class/power_supply/usb/sdp_current_max
echo '3000000' > /sys/class/power_supply/main/current_max
echo '3000000' > /sys/class/power_supply/main/constant_charge_current_max
echo '3000000' > /sys/class/power_supply/battery/current_max
echo '3000000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '4600000' > /sys/class/qcom-battery/restricted_current
echo '3000000' > /sys/class/power_supply/pc_port/current_max
echo '3000000' > /sys/class/power_supply/constant_charge_current__max
sleep 1
done

#Fstrim 
fstrim /cache
fstrim /system
fstrim /data

#Turn Off Swap
swapoff /dev/block/zram0
#
# Resetting ZRAM
echo 1 > /sys/block/zram0/reset
#
# Setting 4 GB ZRAM
echo 4192000000 > /sys/block/zram0/disksize
#
# Making ZRAM Swapable
mkswap /dev/block/zram0
#
# Starting Swap On ZRAM
swapon /dev/block/zram0
#
# Setting Low Memory Killer Parameters According To Total Memory
echo "256,10240,32000,34000,36000,38000" > /sys/module/lowmemorykiller/parameters/minfree
#
# Setting Swappiness To 100
echo 100 > /proc/sys/vm/swappiness
#
# done
#
free

cat /sys/module/lowmemorykiller/parameters/minfree

# Always end with success status
exit 0

