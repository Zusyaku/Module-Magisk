#!/system/bin/sh
TIME=2
PRINT1() {
ui_print "★彡[Gamers Edition]彡★"
ui_print "* By R.kashyap * "
ui_print "* Thermal Engine Conf For X00TD Phone *"
}
PRINT2() {
ui_print "* Enjoy Your New Custom Thermal Management  with few tweaks*"
}
CHECK() {
 D=$(getprop ro.product.device 2>/dev/null)
 P=$(getprop ro.build.product 2>/dev/null)
 VD=$(getprop ro.product.vendor.device 2>/dev/null)
 VP=$(getprop ro.vendor.product.device 2>/dev/null)
 DN=X00TD

for name in $D $P $VD $VP; do
 if [ "$DN" == "$name" ]; then
  why=1
  fi;
 done;

sleep $TIME

if [ "$why" == "0" ]; then
 ui_print "X00TD Only..!!!"
 abort "* Installation Not Approved , Aborting !!! *"
elif [ "$why" == "1" ]; then
 ui_print "* Installation Approved , X00TD Detected *"
fi;
}

PRINT1
CHECK
PRINT2
