
ROPRODEV=$(getprop ro.product.device)

ui_print "Your device is recognized as $ROPRODEV" 
ui_print "It should be one of below:" 
ui_print "  lavender"
ui_print ""
ui_print "In decreasing order of support"
ui_print ""
ui_print ""

if device_check "cepheus"; then 
	rm -rf $TMPDIR/system/lib/
	rm -rf $TMPDIR/system/lib64/
	ui_print "cephy was here, it hates poco libs"
fi

if device_check "perseus"; then 
	rm -rf $TMPDIR/system/lib/
	rm -rf $TMPDIR/system/lib64/
	ui_print "persy was here, it hates poco libs"
fi
