#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

chmod 0777 /sys/class/power_supply/bms/temp_cool
echo 150 > /sys/class/power_supply/bms/temp_cool
chmod 0644 /sys/class/power_supply/bms/temp_cool

chmod 0777 /sys/class/power_supply/bms/temp_warm
echo 490 > /sys/class/power_supply/bms/temp_warm
chmod 0644 /sys/class/power_supply/bms/temp_warm

chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
echo 3300000 > /sys/class/power_supply/battery/constant_charge_current_max
chmod 0644 /sys/class/power_supply/battery/constant_charge_current_max

chmod 0777 /sys/class/power_supply/battery/input_current_limited
echo 0 > /sys/class/power_supply/battery/input_current_limited
chmod 0644 /sys/class/power_supply/battery/input_current_limited

chmod 0777 /sys/class/power_supply/battery/step_charging_enabled
echo 1 > /sys/class/power_supply/battery/step_charging_enabled
chmod 0644 /sys/class/power_supply/battery/step_charging_enabled

chmod 0777 /sys/class/power_supply/battery/sw_jeita_enabled
echo 0 > /sys/class/power_supply/battery/sw_jeita_enabled
chmod 0644 /sys/class/power_supply/battery/sw_jeita_enabled