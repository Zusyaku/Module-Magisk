TEXT="ᴅᴇꜱᴛʀᴏʏ ᴀʟʟ ᴘᴀᴛʜ ᴏꜰ ᴛʜᴇʀᴍᴀʟꜱ ɪɴ $(getprop ro.build.product) ꜱᴏᴄ: $(getprop ro.product.board) ᴋᴇʀɴᴇʟ: $(uname -r). "
ui_print ""
ui_print "    ╭━━┳╮╭╮╱╱╱╱╭━━╮ "
ui_print "    ┃╭╮┃┣╋╋┳┳━╮┃━━╋┳┳━┳━┳┳╮ "
ui_print "    ┃┣┫┃━┫┃╭┫╋╰╋━━┃┃┃╋┃┻┫╭╯ "
ui_print "    ╰╯╰┻┻┻┻╯╰━━┻━━┻━┫╭┻━┻╯ "
ui_print "    ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰╯ "
ui_print ""
ui_print "- By: $(grep_prop author $MODPATH/module.prop) "
ui_print "- Status: $(grep_prop version $MODPATH/module.prop) | $(grep_prop versionCode $MODPATH/module.prop) "
ui_print ""
sed -i "/description=/c description=${TEXT}" $MODPATH/module.prop;
if [ -f $MODPATH/common/Empty.tar.xz ]; then
 tar -xf $MODPATH/common/Empty.tar.xz -C $MODPATH 2>/dev/null
 rm -f $MODPATH/common/Empty.tar.xz 2>/dev/null
 rm -rf $MODPATH/LICENSE 2>/dev/null
 rm -rf $MODPATH/README.md 2>/dev/null
fi