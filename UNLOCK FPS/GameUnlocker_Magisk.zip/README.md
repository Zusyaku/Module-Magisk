##### Introduction: GAME乛Unlocker | Magisk Module

##### Authors: AkiraSuper

##### Contact Telegram: https://t.me/AkiraProjects

#### Note: Unlock game graphic and fps such as Call of Duty Mobile, PUBG, Asphalt, Blade&Soul Revolution, Mobile Legends, Black Desert Mobile, Arena Of Valor Not Working if You're using MagiskHide Props. Or others similar Modules with it. Not Work for All Games, causing SafetyNet fail. Need Xposed module to fix or bypass SafetyNet. It may break some system Apps, such as Miui Camera, Package Installer and etc.

### Version: vFINAL

- Fixed Module Not Applied Issue
- Added PUBG Mobile - 90FPS Settings
- Added COD Mobile, Asphalt & Blade&Soul Revolution - Max Settings
- Added COD Mobile - 120FPS Settings
- Added Mobile Legends - Max Settings
- Added Black Desert Mobile - Max Settings
- Added Arena Of Valor - Max Settings

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.