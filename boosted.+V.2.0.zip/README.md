# boosted v.2 
This module all about tunnig on you tcp for max speed on internet connection.

## Compatibility
* Android Jellybean+
* Selinux enforcing
* Rooted Device using this method (https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445).

## Change Log
### boost net test rc01
* Initial release

### boost net test rc02
* Old tweak using zep stuff

### boost net test rc03
* Another method touching buildprop

### boost net test rc04
* Change value


### boosted v1.0
* Edit later

### boosted v2.0
* Edit later

