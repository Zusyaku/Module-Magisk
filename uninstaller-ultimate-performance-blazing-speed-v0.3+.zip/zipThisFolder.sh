#!/bin/bash

zip -r renameMePlease.zip . -x ".*" -x "*/.*"
