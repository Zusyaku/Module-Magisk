#========================================
# Apolon V3
# Developer : Haxis
#========================================
#!/system/bin/sh
MODDIR=${0%/*}

$MODDIR/system/bin/extreme 2>/dev/null
$MODDIR/system/etc/init.d/tweaks 2>/dev/null
$MODPATH/system/etc/init.d/touch 2>/dev/null