#!/sbin/sh
/tmp/aroma/busybox rm -f kernel_dtb-*
/tmp/aroma/busybox rm -f new-boot.img