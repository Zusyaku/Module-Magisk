ui_print ""
ui_print "- Startin Module Installation -"
sleep 0.5
ui_print ""
ui_print "- Checking Kernel -"
ui_print ""
sleep 2.5
if [ -d /sys/devices/system/cpu/cpu0/cpufreq/interactive ]; then
 echo "- HMP Kernel Detected! -"
ui_print ""
sleep 2.0 
 echo "- Installed Custom HMP PerfHal -" 
 ui_print ""
 cp -af $MODPATH/em/hmp/perf $MODPATH/system/vendor/etc
elif [ -d /sys/devices/system/cpu/cpu0/cpufreq/schedutil ]; then
 echo "- EAS Kernel Detected! -"
ui_print ""
sleep 1.5 
 echo "- Installed Custom EAS PerfHal -"
 ui_print ""
 cp -af $MODPATH/em/eas/perf $MODPATH/system/vendor/etc
 sed -i '/persist.device_config.runtime_native.usap_pool_enabled/s/.*/persist.device_config.runtime_native.usap_pool_enabled=true/' $MODPATH/system.prop && sed -i '/ro.surface_flinger.max_frame_buffer_acquired_buffers/s/.*/ro.surface_flinger.max_frame_buffer_acquired_buffers=3/' $MODPATH/system.prop
fi 
sleep 1.0
ui_print "- ( Vol -DOWN Select / Vol +UP Next )"
ui_print ""
sleep 0.9
ui_print "- Do You Want Dynamic Thermal?"
sleep 0.2
ui_print ""
ui_print "  1. Yes ( Empty + Stock Thermal ) "
sleep 0.2
ui_print "  2. No Thanks"
sleep 0.2
ui_print ""
sleep 0.2
ui_print " Select: "
TH=1
while true; do
 ui_print "   $TH"
 if $VKSEL; then
  TH=$((TH + 1))
 else 
  break
 fi
 if [ $TH -gt 2 ]; then
  TH=1
 fi
done
ui_print " Selected: $TH "
#
case $TH in
 1 ) FCTEXTAD2="Empty/Stock"; cp -af $TMPDIR/em/t/e/* $MODPATH/system/vendor/etc && rm -rf $MODPATH/em/t/e;;
 2 ) FCTEXTAD2="None"; rm -rf $MODPATH/em/t;;
esac
ui_print "- Installed Thermal: $FCTEXTAD2 "
sleep 1.5
ui_print "   "
ui_print "- Improve Rendering Perf By Reducing Transparency & ️OpenGles Version"
sleep 0.2
ui_print " "
ui_print "    1. OpenGles v2.0 + 8 Bit Transparency  "
sleep 0.2
ui_print "    2. OpenGles v3.0 + 16 Bit Transparency "
sleep 0.2
ui_print "    3. OpenGles v3.2 + 32 Bit  (Default One)"
ui_print "   "
sleep 0.2
ui_print " Select: "
GL=1
while true; do
 ui_print "   $GL"
 if $VKSEL; then
  GL=$((GL + 1))
 else 
  break
 fi
 if [ $GL -gt 3 ]; then
  GL=1
 fi
done
ui_print "  Selected: $GL"
case $GL in 
	1 ) FCTEXTAD6="OpenGles v2.0"; sed -i '/ro.opengles.version/s/.*/ro.opengles.version=131072/' $MODPATH/system.prop && sed -i '/persist.sys.use_8bpp_alpha/s/.*/persist.sys.use_8bpp_alpha=1/' $MODPATH/system.prop;;
	2 ) FCTEXTAD6="OpenGles v3.0"; sed -i '/ro.opengles.version/s/.*/ro.opengles.version=196608/' $MODPATH/system.prop && sed -i '/persist.sys.use_16bpp_alpha/s/.*/persist.sys.use_16bpp_alpha=1/' $MODPATH/system.prop;;
	3 ) FCTEXTAD6="OpenGles v3.2"; sed -i '/ro.opengles.version/s/.*/ro.opengles.version=196610/' $MODPATH/system.prop;;
esac
ui_print "-  Installed: $FCTEXTAD6 "
ui_print "   "
ui_print ""
ui_print "- Wanna Enable Fast Charge?"
sleep 0.3
ui_print " (Max Out Charging Speed till 46°C temp) -"
ui_print ""
sleep 0.2
ui_print "  1. Yes"
sleep 0.2
ui_print "  2. No Thanks"
sleep 0.2
ui_print ""
ui_print " Select: "
FC=1
while true; do
 ui_print "   $FC"
 if $VKSEL; then
  FC=$((FC + 1))
 else 
  break
 fi
 if [ $FC -gt 2 ]; then
  FC=1
 fi
done
ui_print " Selected: $FC "
#
case $FC in
 1 ) FCTEXTAD4="Enabled Fast Charging"; cp -af $TMPDIR/em/fc/fc $MODPATH/config && rm -rf $MODPATH/em/fc;;
 2 ) FCTEXTAD4="Disabled Fast Charging"; rm -rf $MODPATH/em/fc;;
esac
ui_print "- $FCTEXTAD4 "
ui_print ""
sleep 0.5
