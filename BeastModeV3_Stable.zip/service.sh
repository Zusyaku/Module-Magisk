#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
# This script will be executed in late_start service mode
#!/system/bin/sh

if [ -e /cache/beast ]; then
rm /cache/beast
fi
if [ -e /cache/battery ]; then
rm /cache/battery
fi
if [ -e /cache/stock ]; then
rm /cache/stock
fi

sleep 50
# Log
if [ -e /storage/emulated/0/BeastMode_ON.log ]; then
rm /storage/emulated/0/BeastMode_ON.log
fi

#Kernel Tweak ( Lil Perf Gain )
echo 0 > /proc/sys/kernel/panic
echo 0 > /proc/sys/kernel/panic_on_oops
echo 0 > /proc/sys/kernel/compat-log
echo 0 > /proc/sys/kernel/sched_tunable_scaling
echo "0 0 0 0" > /proc/sys/kernel/printk

# Reducing Some System load
echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/time
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level

# Turn off some useless kernel modules that are not needed & never used
echo "0" > /sys/module/diagchar/parameters/diag_mask_clear_param
echo "1" > /sys/module/hid/parameters/ignore_special_drivers
echo "0" > /sys/module/icnss/parameters/dynamic_feature_mask
echo "0" > /sys/module/ppp_generic/parameters/mp_protocol_compress

#Disable CPU & Touch Boost (Just incase ur kernel have that shi*)
if [ -e "/sys/module/cpu_boost/parameters/boost_ms" ]; then
	echo "0" > /sys/module/cpu_boost/parameters/boost_ms
fi
if [ -e "/sys/module/msm_performance/parameters/touchboost" ]; then
	echo "0" > /sys/module/msm_performance/parameters/touchboost
fi
if [ -e /sys/power/pnpmgr/touch_boost ]; then
	echo "0" > /sys/power/pnpmgr/touch_boost
fi

# VM Tweaks
echo 6651 > /proc/sys/vm/min_free_kbytes
echo 0 > /proc/sys/vm/oom_dump_tasks

for queue in /sys/block/*/queue; do
   echo 0 > "${queue}"/add_random
   echo 0 > "${queue}"/iostats
   echo 2 > "${queue}"/nomerges
   echo 0 > "${queue}"/rotational
   echo 0 > "${queue}"/iosched/slice_idle
   echo 0 > "${queue}"/iosched/low_latency
   echo 1 > "${queue}"/iosched/group_idle
done 

# Enable Ffcahrging
ffcharge=/sys/kernel/fast_charge/force_fast_charge
if [ -e $ffcharge ]; then
echo 1 > $ffcharge
fi

# For thermal
echo 0 > /sys/module/msm_thermal/parameters/enabled
echo 0 > /sys/module/msm_thermal/vdd_restriction/enable

# Entropy (Stock bess)
echo 64 > /proc/sys/kernel/random/read_wakeup_threshold
echo 896 > /proc/sys/kernel/random/write_wakeup_threshold

#Custom LMK to stop toastapp being kill in bg
echo "18432,23040,27648,32256,55296,80640" > /sys/module/lowmemorykiller/parameters/minfree
echo 0 > /sys/module/lowmemorykiller/parameters/vmpressure_file_min

#Props
setprop debug.hwui.renderer skiagl

# init.d enabler
if [ "$1" == "-ls" ]; then LS=true; else LS=false; fi
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh) $LS && if [ -f "$i" -a -x "$i" ]; then $i & fi;;
    *) $LS || if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done


