#!/system/bin/sh
##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Uncomment and change 'MINAPI' and 'MAXAPI' to the minimum and maximum android version for your mod
# Uncomment DYNLIB if you want libs installed to vendor for oreo+ and system for anything older
# Uncomment DEBUG if you want full debug logs (saved to /sdcard)
#MINAPI=21
#MAXAPI=25
#DYNLIB=true
#DEBUG=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

ui_print " "
ui_print " "
sleep 0.20                                                 
ui_print "    @@@@@@@   @@@@@@@@   @@@@@@    @@@@@@   @@@@@@@  "
sleep 0.19
ui_print "    @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@   @@@@@@@  "
sleep 0.18
ui_print "    @@!  @@@  @@!       @@!  @@@  !@@         @@!    "
sleep 0.17
ui_print "    !@   @!@  !@!       !@!  @!@  !@!         !@!    "
sleep 0.16
ui_print "    @!@!@!@   @!!!:!    @!@!@!@!  !!@@!!      @!!    "
sleep 0.15
ui_print "    !!!@!!!!  !!!!!:    !!!@!!!!   !!@!!!     !!!    "
sleep 0.14
ui_print "    !!:  !!!  !!:       !!:  !!!       !:!    !!:    "
sleep 0.13
ui_print "    :!:  !:!  :!:       :!:  !:!      !:!     :!:    "
sleep 0.12
ui_print "     :: ::::   :: ::::  ::   :::  :::: ::      ::    "
sleep 0.11
ui_print "    :: : ::   : :: ::    :   : :  :: : :       :     "                                                 
ui_print " " 
sleep 0.10
ui_print " "         
ui_print "    @@@@@@@@@@    @@@@@@   @@@@@@@   @@@@@@@@   "
sleep 0.11
ui_print "    @@@@@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@@   "
sleep 0.12
ui_print "    @@! @@! @@!  @@!  @@@  @@!  @@@  @@!        "
sleep 0.13
ui_print "    !@! !@! !@!  !@!  @!@  !@!  @!@  !@!        "
sleep 0.14
ui_print "    @!! !!@ @!@  @!@  !@!  @!@  !@!  @!!!:!     "
sleep 0.15
ui_print "    !@!   ! !@!  !@!  !!!  !@!  !!!  !!!!!:     "
sleep 0.16
ui_print "    !!:     !!:  !!:  !!!  !!:  !!!  !!:        "
sleep 0.17
ui_print "    :!:     :!:  :!:  !:!  :!:  !:!  :!:        "
sleep 0.18
ui_print "    :::     ::   ::::: ::   :::: ::   :: ::::   "
sleep 0.19
ui_print "     :      :     : :  :   :: :  :   : :: ::    "
sleep 0.20
ui_print " " 
ui_print " "
ui_print " "
ui_print "*****************************************************"
ui_print "  " 
ui_print "  × Better CPU/GPU Performance (Less Fps-Drop)       "
sleep 1.2
ui_print "  " 
ui_print "  × Better Battery Backup On Normal usage            "
sleep 1.3
ui_print "  " 
ui_print "  × Dynamic Tweaks (Auto Disable If There's No Need) "
sleep 1.3
ui_print "  " 
ui_print "  × Credits: @HafizZiq, @akira_vishal & @NotZeeTaa     "
sleep 1.2  
ui_print "  " 
ui_print "  × Use At Your Own Risk xD                          "
ui_print "  " 
ui_print "*****************************************************"
sleep 0.9  

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
  set_perm $MODPATH/em/t/e/vendor/bin/thermal-engine 0 2000 0755 0755
  set_perm $MODPATH/em/t/e/vendor/bin/hw/android.hardware.thermal@1.0-service 0 2000 0755 0755
  set_perm $MODPATH/em/t/s/vendor/bin/thermal-engine 0 2000 0755 0755
  set_perm $MODPATH/em/t/s/vendor/bin/hw/android.hardware.thermal@1.0-service 0 2000 0755 0755
  set_perm $MODPATH/system/bin/batterymode 0 2000 0755 0755
  set_perm $MODPATH/system/bin/beastmode 0 2000 0755 0755
}

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'em/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
postfs=$TMPDIR/post-fs-data.sh
. $TMPDIR/functions.sh

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases


