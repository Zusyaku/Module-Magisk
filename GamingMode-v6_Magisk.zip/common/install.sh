ui_print ""
ui_print " ╭━━━╮╱╱╱╱╱╱╱╱╱╱╱╱╭╮╱╭╮╱╱╱╱╱╱╭━╮╱╭╮╱╱╱╭╮╱╱╱╱╱╱╱╭╮╱╱╱╭╮ "
ui_print " ┃╭━╮┃╱╱╱╱╱╱╱╱╱╱╱╱┃┃╱┃┃╱╱╱╱╱╱┃┃╰╮┃┃╱╱╱┃┃╱╱╱╱╱╱╭╯╰╮╱╱┃┃ "
ui_print " ┃┃╱╰╋━━┳╮╭┳━━┳━━╮┃╰━╯┣━━┳━━╮┃╭╮╰╯┣━━╮┃┃╱╱╭┳╮╭╋╮╭╋━━┫┃ "
ui_print " ┃┃╭━┫╭╮┃╰╯┃┃━┫━━┫┃╭━╮┃╭╮┃━━┫┃┃╰╮┃┃╭╮┃┃┃╱╭╋┫╰╯┣┫┃┃━━╋╯ "
ui_print " ┃╰┻━┃╭╮┃┃┃┃┃━╋━━┃┃┃╱┃┃╭╮┣━━┃┃┃╱┃┃┃╰╯┃┃╰━╯┃┃┃┃┃┃╰╋━━┣╮ "
ui_print " ╰━━━┻╯╰┻┻┻┻━━┻━━╯╰╯╱╰┻╯╰┻━━╯╰╯╱╰━┻━━╯╰━━━┻┻┻┻┻┻━┻━━┻╯ "
ui_print ""
ui_print "*******************************"
ui_print ""
ui_print "- By: akira_vishal "
ui_print "- Status: v6 "
ui_print "- Phone Model: $(getprop ro.product.model) "
ui_print "- System Version: Android $(getprop ro.system.build.version.release) "
ui_print "- System Structure: $ARCH "
ui_print ""
ui_print "*******************************"
ui_print ""
for apk in $(pm list packages -3 | sed 's/package://g' | sort); do
	pm disable $apk/com.google.android.gms.analytics.AnalyticsService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsJobService
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementJobService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
	pm disable $apk/com.crashlytics.android.CrashlyticsInitProvider
	pm disable $apk/com.google.android.gms.ads.AdActivity
	pm disable $apk/com.google.firebase.iid.FirebaseInstanceIdService
done
ui_print ""