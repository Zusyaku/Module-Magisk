(
sleep 3
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID
)&