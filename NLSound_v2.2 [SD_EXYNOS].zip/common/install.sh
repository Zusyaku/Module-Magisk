exec 2>$MODPATH/NLSound_install.txt

patch_xml() {
  local Name0=$(echo "$3" | sed -r "s|^.*/.*\[@(.*)=\".*\".*$|\1|")
  local Value0=$(echo "$3" | sed -r "s|^.*/.*\[@.*=\"(.*)\".*$|\1|")
  [ "$(echo "$4" | grep '=')" ] && Name1=$(echo "$4" | sed "s|=.*||") || local Name1="value"
  local Value1=$(echo "$4" | sed "s|.*=||")
  case $1 in
  "-s"|"-u"|"-i")
    local SNP=$(echo "$3" | sed -r "s|(^.*/.*)\[@.*=\".*\".*$|\1|")
    local NP=$(dirname "$SNP")
    local SN=$(basename "$SNP")
    if [ "$5" ]; then
      [ "$(echo "$5" | grep '=')" ] && local Name2=$(echo "$5" | sed "s|=.*||") || local Name2="value"
      local Value2=$(echo "$5" | sed "s|.*=||")
    fi
    if [ "$6" ]; then
      [ "$(echo "$6" | grep '=')" ] && local Name3=$(echo "$6" | sed "s|=.*||") || local Name3="value"
      local Value3=$(echo "$6" | sed "s|.*=||")
    fi
    if [ "$7" ]; then
      [ "$(echo "$7" | grep '=')" ] && local Name4=$(echo "$7" | sed "s|=.*||") || local Name4="value"
      local Value4=$(echo "$7" | sed "s|.*=||")
    fi
  ;;
  esac
  case "$1" in
    "-d") xmlstarlet ed -L -d "$3" "$2";;
    "-u") xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2";;
    "-s")
      if [ "$(xmlstarlet sel -t -m "$3" -c . "$2")" ]; then
        xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2"
      else
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      fi;;
    "-i")
      if [ "$(xmlstarlet sel -t -m "$3[@$Name1=\"$Value1\"]" -c . "$2")" ]; then
        xmlstarlet ed -L -d "$3[@$Name1=\"$Value1\"]" "$2"
      fi
      if [ -z "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value4" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -i "$SNP-$MODID" -t attr -n "$Name4" -v "$Value4" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      fi
      ;;
  esac
}

[ -f /system/vendor/build.prop ] && BUILDS="/system/build.prop /system/vendor/build.prop" || BUILDS="/system/build.prop"
SD660=$(grep "ro.board.platform=sdm660" $BUILDS)
SD665=$(grep "ro.board.platform=trinket" $BUILDS)
SD690=$(grep "ro.board.platform=lito" $BUILDS)
SD710=$(grep "ro.board.platform=sdm710" $BUILDS)
SD720G=$(grep "ro.board.platform=atoll" $BUILDS)
SD730=$(grep "ro.board.platform=sm6150" $BUILDS)
SD765G=$(grep "ro.board.platform=lito" $BUILDS)
SD820=$(grep "ro.board.platform=msm8996" $BUILDS)
SD835=$(grep "ro.board.platform=msm8998" $BUILDS)
SD845=$(grep "ro.board.platform=sdm845" $BUILDS)
SD855=$(grep "ro.board.platform=msmnile" $BUILDS)
SD865=$(grep "ro.board.platform=kona" $BUILDS)

if [ "$SD665" ] || [ "$SD690" ] || [ "$SD710" ] || [ "$SD720G" ] || [ "$SD730" ] || [ "$SD765G" ] || [ "$SD820" ] || [ "$SD835" ] || [ "$SD845" ] || [ "$SD855" ] || [ "$SD865" ]; then
  HIFI=true
ui_print " "
ui_print "- Device with support Hi-Fi detected! -"
else
  NOHIFI=false
ui_print " "
ui_print " - Device without support Hi-Fi detected! -"
fi

RN5PRO=$(grep -E "ro.product.vendor.device=whyred.*" $BUILDS)
RN6PRO=$(grep -E "ro.product.vendor.device=tulip.*" $BUILDS)
RN7=$(grep -E "ro.product.vendor.device=lavender.*" $BUILDS)
RN7PRO=$(grep -E "ro.product.vendor.device=violet.*" $BUILDS)
RN8=$(grep -E "ro.product.vendor.device=ginkgo.*" $BUILDS)
RN8T=$(grep -E "ro.product.vendor.device=willow.*" $BUILDS)
RN9S=$(grep -E "ro.product.vendor.device=curtana.*" $BUILDS)
RN9PRO=$(grep -E "ro.product.vendor.device=joyeuse.*" $BUILDS)
MI9=$(grep -E "ro.product.vendor.device=cepheus.*" $BUILDS)
MI9T=$(grep -E "ro.product.vendor.device=davinci.*" $BUILDS)
MI10=$(grep -E "ro.product.vendor.device=umi.*" $BUILDS)
K20P=$(grep -E "ro.product.vendor.device=raphael.*|ro.product.vendor.device=raphaelin.*|ro.product.vendor.device=raphaels.*" $BUILDS)
MI8=$(grep -E "ro.product.vendor.device=dipper.*" $BUILDS)
MI8P=$(grep -E "ro.product.vendor.device=equuleus.*" $BUILDS)
MI9P=$(grep -E "ro.product.vendor.device=crux.*" $BUILDS)
MIA2=$(grep -E "ro.product.vendor.device=jasmine.*" $BUILDS)
MIA3=$(grep -E "ro.product.vendor.device=laurel.*" $BUILDS)
POCOF1=$(grep -E "ro.product.vendor.device=beryllium.*" $BUILDS)
POCOF2P=$(grep -E "ro.product.vendor.device=lmi.*" $BUILDS)
POCOX3=$(grep -E "ro.product.vendor.device=surya.*" $BUILDS)

MPATHS="$(find /system /vendor -type f -name "mixer_paths*.xml")"
APINF="$(find /system /vendor -type f -name "audio_platform_info*.xml")"
ACONFS="$(find /system /vendor -type f -name "audio_configs*.xml")"

NLS=$MODPATH/common/NLSound
OTHR=$MODPATH/common/NLSound/other
FIRMRN5MI9=$MODPATH/common/NLSound/firmrn5mi9
FIRMRN7=$MODPATH/common/NLSound/firmrn7
FIRM9T=$MODPATH/common/NLSound/firm9t
FIRMMI9PRO=$MODPATH/common/NLSound/firmmi9pro
FIRMRN7PRO=$MODPATH/common/NLSound/firmrn7pro
FIRMK20PRO=$MODPATH/common/NLSound/firmk20pro
FIRMMI8=$MODPATH/common/NLSound/firmmi8
FIRMMI8PRO=$MODPATH/common/NLSound/firmmi8pro
FIRMMIA2=$MODPATH/common/NLSound/firmmia2
FIRMPOCOF1=$MODPATH/common/NLSound/firmpocof1
FIRMPOCOF2PRO=$MODPATH/common/NLSound/firmpocof2pro
FEATURES=$MODPATH/common/NLSound/features
WHYDED=$MODPATH/common/NLSound/whyded
UNI=$MODPATH/common/NLSound/universal

SETC=/system/SETC
SVSETC=/system/vendor/SETC
DEVICEFEA=/system/etc/device_features

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/
chmod -R 0755 $MODPATH/tools

for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
    cp_ch $ORIGDIR$OMIX $MIX
    sed -i 's/\t/  /g' $MIX
    done

sleep 1
ui_print " "
ui_print " - Disable Deep Buffer -"
  ui_print "***************************************************"
  ui_print "* [1/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*               This option disable               *"
  ui_print "*            deep buffer in your device.          *"
  ui_print "*         If you want more low frequencies,       *"
  ui_print "*                skip this option.                *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Disable deep buffer?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Processed . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
	echo -e '\naudio.deep_buffer.media=false\nvendor.audio.deep_buffer.media=false\nqc.audio.deep_buffer.media=false\nro.qc.audio.deep_buffer.media=false\npersist.vendor.audio.deep_buffer.media=false' >> $MODPATH/system.prop
fi

sleep 1    	
ui_print " "
ui_print " - Improve volume levels and change media volume steps -"
  ui_print "***************************************************"
  ui_print "* [2/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*               A T T E N T I O N!                *"
  ui_print "*   Confirming this option may harm your device!  *"
  ui_print "*NLSound Team is not responsible for your devices!*"
  ui_print "*              Choose at your own risk!           *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Improve volume levels and media volume steps?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Improving volume levels . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
    patch_xml -u $MIX '/mixer/ctl[@name="RX0 Digital Volume"]' "88"
    patch_xml -u $MIX '/mixer/ctl[@name="RX1 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX2 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX3 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX4 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX5 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX6 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX7 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "88"
    patch_xml -u $MIX '/mixer/ctl[@name="RX0 Mix Digital Volume"]' "88"
    patch_xml -u $MIX '/mixer/ctl[@name="RX1 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX2 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX3 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX4 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX5 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX6 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX7 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX8 Mix Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_RX0 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_RX1 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_RX2 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_RX0 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_RX1 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_RX2 Digital Volume"]' "88"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "88"
	done	
	ui_print " "
    ui_print " - Improving media volume steps. . . -"
    sleep 1
    ui_print " "
    ui_print " - Please, wait . . . -"
	echo -e '\nro.config.media_vol_steps=40' >> $MODPATH/system.prop
fi

sleep 1    	
ui_print " "
ui_print " - Improve microphones levels -"
  ui_print "***************************************************"
  ui_print "* [3/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*             This option improving               *"
  ui_print "*          microphone volume levels in            *"
  ui_print "*                 your device.                    *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Improve microphone levels?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Improving microphone levels . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
	patch_xml -u $MIX '/mixer/ctl[@name="ADC1 Volume"]' "15"
	patch_xml -u $MIX '/mixer/ctl[@name="ADC2 Volume"]' "15"
	patch_xml -u $MIX '/mixer/ctl[@name="ADC3 Volume"]' "15"
	patch_xml -u $MIX '/mixer/ctl[@name="ADC4 Volume"]' "15"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC0 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC1 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC2 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC3 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC4 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC5 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC6 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC7 Volume"]' "90"
	patch_xml -u $MIX '/mixer/ctl[@name="DEC8 Volume"]' "90"
	done	
fi

sleep 1
ui_print " "
ui_print " - IIR patches -"
  ui_print "***************************************************"
  ui_print "* [4/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*  IIR directly affects the final sound quality   *"
  ui_print "* and it is recommended to try the version with   *"
  ui_print "* and without it, choosing the one that you like  *"
  ui_print "*     the most [Recommended for installation]     *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Install IIR patches?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Installing IIR patches . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band1"][@id="0"]' "268833620"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band1"][@id="1"]' "537398060"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band1"][@id="2"]' "267510580"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band1"][@id="3"]' "537398060"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band1"][@id="4"]' "267908744"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band2"][@id="0"]' "266468108"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band2"][@id="1"]' "544862876"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band2"][@id="2"]' "262421829"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band2"][@id="3"]' "544862876"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band2"][@id="4"]' "260454481"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band3"][@id="0"]' "262913321"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band3"][@id="1"]' "559557058"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band3"][@id="2"]' "252311547"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band3"][@id="3"]' "559557058"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band3"][@id="4"]' "246789412"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band4"][@id="0"]' "294517138"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band4"][@id="1"]' "572289454"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band4"][@id="2"]' "210943778"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band4"][@id="3"]' "572289454"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band4"][@id="4"]' "237025461"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band5"][@id="0"]' "329006442"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band5"][@id="1"]' "711929387"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band5"][@id="2"]' "110068469"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band5"][@id="3"]' "711929387"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Band5"][@id="4"]' "170639455"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Enable Band1"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Enable Band2"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Enable Band3"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Enable Band4"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 Enable Band5"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 INP0 Volume"]' "80"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR1 INP1 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR1 INP2 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR1 INP3 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR1 INP4 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band1"][@id="0"]' "268833620"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band1"][@id="1"]' "537398060"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band1"][@id="2"]' "267510580"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band1"][@id="3"]' "537398060"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band1"][@id="4"]' "267908744"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band2"][@id="0"]' "266468108"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band2"][@id="1"]' "544862876"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band2"][@id="2"]' "262421829"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band2"][@id="3"]' "544862876"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band2"][@id="4"]' "260454481"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band3"][@id="0"]' "262913321"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band3"][@id="1"]' "559557058"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band3"][@id="2"]' "252311547"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band3"][@id="3"]' "559557058"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band3"][@id="4"]' "246789412"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band4"][@id="0"]' "294517138"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band4"][@id="1"]' "572289454"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band4"][@id="2"]' "210943778"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band4"][@id="3"]' "572289454"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band4"][@id="4"]' "237025461"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band5"][@id="0"]' "329006442"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band5"][@id="1"]' "711929387"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band5"][@id="2"]' "110068469"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band5"][@id="3"]' "711929387"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 Band5"][@id="4"]' "170639455"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 INP0 Volume"]' "80"
    patch_xml -u $MIX '/mixer/ctl[@name="IIR2 INP1 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR2 INP2 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR2 INP3 Volume"]' "80"
	patch_xml -u $MIX '/mixer/ctl[@name="IIR2 INP4 Volume"]' "80"
	done
fi

sleep 1
ui_print " "
ui_print " - Patching audio platform files -"
  ui_print "***************************************************"
  ui_print "* [5/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*     Confirming this option will allow the       *"
  ui_print "*         module to force 24-bit audio            *"
  ui_print "*  for your favorite songs, as well as improve    *"
  ui_print "*    the sound quality during video recording     *"
  ui_print "*        [Recommended for installation]           *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Patching audio platform files?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Patching audio platform files . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OAPLI in ${APINF}; do
    APLI="$MODPATH$(echo $OAPLI | sed "s|^/vendor|/system/vendor|g")"
    cp_ch $ORIGDIR$OAPLI $APLI
    sed -i 's/\t/  /g' $APLI
    patch_xml -s $APLI '/audio_platform_info_intcodec/config_params/param[@key="native_audio_mode"]' 'src'
    patch_xml -s $APLI '/audio_platform_info_intcodec/config_params/param[@key="hifi_filter"]' 'true'
	patch_xml -s $APLI '/audio_platform_info_intcodec/config_params/param[@key="true_32_bit"]' 'true'
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"	 
    patch_xml -u $APLI '/audio_platform_info_intcodec/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"
    patch_xml -s $APLI '/audio_platform_info_intcodec/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"	 
    patch_xml -u $APLI '/audio_platform_info_intcodec/app_types/app[@mode="default"]' 'bit_width=24'
    patch_xml -u $APLI '/audio_platform_info_intcodec/app_types/app[@mode="default"]' 'max_rate=192000'
	patch_xml -u $APLI '/audio_platform_info_intcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_MIC"]' "40"
	patch_xml -u $APLI '/audio_platform_info_intcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_CAMCORDER"]' "60"
	patch_xml -u $APLI '/audio_platform_info_intcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_UNPROCESSED"]' "30"
	patch_xml -u $APLI '/audio_platform_info_intcodec/audio_output_usecase_delay/audio_usecase_delay[@name="USECASE_AUDIO_PLAYBACK_DEEP_BUFFER"]' "20"
	
    patch_xml -s $APLI '/audio_platform_info_extcodec/config_params/param[@key="native_audio_mode"]' 'src'
    patch_xml -s $APLI '/audio_platform_info_extcodec/config_params/param[@key="hifi_filter"]' 'true'
	patch_xml -s $APLI '/audio_platform_info_extcodec/config_params/param[@key="true_32_bit"]' 'true'
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"
    patch_xml -u $APLI '/audio_platform_info_extcodec/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"
    patch_xml -s $APLI '/audio_platform_info_extcodec/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"	 
    patch_xml -u $APLI '/audio_platform_info_extcodec/app_types/app[@mode="default"]' 'bit_width=24'
    patch_xml -u $APLI '/audio_platform_info_extcodec/app_types/app[@mode="default"]' 'max_rate=192000'
	patch_xml -u $APLI '/audio_platform_info_extcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_MIC"]' "40"
	patch_xml -u $APLI '/audio_platform_info_extcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_CAMCORDER"]' "60"
	patch_xml -u $APLI '/audio_platform_info_extcodec/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_UNPROCESSED"]' "30"
	patch_xml -u $APLI '/audio_platform_info_extcodec/audio_output_usecase_delay/audio_usecase_delay[@name="USECASE_AUDIO_PLAYBACK_DEEP_BUFFER"]' "20"
	
    patch_xml -s $APLI '/audio_platform_info/config_params/param[@key="native_audio_mode"]' 'src'
    patch_xml -s $APLI '/audio_platform_info/config_params/param[@key="hifi_filter"]' 'true'
	patch_xml -s $APLI '/audio_platform_info/config_params/param[@key="true_32_bit"]' 'true'
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
    patch_xml -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"	 
    patch_xml -u $APLI '/audio_platform_info/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"
    patch_xml -s $APLI '/audio_platform_info/acdb_ids/device[@name="SND_DEVICE_IN_HANDSET_STEREO_DMIC"]' "1"	 
    patch_xml -u $APLI '/audio_platform_info/app_types/app[@mode="default"]' 'bit_width=24'
    patch_xml -u $APLI '/audio_platform_info/app_types/app[@mode="default"]' 'max_rate=192000'
	patch_xml -u $APLI '/audio_platform_info/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_MIC"]' "40"
	patch_xml -u $APLI '/audio_platform_info/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_CAMCORDER"]' "60"
	patch_xml -u $APLI '/audio_platform_info/audio_input_source_delay/audio_source_delay[@name="AUDIO_SOURCE_UNPROCESSED"]' "30"
	patch_xml -u $APLI '/audio_platform_info/audio_output_usecase_delay/audio_usecase_delay[@name="USECASE_AUDIO_PLAYBACK_DEEP_BUFFER"]' "20"
	
    if [ ! "$(grep '<app_types>' $APLI)" ]; then
	sed -i "s/<\/audio_platform_info>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69936\" max_rate=\"192000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69940\" max_rate=\"192000\" \/> \n  <app_types> \n<\/audio_platform_info>/" $APLI
    sed -i "s/<\/audio_platform_info_intcodec>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69936\" max_rate=\"192000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69940\" max_rate=\"192000\" \/> \n  <app_types> \n<\/audio_platform_info_intcodec>/" $APLI		 
	sed -i "s/<\/audio_platform_info_extcodec>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69936\" max_rate=\"192000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"69940\" max_rate=\"192000\" \/> \n  <app_types> \n<\/audio_platform_info_extcodec>/" $APLI		  

	else
    for i in 69936 69940; do
    [ "$(xmlstarlet sel -t -m "/audio_platform_info/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info>/,/<\/audio_platform_info>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"$i\" max_rate=\"192000\" \/> \n\1\2/}" $APLI
    [ "$(xmlstarlet sel -t -m "/audio_platform_info_intcodec/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info_intcodec>/,/<\/audio_platform_info_intcodec>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"$i\" max_rate=\"192000\" \/> \n\1\2/}" $APLI			
    [ "$(xmlstarlet sel -t -m "/audio_platform_info_extcodec/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info_extcodec>/,/<\/audio_platform_info_extcodec>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"24\" id=\"$i\" max_rate=\"192000\" \/> \n\1\2/}" $APLI			
    done
    fi
  done
fi

sleep 1
ui_print " "
ui_print " - Disable сompanders -"
  ui_print "***************************************************"
  ui_print "* [6/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*  Companding - method for reducing the effects   *"
  ui_print "*    of channels with a limited dynamic range.    *"
  ui_print "*      It is based on increasing the number       *"
  ui_print "*     of quantization intervals n the region      *"
  ui_print "*      of small values of the input signal        *"
  ui_print "* and decreasing in the region of maximum values. *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "    Disable companders?"
sleep 1
ui_print " "
ui_print "    Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Killing companders . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
    patch_xml -u $MIX '/mixer/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP0 RX1"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="COMP0 RX2"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="SpkrLeft COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/ctl[@name="SpkrRight COMP Switch"]' "0"
    patch_xml -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="handset"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP0 RX1"]' "0"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP0 RX2"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP0 RX1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP0 RX2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP3 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP4 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP5 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP6 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP7 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP8 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 16 Volume"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 15 Volume"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 29 Volume"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 30 Volume"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 31 Volume"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="Compress Playback 32 Volume"]' "0"
	done
fi

sleep 1
ui_print " "
ui_print " - Configurating interal audio codec -"
  ui_print "***************************************************"
  ui_print "* [7/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*            This option configuring              *"
  ui_print "*       your device's internal audio codec.       *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Configurate?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Configuring . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
   for OACONF in ${ACONFS}; do
    ACONF="$MODPATH$(echo $OACONF | sed "s|^/vendor|/system/vendor|g")"
    cp_ch $ORIGDIR$OACONF $ACONF
    sed -i 's/\t/  /g' $ACONF
    patch_xml -u $ACONF '/configs/property[@name="persist.vendor.audio.sva.conc.enabled"]' "false"
    patch_xml -u $ACONF '/configs/property[@name="persist.vendor.audio.va_concurrency_enabled"]' "false"
    patch_xml -u $ACONF '/configs/property[@name="vendor.voice.dsd.playback.conc.disabled"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.voice.playback.conc.disabled"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.rec.playback.conc.disabled"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.voice.path.for.pcm.voip"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.use.sw.alac.decoder"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.use.sw.ape.decoder"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.use.sw.mpegh.decoder"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.flac.sw.decoder.24bit"]' "true"
    patch_xml -u $ACONF '/configs/property[@name="vendor.audio.hw.aac.encoder"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="aac_adts_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="alac_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="ape_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="flac_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="pcm_offload_enabled_16"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="pcm_offload_enabled_24"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="qti_flac_decoder"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="vorbis_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="wma_offload_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="audiosphere_enabled"]' "false"
    patch_xml -u $ACONF '/configs/flag[@name="ext_hw_plugin_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="ext_qdsp_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="ext_spkr_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="ext_spkr_tfa_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="hfp_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="hifi_audio_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="hwdep_cal_enabled"]' "false"
    patch_xml -u $ACONF '/configs/flag[@name="multi_voice_session"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="maxx_audio_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="usb_offload_sidetone_vol_enabled"]' "false"
    patch_xml -u $ACONF '/configs/flag[@name="keep_alive_enabled"]' "true"
    patch_xml -u $ACONF '/configs/flag[@name="kpi_optimize_enabled"]' "false"
    patch_xml -u $ACONF '/configs/flag[@name="spkr_prot_enabled"]' "false"
    done	
	if [ "$RN5PRO" ] || [ "$MI9" ]; then
    cp_ch -f $FIRMRN5MI9/PNX_TAS2557.bin $MODPATH/system/vendor/firmware/PNX_TAS2557.bin
    cp_ch -f $FIRMRN5MI9/tas2557_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557_uCDSP_aac.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP_aac.bin
	cp_ch -f $FIRMRN5MI9/tas2557_uCDSP_goer.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP_goer.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt_ICTspk.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt_ICTspk.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_CTL.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_CTL.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_DRG.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_DRG.bin
	cp_ch -f $FIRMRN5MI9/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_24bit.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_24bit.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_PG21.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_PG21.bin
    fi
	if [ "$RN7" ]; then
    cp_ch -f $FIRMRN7/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
    fi
	if [ "$RN7PRO" ]; then
	cp_ch -f $FIRMRN7PRO/tas2563_uCDSP.bin $MODPATH/system/vendor/firmware/tas2563_uCDSP.bin
    fi
	if [ "$MI9T" ]; then
	cp_ch -f $FIRM9T/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
    fi
	if [ "$K20P" ]; then
	cp_ch -f $FIRK20PRO/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
    fi 
	if [ "$MI8" ]; then
	cp_ch -f $FIRMRN5MI9/PNX_TAS2557.bin $MODPATH/system/vendor/firmware/PNX_TAS2557.bin
	cp_ch -f $FIRMMI8/tas2557_uCDSP_aac.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP_aac.bin
	cp_ch -f $FIRMMI8/tas2557_uCDSP_goer.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP_goer.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt_ICTspk.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt_ICTspk.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_CTL.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_CTL.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_DRG.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_DRG.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_24bit.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_24bit.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_PG21.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_PG21.bin
    fi
	if [ "$MI8P" ]; then
	cp_ch -f $FIRMRN5MI9/PNX_TAS2557.bin $MODPATH/system/vendor/firmware/PNX_TAS2557.bin
	cp_ch -f $FIRMMI8PRO/tas2557_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt_ICTspk.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt_ICTspk.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_CTL.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_CTL.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_DRG.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_DRG.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_24bit.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_24bit.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_PG21.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_PG21.bin
    fi
	if [ "$MI9P" ]; then
	cp_ch -f $FIRMRN5MI9/PNX_TAS2557.bin $MODPATH/system/vendor/firmware/PNX_TAS2557.bin
	cp_ch -f $FIRMMI9PRO/tas2557_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP.bin
	cp_ch -f $FIRMMI9PRO/tas2557_uCDSP_goer.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP_goer.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt_ICTspk.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt_ICTspk.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_CTL.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_CTL.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_DRG.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_DRG.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_24bit.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_24bit.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_PG21.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_PG21.bin
    fi
	if [ "$MIA2" ]; then
	cp_ch -f $FIRMRN5MI9/PNX_TAS2557.bin $MODPATH/system/vendor/firmware/PNX_TAS2557.bin
	cp_ch -f $FIRMMIA2/tas2557_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557_uCDSP.bin
	cp_ch -f $FIRMMIA2/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_B2N_dvt_ICTspk.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_B2N_dvt_ICTspk.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_CTL.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_CTL.bin
	cp_ch -f $FIRMRN5MI9/TAS2557MSSMono_DRG.bin $MODPATH/system/vendor/firmware/TAS2557MSSMono_DRG.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_24bit.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_24bit.bin
	cp_ch -f $FIRMRN5MI9/tas2557s_uCDSP_PG21.bin $MODPATH/system/vendor/firmware/tas2557s_uCDSP_PG21.bin
    fi
	if [ "$POCOF1" ]; then
	cp_ch -f $FIRMPOCOF1/tas2559_uCDSP.bin $MODPATH/system/vendor/firmware/tas2559_uCDSP.bin
    fi
	if [ "$POCOF2P" ]; then
	cp_ch -f $FIRMPOCOF2PRO/tfa98xx.cnt $MODPATH/system/vendor/firmware/tfa98xx.cnt
    fi
    cp_ch -f $UNI/AcousticGuitar_RTP.bin $MODPATH/system/vendor/firmware/AcousticGuitar_RTP.bin
	cp_ch -f $UNI/Mi_RTP.bin $MODPATH/system/vendor/firmware/Mi_RTP.bin
	cp_ch -f $UNI/MiClassicRemix_RTP.bin $MODPATH/system/vendor/firmware/MiClassicRemix_RTP.bin
	cp_ch -f $UNI/MiHouse_RTP.bin $MODPATH/system/vendor/firmware/MiHouse_RTP.bin
	cp_ch -f $UNI/MiJazz_RTP.bin $MODPATH/system/vendor/firmware/MiJazz_RTP.bin
	cp_ch -f $UNI/MiRemix_RTP.bin $MODPATH/system/vendor/firmware/MiRemix_RTP.bin
	cp_ch -f $UNI/tfa98xx_aac.bin $MODPATH/system/vendor/firmware/tfa98xx_aac.bin
	cp_ch -f $UNI/tfa98xx_ssi.bin $MODPATH/system/vendor/firmware/tfa98xx_ssi.bin
    cp_ch -f $WHYDED/capi_v2_smartAmp_TAS25xx.so.1 $MODPATH/system/vendor/lib/rfsa/adsp/capi_v2_smartAmp_TAS25xx.so.1
	cp_ch -f $WHYDED/MTP_General_cal.acdb $MODPATH/system/vendor/SETC/acdbdata/MTP/MTP_General_cal.acdb
	cp_ch -f $WHYDED/MTP_Speaker_cal.acdb $MODPATH/system/vendor/SETC/acdbdata/MTP/MTP_Speaker_cal.acdb
fi
 
sleep 1
ui_print " "
ui_print " - Patch device_features files -"
  ui_print "***************************************************"
  ui_print "* [8/9]                                          *"
  ui_print "*                                                 *"
  ui_print "*        This step will do the following:         *"
  ui_print "*        - Unlocks the sampling frequency         *"
  ui_print "*          of the audio up to 384000 kHz;         *"
  ui_print "*        - Enable the AAC codec switch in         *"
  ui_print "*          the Bluetooth headphone settings;      *"
  ui_print "*        - Enable additional support for          *"
  ui_print "*          IIR parameters;                        *"
  ui_print "*        - Enable support for stereo recording;   *"
  ui_print "*        - Enable support for hd voice            *"
  ui_print "*          recording quality;                     *"
  ui_print "*        - Enable Dolby and Hi-Fi support         *"
  ui_print "*          (on some devices);                     *"
  ui_print "*        - Enable audio focus support             *"
  ui_print "*          during video recording;                *"
  ui_print "*        - Enable support for quick connection    *"
  ui_print "*          of Bluetooth headphones.               *"
  ui_print "*                                                 *"
  ui_print "*  And much more . . .                            *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "    Install this step?"
sleep 1
ui_print " "
ui_print "    Vol Up = YES, Vol Down = NO"
if $VKSEL; then
ui_print " "
ui_print " - Installing . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
if [ "$RN5PRO" ]; then
    cp_ch -f $FEATURES/whyred.xml $MODPATH/system/etc/device_features/whyred.xml
  fi
if [ "$RN7" ]; then
    cp_ch -f $FEATURES/lavender.xml $MODPATH/system/etc/device_features/lavender.xml
  fi
if [ "$RN7PRO" ]; then
	cp_ch -f $FEATURES/violet.xml $MODPATH/system/etc/device_features/violet.xml
  fi
if [ "$RN9S" ]; then
	cp_ch -f $FEATURES/curtana.xml $MODPATH/system/vendor/etc/device_features/curtana.xml
  fi
if [ "$RN9PRO" ]; then
	cp_ch -f $FEATURES/joyeuse.xml $MODPATH/system/vendor/etc/device_features/joyeuse.xml
  fi
if [ "$RN8" ]; then
	cp_ch -f $FEATURES/ginkgo.xml $MODPATH/system/etc/device_features/ginkgo.xml
  fi
if [ "$RN8T" ]; then
	cp_ch -f $FEATURES/willow.xml $MODPATH/system/etc/device_features/willow.xml
  fi
if [ "$RN6PRO" ]; then
	cp_ch -f $FEATURES/tulip.xml $MODPATH/system/etc/device_features/tulip.xml
  fi
if [ "$MIA2" ]; then
	cp_ch -f $FEATURES/wayne.xml $MODPATH/system/etc/device_features/wayne.xml
  fi
if [ "$POCOX3" ]; then
	cp_ch -f $FEATURES/surya.xml $MODPATH/system/vendor/etc/device_features/surya.xml
  fi
fi

sleep 1
ui_print " "
ui_print " - Install other patches in mixer_paths - "
  ui_print "***************************************************"
  ui_print "* [9/9]                                         *"
  ui_print "*                                                 *"
  ui_print "*           A large set of universal              *"
  ui_print "*          settings for many devices.             *"
  ui_print "*  If you encounter problems after installation   *"
  ui_print "*       try skipping this option first.           *"
  ui_print "*                                                 *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Install patches in mixer_paths files?"
sleep 1
ui_print " "
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 
if $VKSEL; then
ui_print " - Install paths . . . -"
sleep 1
ui_print " "
ui_print " - Please, wait . . . -"
  for OMIX in ${MPATHS}; do
    MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g")"
    if ! $NOHIFI; then
    patch_xml -s $MIX '/mixer/ctl[@name="RX_HPH_PWR_MODE"]' "HIRES"
    patch_xml -u $MIX '/mixer/ctl[@name="RX HPH Mode"]' "HD2"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIRES"
    patch_xml -s $MIX '/mixer/ctl[@name="VBoost Ctrl"]' "AlwaysOn"
	patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="SLIM_2_RX Format"]' "DSD_DOP"
	elif $HIFI; then
    patch_xml -u $MIX '/mixer/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
    patch_xml -s $MIX '/mixer/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
    patch_xml -u $MIX '/mixer/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -s $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_HIFI"
	patch_xml -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -u $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIFI"
	patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="SLIM_2_RX Format"]' "DSD_DOP"
    fi
    if [ "$RN7PRO" ] || [ "$RN8" ] || [ "$RN8T" ] || [ "$RN9S" ] || [ "$RN9PRO" ] || [ "$MIA3" ][ "$MI9" ] || [ "$MI9T" ] || [ "$MI10" ] || [ "$K20P" ] || [ "$MI8P" ] || [ "$MI8" ] || [ "$MI9P" ] || [ "$POCOF1" ] || [ "$POCOF2P" ] || [ "$POCOX3" ]; then
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="SLIM_5_RX Format"]' "S24_3LE"
    patch_xml -s $MIX '/mixer/ctl[@name="USB_AUDIO_RX Format"]' "S24_3LE"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="SLIM_6_RX Format"]' "S24_3LE"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="SLIM_5_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/ctl[@name="USB_AUDIO_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="SLIM_6_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="SLIM_2_RX SampleRate"]' "KHZ_384"
    patch_xml -u $MIX '/mixer/ctl[@name="SLIM_5_RX Channels"]' "Two"
    patch_xml -u $MIX '/mixer/ctl[@name="SLIM_6_RX Channels"]' "Two"
    patch_xml -u $MIX '/mixer/ctl[@name="SLIM_2_RX Channels"]' "Two"
    patch_xml -u $MIX '/mixer/ctl[@name="QUAT_MI2S_RX Channels"]' "Two"
    patch_xml -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="HPHL Volume"]' "20"
	patch_xml -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="HPHR Volume"]' "20"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX1 Mix Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX2 Mix Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX1 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX2 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX6 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX7 Digital Volume"]' "90"
    patch_xml -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX1 Digital Volume"]' "90"
    patch_xml -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX2 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX3 Digital Volume"]' "90"
	patch_xml -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS1_DL_HL Switch"]' "1"
    fi
    if [ "$RN5PRO" ] || [ "$RN6PRO" ] || [ "$MIA2" ] || [ "$RN7" ]; then
	patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="SLIM_5_RX Format"]' "S24_3LE"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX1 Mix Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX2 Mix Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX1 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX2 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX6 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX7 Digital Volume"]' "90"
    patch_xml -s $MIX '/mixer/ctl[@name="TAS2557 ClassD Edge"]' "7"
	patch_xml -s $MIX '/mixer/ctl[@name="TFA Profile"]' "music"
    patch_xml -u $MIX '/mixer/ctl[@name="INT0_MI2S_RX Format"]' "UNPACKED"
    patch_xml -u $MIX '/mixer/ctl[@name="INT0_MI2S_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/ctl[@name="ADC1_INP1 Switch"]' "0"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX1 Digital Volume"]' "96"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX2 Digital Volume"]' "96"
    patch_xml -u $MIX '/mixer/path[@name="headphones-ce"]/ctl[@name="RX1 Digital Volume"]' "80"
    patch_xml -u $MIX '/mixer/path[@name="headphones-ce"]/ctl[@name="RX2 Digital Volume"]' "80"
    patch_xml -u $MIX '/mixer/path[@name="headphones-no-ce"]/ctl[@name="RX1 Digital Volume"]' "88"
    patch_xml -u $MIX '/mixer/path[@name="headphones-no-ce"]/ctl[@name="RX2 Digital Volume"]' "88"
    patch_xml -u $MIX '/mixer/path[@name="headphones-karaoke"]/ctl[@name="IIR1 INP1 Volume"]' "88"
    patch_xml -u $MIX '/mixer/path[@name="headphones-karaoke"]/ctl[@name="IIR1 INP2 Volume"]' "88"
	patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="SLIM_6_RX Format"]' "S24_3LE"
    patch_xml -s $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="SLIM_5_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/path[@name="headphones"]/ctl[@name="SLIM_6_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="SLIM_2_RX SampleRate"]' "KHZ_384"
    fi
    patch_xml -u $MIX '/mixer/ctl[@name="Ultrasound Enable"]' "On"
    patch_xml -u $MIX '/mixer/ctl[@name="Ultrasound RampDown"]' "On"
    patch_xml -u $MIX '/mixer/ctl[@name="Ultrasound Mode"]' "489"
    patch_xml -s $MIX '/mixer/ctl[@name="Ultrasound Input"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="Ultrasound Output"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="Ultrasound Suspend"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="ultrasound-suspend"]/ctl[@name="Ultrasound Suspend"]' "0"
    patch_xml -u $MIX '/mixer/ctl[@name="Mi_Ultrasound Enable"]' "On"
    patch_xml -u $MIX '/mixer/ctl[@name="Mi_Ultrasound RampDown"]' "On"
    patch_xml -u $MIX '/mixer/ctl[@name="Mi_Ultrasound Mode"]' "489"
    patch_xml -s $MIX '/mixer/ctl[@name="Mi_Ultrasound Input"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="Mi_Ultrasound Output"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="Mi_Ultrasound Suspend"]' "0"
	patch_xml -u $MIX '/mixer/path[@name="mi_ultrasound-suspend"]/ctl[@name="Mi_Ultrasound Suspend"]' "0"
	patch_xml -s $MIX '/mixer/ctl[@name="A2DP_SLIM7_UL_HL Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="PCM_RX_DL_HL Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="USB_DL_HL Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIM_7_RX Format"]' "S24_LE"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIM_7_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIM_7_RX Channels"]' "Two"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Format"]' "S24_LE"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX SampleRate"]' "KHZ_192"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Channels"]' "Two"
    patch_xml -s $MIX '/mixer/ctl[@name="SLIM7_RX_DL_HL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="HFP_SLIM7_UL_HL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="HFP_PRI_AUX_UL_HL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="HFP_AUX_UL_HL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="HFP_INT_UL_HL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="AFE Input Channels"]' "Two"
    patch_xml -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM Channels"]' "Two"
	patch_xml -u $MIX '/mixer/ctl[@name="Voice Sidetone Enable"]' "1"
	patch_xml -u $MIX '/mixer/ctl[@name="HPHL_RDAC Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="HPHR_RDAC Switch"]' "1"		
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT1 SEC MIX HPHL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT2 SEC MIX HPHR Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="RX INT3 SEC MIX LO1 Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="RX INT4 SEC MIX LO2 Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT1 MIX3 DSD HPHL Switch"]' "1"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT2 MIX3 DSD HPHR Switch"]' "1"
    patch_xml -s $MIX '/mixer/ctl[@name="HiFi Function"]' "On"
    patch_xml -s $MIX '/mixer/ctl[@name="HiFi Filter"]' "6"
    patch_xml -u $MIX '/mixer/ctl[@name="EC Reference Channels"]' "Two"
    patch_xml -u $MIX '/mixer/ctl[@name="EC Reference SampleRate"]' "192000"
    patch_xml -u $MIX '/mixer/ctl[@name="EC Reference Bit Format"]' "S24_LE"
    patch_xml -u $MIX '/mixer/ctl[@name="HPHL"]' "Switch"
    patch_xml -u $MIX '/mixer/ctl[@name="HPHR"]' "Switch"
	patch_xml -u $MIX '/mixer/ctl[@name="RX INT1 DEM MUX"]' "CLSH_DSM_OUT"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT2 DEM MUX"]' "CLSH_DSM_OUT"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT3 DEM MUX"]' "CLSH_DSM_OUT"
    patch_xml -u $MIX '/mixer/ctl[@name="RX INT4 DEM MUX"]' "CLSH_DSM_OUT"
	patch_xml -s $MIX '/mixer/ctl[@name="ASM Bit Width"]' "24"
	patch_xml -s $MIX '/mixer/ctl[@name="MSM ASphere Set Param"]' "1"
	done	
fi

ui_print " "
ui_print " - Done. -"
ui_print "|______________________________________________|"
ui_print "|                                              |"
ui_print "|   Upload */sdcard/NLSound_install.txt in     |"
ui_print "|   support chat for checking working patch.   |"
ui_print "|______________________________________________|"
sleep 2
ui_print " "
ui_print " - With love, NLSound Team. -"
ui_print " "
sleep 2
cp -f $MODPATH/NLSound_install.txt /storage/emulated/0/NLSound_install.txt