Idioma: Português 🇧🇷
[*] Módulo com perfil que você pode alterar de acordo com seu gosto no aplicativo "Raiden Tweaks"

[!] Se você vai postar algum vídeo no seu canal com o meu módulo, deixe os créditos na descrição.

[*] Divirta-se fazendo o que você mais gosta de fazer, deixe comentários.
[*] Muito obrigado, antecipadamente.

Qualquer bug no módulo entre em contato comigo no grupo de suporte.

Language: English 🇺🇸
[*] Profiled module that you can change according to your taste in the "Raiden Tweaks" app

[!] If you are going to post any video on your channel with my module please leave the credits in the description.

[*] Have fun doing what you most enjoy doing, leave feedback
[*] Thank you very much in advance.

Any bugs in the module contact me in the support group.


RTKS Projects:

[ https://t.me/rtksprojectz ]

King Projects:

#KeepTheKing
Github: github.com/pedrozzz0
Discussion group: @kingprojectzdiscussion
[ https://t.me/kingprojectz ]

Credits and special thanks:

pedro3z0 @ (telegram) KTSR dev.

frap129 @ (GitHub) Spectrum dev.

Rolyattshit @ (telegram) Tester

phz333 @ (telegram) Tester

DanNinee @ (telegram) Tester

Runzikmartelo @ (Telegram) Tester