ui_print " _______ _________ _        _______ "
ui_print "(  ____ )\__   __/| \    /\(  ____ \ "
ui_print "| (    )|   ) (   |  \  / /| (    \/ "
ui_print "| (____)|   | |   |  (_/ / | (_____ "
ui_print "|     __)   | |   |   _ (  (_____  ) "
ui_print "| (\ (      | |   |  ( \ \       ) | "
ui_print "| ) \ \__   | |   |  /  \ \/\____) | "
ui_print "|/   \__/   )_(   |_/    \/\_______) "
ui_print " "
ui_print "VERSION: HAWK - 07/05/21"
sleep 3
ui_print " "
ui_print "With this module you can choose one of his profiles and improve your user experience."
sleep 3
ui_print " "
ui_print " - [*] Created by raidenkk @ (telegram)"
sleep 3
ui_print " "
ui_print " - Contributors, credits:"
sleep 2
ui_print " "
ui_print " - King Tweaks dev: pedro3z0 @ (telegram)"
sleep 2
ui_print " "
ui_print " - Spectrum dev: frap129 @ (GitHub)"
sleep 2
ui_print " "
ui_print " - [!] Join my support group: @rtksgroup (telegram)"
sleep 2
ui_print " "
ui_print " - Thanks to everyone for the feedback, it helps a lot."
sleep 2
ui_print " "
ui_print " - [*] Installing Raiden Tweaks control mode app"
pm install $MODPATH/rtks_sign.apk
ui_print " "
ui_print " - [*] Fstrim partitions..."
fstrim -v /data;
sleep 2
fstrim -v /system;
sleep 2
fstrim -v /cache;
sleep 2
ui_print " "
ui_print " - [*] RTKS Module has been installed Successfuly!"
ui_print " "
sleep 2