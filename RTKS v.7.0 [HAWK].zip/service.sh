#========================================
# RTKS HAWK
# Developer : Raidenkkj
#========================================
#!/system/bin/sh
while true; do
	if [[ $(getprop sys.boot_completed) ]]; then
	break ; fi
done

# Enable Spectrum support
setprop persist.spectrum.kernel "RTKS"
setprop spectrum.support 1

su -c "raidentweaks &"