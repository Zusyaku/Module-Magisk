#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode


# Kernel based tweaks that reduces the amount of wasted CPU cycles to maximum and gives back a huge amount of needed performance to both the system and the user;
echo "0" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "0" > /proc/sys/kernel/nmi_watchdog
echo "5" > /proc/sys/kernel/sched_walt_init_task_load_pct
echo "0" > /proc/sys/kernel/sched_tunable_scaling

#cpu tweak
chown system system /sys/devices/system/cpu/cpufreq/interactive/*
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
restorecon -R /sys/devices/system/cpu
chmod 0644 /sys/devices/system/cpu/cpufreq/interactive/*
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor 
echo "2000000" > /sys/devices/system/cpu/cpufreq/interactive/hispeed_freq
echo "90" > /sys/devices/system/cpu/cpufreq/interactive/target_loads 
echo "90000" > /sys/devices/system/cpu/cpufreq/interactive/above_hispeed_delay
echo "50" > /sys/devices/system/cpu/cpufreq/interactive/go_hispeed_load 
echo "40000" > /sys/devices/system/cpu/cpufreq/interactive/min_sample_time 
echo "20000" > /sys/devices/system/cpu/cpufreq/interactive/timer_rate 
echo "20000" > /sys/devices/system/cpu/cpufreq/interactive/timer_slack 
echo "10000" > /sys/devices/system/cpu/cpufreq/interactive/boostpulse_duration 

# scheduler TWEAK
chmod 0644 /sys/block/sda/queue/*
chmod 0644 /sys/block/sdb/queue/*
chmod 0644 /sys/block/sdc/queue/*
echo "deadline" > /sys/block/mmcblk0/queue/scheduler 
echo "deadline" > /sys/block/sda/queue/scheduler
echo "deadline" > /sys/block/sdb/queue/scheduler 
echo "deadline" > /sys/block/sdc/queue/scheduler 

stop logd
stop thermald
echo always_on > /sys/devices/platform/13040000.mali/power_policy;
echo alweys_on > /sys/devices/platform/13040000.mali/gpuinfo;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed;
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer;
echo boost > /sys/devices/system/cpu/sched/sched_boost;
echo '1' > /sys/devices/system/cpu/eas/enable;
echo '7035' > /sys/class/touch/switch/set_touchscreen

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

