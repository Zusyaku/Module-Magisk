# Ben's Thermal [SD845]

Disable thermal throttling on SD845 + Enable Quick Charge.
Device might heat up more than normal. Install this module only if you want to unleash the full potential of SD845 and neglect the slight increase in heat.

## Instructions ##
* __Install Module__ via Magisk Manager/TWRP
* __Reboot__ Device

## Credits ##
Original module by IbenHadi
Inspired by DwikyFajri & Chrysalis

## Contact ##
<a href="https://lab.manuelpinto.in/seshstation">Commit an Issue</a>
