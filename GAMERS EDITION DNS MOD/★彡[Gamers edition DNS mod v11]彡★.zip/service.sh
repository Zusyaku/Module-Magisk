#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

setenforce 0

# Analytics
	pm disable $apk/com.google.android.gms.analytics.AnalyticsService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsJobService
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementJobService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
	pm disable $apk/com.crashlytics.android.CrashlyticsInitProvider
	# Ads
	pm disable $apk/com.google.android.gms.ads.AdActivity
	# Firebase
	pm disable $apk/com.google.firebase.iid.FirebaseInstanceIdService
done
exit 0
