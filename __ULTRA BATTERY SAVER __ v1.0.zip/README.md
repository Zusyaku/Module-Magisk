# GPU Turbo Boost
## Description
This module aims to increase Android powered devices by up to 70% but at the same time reduces power consumption by up to 35% seamlessly.

## Supported vendors
- Snapdragon
- MediaTek
- Exynos
- HiSilicon Kirin

## Supported Architectures
- Arm & Arm64
- x86 & x86_64

## What it does
Modifying values found in stock kernel, custom kernel and build.prop, enhances gpu and accelerates your device performance to the highest level!.
It will give you less consumption overtime. 
## Requirements
- Magisk v19.0 or higher

## Changelog 
- v1.0 - Initial Releaase

Credits to levv20 for source codes 

#tweaks are taken from other devs and modified by me


#this module is tested on poco f1 (beryllium) and works fine!!! 