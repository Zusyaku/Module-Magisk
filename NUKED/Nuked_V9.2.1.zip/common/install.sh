#!/system/bin/sh
ui_print " "
ui_print "    **************************************"
ui_print "    *        * ϟ NUKED SCRIPT ϟ *        *"
ui_print "    **************************************"
ui_print " "
ui_print "    * ϟ NUKED SCRIPT ϟ *"
ui_print ""
ui_print "    * BYE BYE ANALYTIC SERVICES *"
ui_print ""
ui_print "    * Module For Reduce Battery Drain And Wakelock *"
ui_print ""
ui_print "    * Credits : *"
ui_print "    * @Foobar66 For First Script *"
ui_print "    * @AndrzejDwo script founder *"
ui_print "    * @Juuushiro there big help *"
ui_print "    * ϟ @HafizZiq ϟ for magisk module *"
ui_print "    * ϟ @K1ks ϟ for some help *"
ui_print "    * Thnx to all my tester for feedback *"
ui_print ""
ui_print "    * Thnx for using my script *"
ui_print ""
if [ -d /system/bin ]; then
 b=bin
elif [ -d /system/xbin ]; then
 b=xbin
fi;
mkdir -p $MODPATH/system/$b
if [ -f $MODPATH/nuked.tar.xz ]; then
 tar -xf $MODPATH/nuked.tar.xz -C $MODPATH/system/$b 2>/dev/null
 rm -f $MODPATH/nuked.tar.xz 2>/dev/null
fi;