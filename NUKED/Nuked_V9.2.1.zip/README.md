<h1 align="center">NUKED SCRIPT BY BUGFOUNDER83</h1>
<p align="center">
</p>


# Disclaimer
This program is distributed in the hope that it will be useful
I am not responsible for bricked devices, dead SD cards, corrupted partition, ect...

No to upload on additionals clouds

## Introduction
Hi all I have reddit one old scripts for disable a lot of analytic/reporting/Tracking stuff related to google or other.


## Requirements
- universal need to be confirmed by user

## How to use it ?

- Instructions :

- Flash the zip in magisk 
- Reboot
- Go to terminal type :
- su
- nuked0
- wakelock0
- GMS0
- ALL0 (optional)
- reboot

- optimisation

If you want revert to stock  :

- Go to terminal type :
- su
- stock
- when fully applied
- reboot


## Credits 

- Old scrip and some new service founder : @AndrzejDwo

- Old Zip installer : @Haridhayal
 
- Script updated by : @BugFounder

- Module powered and encrypted by : @HafizZiq & @K1ks1 for prevent any Kanger 

- Big thnx to: @K1ks for the base of the new script

## Changelog

### V6.2

⭐ new update guys ⭐

What's news ??

- added commad : fix1 for fix google backup added new service in google play services apps

- add support for magisk canary

- apply on boot can work on certain device need feedback 

Credits™️ :
Old scrip and some new service founder : AndrzejDwo
Old Zip installer : Haridhayal 
Script updated by : BugFounder 83
Module powered and encrypted by : HafizZiq & K1ks1 for prevent any Kanger 
Big thnx to: @K1ks1 for the base of the new script

💥 🙌 Big Thnx to @HafizZiq for this help about log part and coding  🙌 💥

### V6.0

⭐ Litle update but big improvement ⭐

Wats news ?? 

- added log part for knowing what service are disable and in what apk ✅
(Log are located in internal storage/nuked folder)

-  fixed service not disabled ✅


Enjoy  😇😇

Credits™️ :
Old scrip and some new service founder : AndrzejDwo
Old Zip installer : Haridhayal 
Script updated by : BugFounder 83
Module powered and encrypted by : HafizZiq & K1ks1 for prevent any Kanger 
Big thnx to: K1ks1 for the base of the new script

💥 🙌 Big Thnx to HafizZiq for this help about log part and coding  🙌 💥

### V5.3

- 💥 big update 💥 

- ⚠️ If you have applied wakelock script you need to apply stock command before install this update ⚠️

- ⚠️ For all user delete nuked module in magisk reboot and in stall the new sa fresh for prevent duplicated module in magisk ⚠️

- Wats news ?? 

- revised whole wakelock part now safe completely safe to use ✅

- all0 update with wakelock part ✅

- fixed magisk module properties ✅

- fixed all issue related by any user for sure at 100% ✅

- updated stock command  ✅

- now device run a little part of the script at every boot in case of you install any new apps for disable automatically useless service ✅

- Before share it this version have been heavy tested all apps works like a charm issue about social apps are fixed

### V5.2

- FULLY UNIVERSAL (ALL APPS TRIGGERED EVEN SYSTEM APPS) 

- the new code needs some time to apply due to all apps in your phone are triggered ⏳ ***

- whole code revised (now only apps installed in your phone are triggered)

- Gms doze (experimental) 

- removed ads for some reason (like for dev need it for contribution) you can use adway for do the same job 💨

- rename dss command by nuked

- wakelock updated (experimental) need real long time for fully applying 

- add the all in one script for gms and analytic and wakelock at the same time 

- removed bloat since inst universal and cause some trouble

- encrypted module to prevent KANGING 