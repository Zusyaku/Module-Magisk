# About
MTK (Mediatek SoC) Performance Tuner
Version 1.1.0 - Performance


# Features
- Real performance of Helio X series.
- Reduce lags on heavy gaming.
- Better RAM management.
- Improve multitasking.


# Disadvantages
- Device temperature raises due of performance boost.
- Not suitable for daily driver with lack of charging power sources.


# Supported Devices
- Xiaomi Redmi Note 4 Mediatek Helio X20 MT6797
- Xiaomi Redmi Note 4X Mediatek Helio X20 MT6797
- Xiaomi Redmi Pro Mediatek Helio X20/25 MT6797 (Experimental)


# Installation
- Requires Magisk Root version 15.0 or above.
- Install this module from Magisk Manager or flash it through recovery.


# Changelog
v1.1.0
- Better thermal management.
- Disable performance service.
- Kernel optimization.
- Multitasking improvement.

v1.0.0
- Initial release.


# Credits/References
@asusm930/XDA
https://forum.xda-developers.com/redmi-note-4/how-to/xiaomi-eu-redmi-note-4-rom-multi-t3527345
https://forum.xda-developers.com/redmi-note-4/how-to/root-redmi-note-4-mtk-gaming-gpu-t3569055
