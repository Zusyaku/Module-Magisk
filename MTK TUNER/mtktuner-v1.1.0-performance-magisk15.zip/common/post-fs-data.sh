#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

LOGFILE=/cache/magisk.log

i_logger()
{
	echo "mtktuner: $1"
	echo "mtktuner: $1" >> $LOGFILE
	log -p i -t Magisk "mtktuner: $1"
}

i_wait_end()
{
	while :; do [ "$(getprop sys.boot_completed)" = "1" ] && \
	[ "$(getprop dev.bootcomplete)" = "1" ] && break; sleep 3; done

	i_logger "Late Start Tuning"
	echo "4608,9472,14336,19200,23808,28672" > /sys/module/lowmemorykiller/parameters/minfree
}

i_tuning()
{
	# cpu/gpu tuning
	echo 10000 > /dev/cpuctl/bg_non_interactive/cpu.rt_runtime_us
	echo 950000 > /dev/cpuctl/cpu.rt_runtime_us
	echo 1000000 > /dev/cpuctl/cpu.rt_period_us
	echo 0 > /proc/sys/kernel/sched_tunable_scaling
	echo 1 > /proc/mali/dvfs_enable
	echo 1 > /proc/gpufreq/gpufreq_limited_thermal_ignore

	# cpu core limits
	echo 0-9 > /dev/cpuset/foreground/cpus
	echo 0,4 > /dev/cpuset/background/cpus
#	echo 5 > /proc/hps/num_limit_power_serv
#	echo 5 > /proc/hps/num_limit_thermal
#	echo 5 > /proc/hps/num_limit_low_battery
#	echo 5 > /proc/hps/num_limit_ultra_power_saving
	echo 99 > /proc/hps/up_threshold
	echo 87 > /proc/hps/down_threshold
	echo 1 > /proc/hps/rush_boost_enabled
	echo 1 > /proc/hps/input_boost_enabled

	# vm tunning
	echo 300 > /proc/sys/vm/dirty_expire_centisecs
	echo 500 > /proc/sys/vm/dirty_writeback_centisecs

	# late start
	i_wait_end &
	exit
}

i_logger "Tuning Performance Mode"
i_tuning
