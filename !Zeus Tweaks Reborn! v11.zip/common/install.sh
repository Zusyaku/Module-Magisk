#!/system/bin/sh


ui_print "RUNNING TWEAKS..."
sleep 3
set_perm_recursive "$MODPATH/system/bin" root root 0777 0755

ui_print "LOG IN INTERNAL STORAGE Android/zeusreborn.log"
sleep 1