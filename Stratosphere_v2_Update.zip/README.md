 

 <p align="center"><a href="https://t.me/AndroidRootModulesCommunity"><img src="https://i.imgur.com/IOUJLXI.mp4" width="500"></a></p>  
 <h1 align="center"><b> STRATOSPHERE </b></h1> 
 <h4 align="center">Tweak Module to improve ur experience, Power, Battery and Smoothness on your device.</h4>

 <a href="https://t.me/AndroidRootModulesCommunity"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>

Focused on Maximizing user experience, multiple profiles, Changeable in Termux Menu + Many More Features! Stay Fast!

 <h1 align="center"><b> UNIVERSAL </b></h1> 

## Requirements:
Magisk 22.0+
Latest Busybox
Android 5.0+

## Termux Command:
---> su -c strpmenu #NewStratosphereMenu


## 5 Diffrent Profile's!
■ Smooth Ui
--->> Focused On Smoothness, Improve The UI Smoothness And Overall System Speed.

■ Maximize Battery Durability 
--->> Reduce Power Draw And Improve Energetic Efficiency, Maximize Battery Backup.

■ Make It Balanced 
-->> Balanced Between Battery And Performance, Perfect For Daily Use / Tasks.

■ Max CPU
--->> Force CPU To Max, Disabling CPU Throttling And Tweaking It To Max Power.

■ GAMING
--->> Recommended To Hardcore Gamers, Who Wanna Max Performance While Playing, It Set Both CPU / GPU To Max Power.



#
## FAQ

## Does this module work on all devices/processor types? 
Yes, this module is universal, but it may not work correctly on some devices.

#

## Is there any chance my device will loop after installation? 
No, there is no way that will happen.

#

## I'm having bugs with the module, where can I report it? 
For you to report bugs, you must go to my telegram channel and report there, group link ... https://t.me/AndroidRootModulesCommunity.



Created By @CRANKV2 (Telegram)

Some Credits:

Too My Semxy Testers.. 
@hezenscs,@Legend_Gaming077, @Darkz❤

@@FastBoiOp, @RedmagicBoi, @Prince, @BeastOg❤

## Thanks To All Supporters❤️

