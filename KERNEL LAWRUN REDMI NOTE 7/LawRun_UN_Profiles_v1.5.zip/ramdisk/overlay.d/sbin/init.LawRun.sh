#!/system/bin/sh

sleep 1;
################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
#############################LawRun-Initation###################################
if [ ! -d /storage/emulated/0/LawRun-Kernel ]; then
# Set LawRun Folder
mkdir -p /storage/emulated/0/LawRun-Kernel/
else
rm -r /storage/emulated/0/LawRun-Kernel/log.txt
fi
################################################################################

# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt LawRun Booted Successfully" >> /storage/emulated/0/LawRun-Kernel/log.txt

# Destroy our /system scripts if another kernel has been installed
if ! grep -qi LawRun /proc/version; then
	mount -o remount,rw /system_root || exit 1
	rm -f /system_root/init.LawRun.rc
	sed -i '/init.LawRun.rc/d' /system_root/init.rc
	rm -rf $ramdisk/sbin/init.LawRun.sh;
	rm -rf $ramdisk/sbin/profile.LRbalance.sh;
	rm -rf $ramdisk/sbin/profile.LRbattery.sh;
	rm -rf $ramdisk/sbin/profile.LRebalance.sh;
	rm -rf $ramdisk/sbin/profile.LRgaming.sh;
	rm -rf $ramdisk/sbin/profile.LRperformance.sh;
	rm -rf /storage/emulated/0/LawRun-Kernel;
	mount -o remount,ro /system_root
fi

# Destroy our /system scripts if Our kernel has been installed
if grep -qi LawRun /proc/version; then

if [ -f /sbin/LawRun.FAllow.sh ]; then
rm -rf $ramdisk/sbin/LawRun.FAllow.sh;
fi;

if [ -f /sbin/Neg.LawRun.sh ]; then
rm -rf $ramdisk/sbin/Neg.LawRun.sh;
fi;

if [ -f /sbin/profile.balance.sh ]; then
rm -rf $ramdisk/sbin/profile.balance.sh;
fi;

if [ -f /sbin/profile.balance-M.sh ]; then
rm -rf $ramdisk/sbin/profile.balance-M.sh;
fi;

if [ -f /sbin/Perm.LawRun.sh ]; then
rm -rf $ramdisk/sbin/Perm.LawRun.sh;
fi

if [ -f /sbin/init.supolicy.sh ]; then
rm -rf $ramdisk/sbin/init.supolicy.sh;
fi

if [ -f /sbin/init.special_power.sh ]; then
rm -rf $ramdisk/sbin/init.special_power.sh;
fi

if [ -f /sbin/LawRun.performance.sh ]; then
rm -rf $ramdisk/sbin/LawRun.performance.sh;
fi

if [ -f /sbin/LawRun.ebalance.sh ]; then
rm -rf $ramdisk/sbin/LawRun.ebalance.sh;
fi

if [ -f /sbin/LawRun.gaming.sh ]; then
rm -rf $ramdisk/sbin/LawRun.gaming.sh;
fi

if [ -f /sbin/LawRun.balance.sh ]; then
rm -rf $ramdisk/sbin/LawRun.balance.sh;
fi

if [ -f /sbin/LawRun.battery.sh ]; then
rm -rf $ramdisk/sbin/LawRun.battery.sh;
fi

if [ -f /sbin/profile.performance.sh ]; then
rm -rf $ramdisk/sbin/profile.performance.sh;
fi

if [ -f /sbin/profile.ebalance.sh ]; then
rm -rf $ramdisk/sbin/profile.ebalance.sh;
fi;

if [ -f /sbin/profile.battery.sh ]; then
rm -rf $ramdisk/sbin/profile.battery.sh;
fi;

if [ -f /sbin/profile.gaming.sh ]; then
rm -rf $ramdisk/sbin/profile.gaming.sh;
fi;

if [ -f /sbin/HPos.LawRun.sh ]; then
rm -rf $ramdisk/sbin/HPos.LawRun.sh;
fi;

if [ -f /sbin/Pos.LawRun.sh ]; then
rm -rf $ramdisk/sbin/Pos.LawRun.sh;
fi;

if [ -f /sbin/init.Profiles.sh ]; then
rm -rf $ramdisk/sbin/init.Profiles.sh;
fi;

if [ -f /sbin/init.LawRunProfiles.sh ]; then
rm -rf $ramdisk/sbin/init.LawRunProfiles.sh;
fi;

if [ -f /sbin/init.spectrum.sh ]; then
rm -rf $ramdisk/sbin/init.spectrum.sh;
fi;
fi

if [ -d /data/adb/modules/LawRun ]; then
# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt LawRun Tweaks Setted" >> /storage/emulated/0/LawRun-Kernel/log.txt

# Ram Management
# 2048 x 4 /1024 = 8
# lower number * higher multitasking
echo "0" > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo "0" > /sys/module/lowmemorykiller/parameters/lmk_fast_run
echo "1" > /sys/module/lowmemorykiller/parameters/oom_reaper
echo "2048,3072,11520,16640,24320,42240" > /sys/module/lowmemorykiller/parameters/minfree

echo "1" > /dev/stune/foreground/schedtune.prefer_idle
echo "1" > /dev/stune/top-app/schedtune.prefer_idle

# Runtime fs tuning: as we have init boottime setting and kernel patch setting
# default readahead to 2048KB. We should adjust the setting upon boot_complete
# for runtime performance
echo "128" > /sys/block/sda/queue/nr_requests
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/rq_affinity
echo "deadline" > /sys/block/sda/queue/scheduler

echo "128" > /sys/block/sdb/queue/nr_requests
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdb/queue/rq_affinity
echo "deadline" > /sys/block/sdb/queue/scheduler

echo "128" > /sys/block/sdc/queue/nr_requests
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdc/queue/rq_affinity
echo "deadline" > /sys/block/sdc/queue/scheduler

echo "128" > /sys/block/sdd/queue/nr_requests
echo "0" > /sys/block/sdd/queue/iostats
echo "0" > /sys/block/sdd/queue/rq_affinity
echo "deadline" > /sys/block/sdd/queue/scheduler

echo "128" > /sys/block/sde/queue/nr_requests
echo "0" > /sys/block/sde/queue/iostats
echo "0" > /sys/block/sde/queue/rq_affinity
echo "deadline" > /sys/block/sde/queue/scheduler

echo "128" > /sys/block/sdf/queue/nr_requests
echo "0" > /sys/block/sdf/queue/iostats
echo "0" > /sys/block/sdf/queue/rq_affinity
echo "deadline" > /sys/block/sdf/queue/scheduler

echo "128" > /sys/block/dm-0/queue/nr_requests
echo "0" > /sys/block/dm-0/queue/iostats
echo "0" > /sys/block/dm-0/queue/rq_affinity
echo "deadline" > /sys/block/dm-0/queue/scheduler

# Setup final cpuset
echo "0-7" > /dev/cpuset/top-app/cpus
echo "0-3,6-7" > /dev/cpuset/foreground/boost/cpus
echo "0-3,6-7" > /dev/cpuset/foreground/cpus
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus

# Enable display / screen panel power saving features;
echo "Y" > /sys/kernel/debug/dsi_ebbg_fhd_ft8716_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_ebbg_fhd_ft8719_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_gvo_fhd_rm69299_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_jdi_fhd_nt35596s_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_jdi_fhd_r63452_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_samsung_fhd_ea8076_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_ss_fhd_ea8074_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_ss_notch_fhd_ea8074_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_nt36672a_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_rm69299_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_visionox_fhd_r66455_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_visionox_fhd_r66455_vid_display/dsi-phy-0_allow_phy_power_off

# Disable a few minor and overall pretty useless modules for slightly better battery life & system wide performance;
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco

# Thermal re-set
if [ -d /data/adb/modules/LawRun-Thermals ]; then
a=$(cat /sys/class/thermal/thermal_message/sconfig)
echo "$a"
if [ "$a" != "-1" ]; then
echo "-1" > /sys/class/thermal/thermal_message/sconfig
else
echo "10" > /sys/class/thermal/thermal_message/sconfig
sleep 2;
echo "-1" > /sys/class/thermal/thermal_message/sconfig
fi
else
a=$(cat /sys/class/thermal/thermal_message/sconfig)
echo "$a"
if [ "$a" != "-1" ]; then
echo "-1" > /sys/class/thermal/thermal_message/sconfig
sleep 2;
echo "$a" > /sys/class/thermal/thermal_message/sconfig
else
echo "10" > /sys/class/thermal/thermal_message/sconfig
sleep 2;
echo "-1" > /sys/class/thermal/thermal_message/sconfig
fi
fi

################################LawRun-Test#######################################

#Fix For Random Boot And Boot Reset Issue
chmod 777 /sys/module/sync/parameters/fsync_enabled
echo "Y" > /sys/module/sync/parameters/fsync_enabled

#Fix Lag And Battery Drain In Gaming
chmod 777 /proc/sys/vm/dirty_ratio
echo '95'> /proc/sys/vm/dirty_ratio
chmod 777 /proc/sys/vm/dirty_writeback_centisecs
echo '1500'> /proc/sys/vm/dirty_writeback_centisecs
chmod 777 /proc/sys/vm/vfs_cache_pressure
echo '5'> /proc/sys/vm/vfs_cache_pressure
chmod 777  /proc/sys/kernel/random/write_wakeup_threshold
echo '128'> /proc/sys/kernel/random/write_wakeup_threshold
chmod 777  /proc/sys/kernel/random/read_wakeup_threshold
echo '64'> /proc/sys/kernel/random/read_wakeup_threshold
chmod 777 /sys/block/mmcblk0/queue/read_ahead_kb
echo '64'> /sys/block/mmcblk0/queue/read_ahead_kb
chmod 777 /sys/block/mmcblk0/queue/scheduler
echo 'noop'> /sys/block/mmcblk0/queue/scheduler
chmod 777 /sys/block/mmcblk0/queue/iostats
echo '0'> /sys/block/mmcblk0/queue/iostats
chmod 777 /sys/block/mmcblk0/queue/add_random
echo '0'> /sys/block/mmcblk0/queue/add_random
chmod 777 /sys/block/mmcblk0/queue/rotational
echo '0'> /sys/block/mmcblk0/queue/rotational
chmod 777 sys/block/mmcblk0/queue/rq_affinity
echo '0'> /sys/block/mmcblk0/queue/rq_affinity
chmod 777 /sys/block/mmcblk1/queue/scheduler
echo 'noop'> /sys/block/mmcblk1/queue/scheduler
chmod 777 /sys/block/mmcblk1/queue/read_ahead_kb
echo '64'> /sys/block/mmcblk1/queue/read_ahead_kb
chmod 777 /sys/block/mmcblk1/queue/iostats
echo '0'> /sys/block/mmcblk1/queue/iostats
chmod 777 /sys/block/mmcblk1/queue/rotational
echo '0'> /sys/block/mmcblk1/queue/rotational
chmod 777 /sys/block/mmcblk1/queue/add_random
echo '0'> /sys/block/mmcblk1/queue/add_random
chmod 777 /sys/block/mmcblk1/queue/rq_affinity
echo '0'> /sys/block/mmcblk1/queue/rq_affinity

########################

# Scrolling Cache
setprop persist.sys.scrollingcache 1

########################

echo "0" > /proc/sys/kernel/sched_schedstats

echo "N" > /sys/kernel/debug/debug_enabled

echo "N" > /sys/module/workqueue/parameters/power_efficient
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "N" > /sys/module/cifs/parameters/enable_oplocks
echo "Y" > /sys/module/cryptomgr/parameters/notests
echo "0" > /sys/module/diagchar/parameters/diag_mask_clear_param
echo "0" > /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
echo "0" > /sys/module/dwc3/parameters/ep_addr_txdbg_mask
echo "1" > /sys/module/hid/parameters/ignore_special_drivers
echo "0" > /sys/module/icnss/parameters/dynamic_feature_mask
echo "1" > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo "0" > /sys/module/lowmemorykiller/parameters/lmk_fast_run
echo "0" > /sys/module/lowmemorykiller/parameters/oom_reaper
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo "0" > /sys/module/service_locator/parameters/enable
echo "N" > /sys/module/drm_kms_helper/parameters/poll
echo "0" > /sys/module/msm_poweroff/parameters/download_mode
echo "N" > /sys/module/printk/parameters/always_kmsg_dump
echo "Y" > /sys/module/printk/parameters/console_suspend

echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work

echo "0" > /proc/sys/debug/exception-trace
echo "0 0 0 0" > /proc/sys/kernel/printk

echo "128" > /proc/sys/net/core/netdev_max_backlog
echo "0" > /proc/sys/net/core/netdev_tstamp_prequeue
echo "0" > /proc/sys/net/ipv4/cipso_cache_bucket_size
echo "0" > /proc/sys/net/ipv4/cipso_cache_enable
echo "0" > /proc/sys/net/ipv4/cipso_rbm_strictvalid
echo "0" > /proc/sys/net/ipv4/igmp_link_local_mcast_reports
echo "24" > /proc/sys/net/ipv4/ipfrag_time
echo "1" > /proc/sys/net/ipv4/tcp_ecn
echo "0" > /proc/sys/net/ipv4/tcp_fwmark_accept
echo "320" > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo "21600" > /proc/sys/net/ipv4/tcp_keepalive_time
echo "1800" > /proc/sys/net/ipv4/tcp_probe_interval
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save
echo "0" > /proc/sys/net/ipv4/tcp_slow_start_after_idle
echo "0" > /proc/sys/net/ipv6/calipso_cache_bucket_size
echo "0" > /proc/sys/net/ipv6/calipso_cache_enable
echo "48" > /proc/sys/net/ipv6/ip6frag_time

if [ -e "/sys/class/lcd/panel/power_reduce" ]; then
chmod 0644 /sys/class/lcd/panel/power_reduce
echo "1" > /sys/class/lcd/panel/power_reduce
fi;

echo 1 > /dev/stune/top-app/schedtune.sched_boost
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled

echo '0:1324800' > /sys/module/cpu_boost/parameters/input_boost_freq
echo 40 > /sys/module/cpu_boost/parameters/input_boost_ms
echo 1200 > /sys/module/cpu_boost/parameters/powerkey_input_boost_ms

echo "0-3, 6-7" > /dev/cpuset/camera-daemon/cpus
echo "0" > /dev/cpuset/restricted/cpus 

echo "0:300000" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "1:300000" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "2:300000" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "3:300000" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "4:825600" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "5:825600" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "6:825600" > /sys/module/msm_performance/parameters/cpu_min_freq
echo "7:825600" > /sys/module/msm_performance/parameters/cpu_min_freq

echo "825600" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo "825600" > /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
echo "825600" > /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
echo "825600" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo "300000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo "300000" > /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
echo "300000" > /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
echo "300000" > /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq

######################## 
echo "CACHE_HOT_BUDDY" > /sys/kernel/debug/sched_features
echo "ENERGY_AWARE" > /sys/kernel/debug/sched_features
echo "FBT_STRICT_ORDER" > /sys/kernel/debug/sched_features
echo "LAST_BUDDY" > /sys/kernel/debug/sched_features
echo "NEXT_BUDDY" > /sys/kernel/debug/sched_features
echo "NO_RT_RUNTIME_SHARE" > /sys/kernel/debug/sched_features
echo "NO_TTWU_QUEUE" > /sys/kernel/debug/sched_features
echo "NO_LB_BIAS" > /sys/kernel/debug/sched_features

sysctl -e -w kernel.panic_on_oops=0
sysctl -e -w kernel.panic=0

########################
echo "0" > /sys/kernel/rcu_expedited
echo "1" > /sys/kernel/rcu_normal

echo "0" > /sys/class/kgsl/kgsl-3d0/bus_split
echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo "0" > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling

echo "0" > /sys/class/kgsl/kgsl-3d0/force_no_nap

echo "Y" > /proc/sys/dev/cnss/randomize_mac

echo "0" > /sys/block/mmcblk0/queue/io_poll
echo "0" > /sys/block/mmcblk0/queue/nomerges
echo "128" > /sys/block/mmcblk0/queue/nr_requests
echo "write through" > /sys/block/mmcblk0/queue/write_cache

echo 0 > /sys/block/mmcblk0/queue/iosched/group_idle
echo 1 > /sys/block/mmcblk0/queue/iosched/low_latency
echo 300 > /sys/block/mmcblk0/queue/iosched/target_latency

echo "0" > /sys/block/sda/queue/add_random
echo "0" > /sys/block/sda/queue/io_poll
echo "0" > /sys/block/sda/queue/nomerges
echo "0" > /sys/block/sda/queue/rotational
echo "write through" > /sys/block/sda/queue/write_cache

echo 0 > /sys/block/sda/queue/iosched/group_idle
echo 1 > /sys/block/sda/queue/iosched/low_latency
echo 300 > /sys/block/sda/queue/iosched/target_latency

########################

killall -9 android.process.media
killall -9 mediaserver

echo 3000 > /proc/sys/vm/dirty_expire_centisecs
echo 0 > /d/tracing/tracing_on
echo 0 > /d/tracing/events/ext4/enable
echo 0 > /d/tracing/events/f2fs/enable
echo 0 > /d/tracing/events/block/enable
setprop sys.use_fifo_ui 1
setprop persist.radio.add_power_save 1
setprop debug.composition.type c2d
setprop video.accelerate.hw 1

for i in $(find /sys/class/net -type l); do
  echo "128" > $i/tx_queue_len;
done;

for i in $(find /sys/ -name debug_mask); do
echo "0" > $i;
done
for i in $(find /sys/ -name debug_level); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
echo "0" > $i;
done
if [ -e /sys/module/logger/parameters/log_mode ]; then
 echo "2" > /sys/module/logger/parameters/log_mode
fi;
for i in $(find /sys/ -name debug_level); do
 echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
 echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
 echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
 echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
 echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
 echo "0" > $i;
done

# FS-Trim
fstrim /data;
fstrim /cache;
fstrim /system;

########################

else

# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt LawRun Tweaks not Detected" >> /storage/emulated/0/LawRun-Kernel/log.txt

fi;

if [ -d /data/adb/modules/Profiles ]; then
# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt LawRun Profiles Detected" >> /storage/emulated/0/LawRun-Kernel/log.txt

sleep 2;

# profile re-applying
a=$(cat /storage/emulated/0/LawRun-Kernel/Prof-save.txt)
echo "$a"
if [ "$a" != "" ]; then
 setprop persist.lawrun.profile "$a"
# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Previous Profile applied" >> /storage/emulated/0/LawRun-Kernel/log.txt
else
 setprop persist.lawrun.profile 1
# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Default Profile applied" >> /storage/emulated/0/LawRun-Kernel/log.txt
fi

else

# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt LawRun Profiles not Detected" >> /storage/emulated/0/LawRun-Kernel/log.txt

# Detect Device version for kernel setup
if grep -qi dipper /system/build.prop || grep -qi beryllium /system/build.prop || grep -qi polaris /system/build.prop; then

# SILVER Cluster LawRun
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1766400" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq

# GOLD Cluster LawRun
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
echo "825600" > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
echo "2803200" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk

# High Freq
echo "710000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "710000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk

#Charging mode
echo "2800000" > /sys/class/power_supply/battery/constant_charge_current_max

# Detect Device version for kernel setup
elif grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop; then

# SILVER Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1708800" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# GOLD Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq
echo "2208000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "180" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "504000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "504000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "504" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
echo "2000000" > /sys/class/power_supply/battery/constant_charge_current_max

# Detect Device version for kernel setup
elif grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop; then

# SILVER Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1708800" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# GOLD Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq
echo "2304000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "180" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "610000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "610000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "610" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
echo "3000000" > /sys/class/power_supply/battery/constant_charge_current_max

fi

fi;
################################LawRun-END#######################################
