#!/system/bin/sh

# Profile Log
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt eBalanced LRK applied" >> /storage/emulated/0/LawRun-Kernel/log.txt

# Save Profile incase of restart
rm -r /storage/emulated/0/LawRun-Kernel/Prof-save.txt
echo "1" > /storage/emulated/0/LawRun-Kernel/Prof-save.txt

################################LawRun-SDM845#######################################
# Detect Device version for kernel setup
if grep -qi dipper /system/build.prop || grep -qi beryllium /system/build.prop || grep -qi polaris /system/build.prop; then

# SILVER Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1766400" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq

# GOLD Cluster LawRun
echo "825600" > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
echo "2803200" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "180" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "710000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "710000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "710" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
a=$(cat /sys/class/power_supply/battery/constant_charge_current_max)
echo "$a"
if [ "$a" == "1800000" ]; then
echo "2800000" > /sys/class/power_supply/battery/constant_charge_current_max
fi

# GPU Little Cluster Not LawRun
g=$(cat /sys/class/kgsl/kgsl-3d0/num_pwrlevels)
echo "$g"
if [ "$g" == "8" ]; then
echo "257000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "7" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo "1" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
elif [ "$g" == "7" ]; then
echo "257000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "6" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo "0" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
fi

# SILVER Cluster LawRun
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/hispeed_freq
echo "1" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/pl
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/up_rate_limit_us
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/down_rate_limit_us

# SILVER Cluster not LawRun
c=$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)
echo "$c"
if [ "$c" != "schedutil" ]; then
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/hispeed_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/pl
fi

# GOLD Cluster LawRun
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy4/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/hispeed_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/pl
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/up_rate_limit_us
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/down_rate_limit_us

# GOLD Cluster not LawRun
c=$(cat /sys/devices/system/cpu/cpufreq/policy4/scaling_governor)
echo "$c"
if [ "$c" != "schedutil" ]; then
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy4/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/hispeed_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy4/"$c"/pl
fi

################################LawRun-SDM710#######################################
# Detect Device version for kernel setup
elif grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop; then

# Detect Device version for kernel setup
if grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop; then

# SILVER Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1708800" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# GOLD Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq
echo "2208000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "180" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "504000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "504000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "504" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
a=$(cat /sys/class/power_supply/battery/constant_charge_current_max)
echo "$a"
if [ "$a" == "1400000" ]; then
echo "2000000" > /sys/class/power_supply/battery/constant_charge_current_max
fi

# Detect Device version for kernel setup
elif grep -qi RMX1851 /system/build.prop || grep -qi nad_RMX1851 /system/build.prop || grep -qi RMX1851EX /system/build.prop; then

# SILVER Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1708800" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# GOLD Cluster LawRun
echo "300000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq
echo "2304000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

# Low Freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "180000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "180" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "610000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "610000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "610" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
a=$(cat /sys/class/power_supply/battery/constant_charge_current_max)
echo "$a"
if [ "$a" == "1400000" ]; then
echo "3000000" > /sys/class/power_supply/battery/constant_charge_current_max
fi

fi;

# SILVER Cluster not LawRun
c=$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)
echo "$c"
if [ "$c" != "schedutil" ]; then
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/hispeed_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/"$c"/pl
fi

# GOLD Cluster not LawRun
c=$(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_governor)
echo "$c"
if [ "$c" != "schedutil" ]; then
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
c=$(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_governor)
echo "$c"
echo "0" > /sys/devices/system/cpu/cpufreq/policy6/"$c"/hispeed_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy6/"$c"/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/policy6/"$c"/pl
fi

# Detect Device version for kernel setup
elif grep -qi lavender /system/build.prop; then

# SILVER Cluster LawRun
echo "633600" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo "1843200" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# GOLD Cluster LawRun
echo "1113600" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq
echo "2208000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

# Low Freq
echo "160000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo "160000000" > /sys/class/kgsl/kgsl-3d0/gpuclk
echo "160" > /sys/class/kgsl/kgsl-3d0/min_clock_mhz

# High Freq
echo "647000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo "647000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo "647" > /sys/class/kgsl/kgsl-3d0/max_clock_mhz

# Charging mode Reset
a=$(cat /sys/class/power_supply/battery/constant_charge_current_max)
echo "$a"
if [ "$a" == "1500000" ]; then
echo "2300000" > /sys/class/power_supply/battery/constant_charge_current_max
fi

################################LawRun-Others#######################################
fi;

# Limiter
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor

# IO Scheduler
echo "deadline" > /sys/block/sda/queue/scheduler
echo "deadline" > /sys/block/sdb/queue/scheduler
echo "deadline" > /sys/block/sdc/queue/scheduler
echo "deadline" > /sys/block/sdd/queue/scheduler
echo "deadline" > /sys/block/sde/queue/scheduler
echo "deadline" > /sys/block/sdf/queue/scheduler
