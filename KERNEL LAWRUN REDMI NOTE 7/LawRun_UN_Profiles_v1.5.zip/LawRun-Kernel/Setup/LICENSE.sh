#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
#############################LawRun-Initation###################################

# Clear
ui_print "                                    ";
ui_print "                                    ";

############################# LawRun-LICENSE ###################################

# Install LawRun summary
	ui_print "                 LawRun summary                ";
ui_print "                                    ";
ui_print "                                    ";
if [ -d /data/adb/magisk ]; then
    ui_print "LawRun ramdisk Included...";
if [ -d /data/adb/modules/Profiles ]; then
    ui_print "LawRun Profiles Installed...";
fi;
else
ui_print "                                    ";
fi
    ui_print "                                    ";
    ui_print "Download Our App from our website linked below...";
    ui_print "Website ==> https://www.lawrun-kernel.ml...";
    ui_print "Telegram ==> https://t.me/LawRunKernel...";
    ui_print "Email ==> lawrunbynegrroo@gmail.com...";
    ui_print "                  Dont forget                    ";
    ui_print "            ALWAYS BE READY TO RUN!!              ";

############################### LawRun-End #####################################
