#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
############################## Installation ####################################

# Profiles
if [ -d /data/adb/magisk ]; then
ui_print "-> Installing LawRun-Profiles Magisk Module...";
MODMagisk=/data/adb/modules/Profiles
# Place MOD options
rm -rf $MODMagisk
mkdir -p $MODMagisk
cp -Rf /tmp/anykernel/LawRun-Kernel/common/Profiles/* $MODMagisk
chmod 755 $MODMagisk/service.sh
chmod 755 $MODMagisk/post-fs-data.sh
fi

# LICENSE
. /tmp/anykernel/LawRun-Kernel/Setup/LICENSE.sh;

############################### LawRun-End #####################################
