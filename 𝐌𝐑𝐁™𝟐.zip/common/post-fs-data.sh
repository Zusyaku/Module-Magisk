#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
## Script to enable init.d by @androidexpert35
busybox run-parts $MODDIR/system/etc/init.d
setprop ro.vendor.qti.config.zram true
write /proc/sys/vm/page-cluster 0
write /sys/block/zram0/max_comp_streams 8
# This script will be executed in post-fs-data mode

#DNS servers address
setprop net.eth0.dns1 1.1.1.1
setprop net.eth0.dns2 1.0.0.1

setprop net.dns1 1.1.1.1
setprop net.dns2 1.0.0.1

setprop net.ppp0.dns1 1.1.1.1
setprop net.ppp0.dns2 1.0.0.1

setprop net.rmnet0.dns1 1.1.1.1
setprop net.rmnet0.dns2 1.0.0.1

setprop net.rmnet1.dns1 1.1.1.1
setprop net.rmnet1.dns2 1.0.0.1

setprop net.pdpbr1.dns1 1.1.1.1
setprop net.pdpbr1.dns2 1.0.0.1

setprop 2606:4700:4700::1111
setprop 2606:4700:4700::1001



# Edit the resolv conf file if it exist

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 1.1.1.1\nnameserver 1.0.0.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi

echo "High Performance DAC Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/injector.log
echo "" >> /storage/emulated/0/injector.log

echo "Cleaner Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/injector.log
echo "" >> /storage/emulated/0/injector.log

echo "CloudFlare Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/network.log
echo "" >> /storage/emulated/0/network.log

echo '0' > /sys/kernel/power_suspend/power_suspend_mode
echo '2' > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo '1' > /sys/module/cpu_boost/parameters/sched_boost_on_input
echo '0' > /sys/kernel/mm/uksm/max_cpu_percentage
echo '0' > /sys/kernel/mm/uksm/sleep_millisecs
echo 'noop' > /sys/block/mmcblk0/queue/scheduler                
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'N' > /sys/module/workqueue/parameters/power_efficient
echo 'performance' > /sys/kernel/mm/uksm/cpu_governor
echo '1' > /sys/kernel/mm/uksm/run

echo 'lz4' > /sys/block/zram1/comp_algorithm
echo '8' > /sys/block/zram1/max_comp_streams
echo '134217728' > /sys/block/zram1/disksize
mkswap /dev/block/zram1 > /dev/null 2>&1
swapon /dev/block/zram1 > /dev/null 2>&1

echo 'lz4' > /sys/block/zram2/comp_algorithm
echo '8' > /sys/block/zram2/max_comp_streams
echo '134217728' > /sys/block/zram2/disksize
mkswap /dev/block/zram2 > /dev/null 2>&1
swapon /dev/block/zram2 > /dev/null 2>&1

echo 'lz4' > /sys/block/zram3/comp_algorithm
echo '8' > /sys/block/zram3/max_comp_streams
echo '134217728' > /sys/block/zram3/disksize
mkswap /dev/block/zram3 > /dev/null 2>&1
swapon /dev/block/zram3 > /dev/null 2>&1

echo 1 > /sys/class/graphics/fb0/SRGB
