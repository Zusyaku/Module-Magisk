#!/system/bin/sh
MODDIR=${0%/*}

/system/etc/fde.ai/r.bin &

