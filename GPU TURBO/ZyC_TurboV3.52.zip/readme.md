<hr>
this is just magisk modul for disable your thermal gpu and improve your gpu performance with some additional feature <br>
tested devices : max pro m2 using aegis X oc and non oc kernel,and some custom rom <br>
and support other qualcomm processor ( need tested ) <br>
and not support other processor(i mean only qualcomm ),but you can try this modul and told me if is support for your phone xD <br>
<hr>

