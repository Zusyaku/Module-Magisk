
set_permissions() {
  set_perm_recursive $MODPATH/system/bin root root 0777 0755
}

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

ui_print ""
fstrim -v /system
fstrim -v /data
fstrim -v /cache
ui_print ""
ui_print "[*] Installing Zeus Tweaks app..."
pm install $MODPATH/ZTS.apk
sleep 1
ui_print ""
ui_print "[*] Logs are stored in your internal storage/ZTS"
sleep 1
ui_print ""
ui_print "[*] Now, reboot."
sleep 1