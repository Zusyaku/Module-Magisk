#!/system/bin/sh
# Written by tytydraco
# Zeus by (Teixeira @ telegram @kodekasu).

# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 2
done

sleep 60

# Setup tweaks
zeustweaks