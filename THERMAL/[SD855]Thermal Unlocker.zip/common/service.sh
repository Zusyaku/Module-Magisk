#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

setenforce 0

chmod 755 /sys/class/power_supply/battery/constant_charge_current_max
echo 6000000 > /sys/class/power_supply/battery/constant_charge_current_max
chmod 755 /sys/class/power_supply/battery/input_current_max
echo 6000000 > /sys/class/power_supply/battery/input_current_max
chmod 555 /sys/class/power_supply/battery/constant_charge_current_max
chmod 555 /sys/class/power_supply/battery/input_current_max

echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps

echo 0 > /sys/block/sda/queue/iostats

echo 0 > /proc/sys/kernel/sched_boost

echo Y > /sys/module/lpm_levels/parameters/sleep_disabled

echo 3 > /proc/sys/vm/drop_caches

echo 'N' > /sys/module/sync/parameters/fsync_enabled

/system/bin/KFmark
/system/bin/LMK

exit 0