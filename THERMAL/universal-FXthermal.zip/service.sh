#!/system/bin/sh
# Credits: Felix (FThermalX) Since FThermal X7 The code was rebased to enchance user Experience.
while [ ! "$(getprop sys.boot_completed)" == "1" ]; do
 sleep 1
done
sleep 60

#Whyred Settings
# Disable Spy Services (by @Vern_Kuato)
for apk in $(pm list packages -3 | sed 's/package://g' | sort); do
 # analytics
 pm disable $apk/com.google.android.gms.analytics.AnalyticsService
 pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
 pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
 pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
 pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
 pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
 pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
 pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
 # ads
 pm disable $apk/com.google.android.gms.ads.AdActivity
done 2>/dev/null
exit 0
