Creator
 - felix (@felixfw16)

Contributor
 -@K1ks1 (NFS Developer) (For the Installer script)
 -@HafizZiq (For editing the old scripts to be compatible with Magisk)
