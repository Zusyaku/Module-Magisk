﻿#!/system/bin/sh
TIME=1
S=V6
if [ -d /data/adb/modules ]; then
 SBIN=/data/adb/modules
elif [ -d /sbin/.core/img ]; then
 SBIN=/sbin/.core/img
elif [ -d /sbin/.magisk/img ]; then
 SBIN=/sbin/.magisk/img
fi;
PRINT1() {
ui_print "* ϟ T-ENGINE  ϟ *"
ui_print "* Status = $S * "
ui_print "* By K1KS * "
ui_print "* Thermal Engine Conf For SDM 6 SERIES *"
ui_print "* Perf Boost Custom Config *"
}
PRINT2() {
ui_print "* Enjoy Your New Custom Performance *"
}
CHECK1() {
D=$(getprop ro.product.device 2>/dev/null)
P=$(getprop ro.build.product 2>/dev/null)
VD=$(getprop ro.product.vendor.device 2>/dev/null)
VP=$(getprop ro.vendor.product.device 2>/dev/null)
DN=whyred

case "$DN" in
 "$D"|"$P"|"$VD"|"$VP")
  why=1
 ;;
 *)
  why=0
 ;;
esac

sleep $TIME

if [ "$why" == "0" ]; then
 ui_print "* Whyred Only..!!!"
 abort "* Err Code1 : Installation Not Approved , Aborting !!! *"
elif [ "$why" == "1" ]; then
 ui_print "* Installation Approved Level 1 , Whyred Detected *"
fi;
}

CHECK2() {
if [ -e $SBIN/disable_thermal-throttle/disable ]; then
 Conf=1
elif [ -d $SBIN/disable_thermal-throttle ]; then
 Conf=1
elif [ -e $SBIN/FThermalXWH/disable ]; then
 Conf=1
elif [ -d $SBIN/FThermalXWH ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv1/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv1 ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv2/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv2 ]; then
 Conf=1
elif [ -e $SBIN/neothermalwhyred/disable ]; then
 Conf=1
elif [ -d $SBIN/neothermalwhyred ]; then
 Conf=1
elif [ -e $SBIN/uni-thermal-mod-whyred/disable ]; then
 Conf=1
elif [ -d $SBIN/uni-thermal-mod-whyred ]; then
 Conf=1
else
 Conf=0
fi;

sleep $TIME

if [ "Conf" == "1" ]; then
 ui_print "* Thermal Detected..!!!"
 abort "* Err Code : Installation Not Approved  , Aborting !!! *"
elif [ "$Conf" == "0" ]; then
 ui_print "* Installation Approved Level  , No Thermal Detected *"
fi;
}

PRINT1
#CHECK1
CHECK2
PRINT2