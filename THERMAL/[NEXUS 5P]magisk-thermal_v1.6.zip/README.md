# Nexus 5X Thermal Tweaking

# Changelog

1.6

  *  Updated Magisk Template to 17000

1.5

  *  Updated Magisk Template to 1500

v1.4

  * Updated Magisk Template to 1400

v1.3

  * Initial release updated for newer Magisk version
