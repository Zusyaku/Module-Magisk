# Poco F1 Magisk Thermal Unlock
This simple script will replace normal thermal profile with decoy file which always run at maximum performance when battery is >=20%.

Provide much better FPS but may heat up quicker and use more battery.

If you are gaming and want to reserve more battery, consider reduce FPS and game quality. Game loading speed and stability may improve significantly on low settings.

If you want to revert back to original thermal profile, disable or delete the script through Magisk Manager.

## Included

* Empty decoy file to disable thermal control
* [magisk-module-installer 18100](https://github.com/topjohnwu/magisk-module-installer)

## Requirement

* Magisk v18.1 or higher installed on your phone
* Read the disclaimer before install

## Disclaimer
~~Your warranty is now void~~


Oh wait, you can't void warranty on this phone...


Anyway...

I'm not responsible for bricked phone, causing the phone to explode, thermonuclear war, or you getting fired because the alarm app failed.

And if you point the finger at me for messing up your device, I will laugh at you, hard, a lot.

## Install

You can download the release installer zip file and install it via the Magisk Manager App.
