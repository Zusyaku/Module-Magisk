#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
##########################################################################################
# AUROX - THERMAL
# VERSION = v2.5 | STABLE
# DATE = 05-09-2020
##########################################################################################
MODDIR=${0%/*}

# Wait for boot to be completed
while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

# Apply settings
sleep 60s

# VM Management Tweaks Set Config
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /proc/sys/vm/swappiness;
echo '70' > /proc/sys/vm/dirty_background_ratio;
echo '90' > /proc/sys/vm/dirty_ratio;
echo '50' > /proc/sys/vm/vfs_cache_pressure;

# Virtual Memory Tweaks Set Config
stop perfd
echo '5' > /proc/sys/vm/swappiness;
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
echo '80' > /proc/sys/vm/vfs_cache_pressure;
echo '0' > /proc/sys/vm/extra_free_kbytes;
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb;
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb;
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo '4096' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '5' > /proc/sys/vm/dirty_ratio;
echo '20' > /proc/sys/vm/dirty_background_ratio;
sleep 30
chmod 666 /sys/module/lowmemorykiller/parameters/minfree;
chown root /sys/module/lowmemorykiller/parameters/minfree;
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree;
rm /data/system/perfd/default_values;
start perfd

# CPU Boost Tweaks Set Config
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_min_freq;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy0/scaling_setspeed;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;

# TCP Congestion Control Tweaks Set Config
write /proc/sys/net/core/default_qdisc; fq_codel
write /proc/sys/net/ipv4/tcp_congestion_control; bbr

# Internet Speed Tweaks Set Config
echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '30' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '524288' > /proc/sys/net/core/wmem_max;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '524288' > /proc/sys/net/core/rmem_max;
echo '524288' > /proc/sys/net/core/rmem_default;
echo '524288' > /proc/sys/net/core/wmem_default;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_rmem;
echo '4096 87380 524288' > /proc/sys/net/ipv4/tcp_wmem;
echo '4296 87380 404480' > /proc/sys/net/ipv4;
echo '524288 524288 524288' > /proc/sys/net/ipv4/tcp_mem;

# Enable Fast Charging Rate
if [ -e /sys/kernel/fast_charge/force_fast_charge; ]; then
  echo "1" > /sys/kernel/fast_charge/force_fast_charge;

# Fast Charging Tweaks Set Config
echo '2000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma;
echo '1800' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma;
echo '2400' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma;
echo '1800' > /sys/module/dwc3_msm/parameters/hvdcp_max_current;
echo '2000' > /sys/module/dwc3_msm/parameters/dcp_max_current;
echo '2000' > /sys/module/phy_msm_usb/parameters/dcp_max_current;
echo '1800' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current;
echo '1200000' > /sys/module/qpnp_smb2/parameters/weak_chg_icl_ua;

#Quick Charge 3.0 Specific settings:
#Battery Maximum charging current, just a initial value.
echo '140' > /sys/class/power_supply/bms/temp_cool;
echo '460' > /sys/class/power_supply/bms/temp_hot;
echo '460' > /sys/class/power_supply/bms/temp_warm;
echo '3200000' > /sys/class/power_supply/usb/current_max;
echo '3200000' > /sys/class/power_supply/usb/hw_current_max;
echo '3200000' > /sys/class/power_supply/usb/pd_current_max;
echo '3200000' > /sys/class/power_supply/usb/ctm_current_max;
echo '3200000' > /sys/class/power_supply/usb/sdp_current_max;
echo '3200000' > /sys/class/power_supply/main/current_max;
echo '3200000' > /sys/class/power_supply/main/constant_charge_current_max;
echo '3200000' > /sys/class/power_supply/battery/current_max;
echo '3200000' > /sys/class/power_supply/battery/constant_charge_current_max;
echo '4400000' > /sys/class/qcom-battery/restricted_current;
echo '3200000' > /sys/class/power_supply/pc_port/current_max;
echo '3200000' > /sys/class/power_supply/constant_charge_current__max;

# Dt2W Fixed Tweaks Set Config
If [[ -d "/sys/touchpanel/double_tap" ]]
then
  write "/sys/touchpanel/double_tap" 1
fi

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

# This script will be executed in late_start service mode
# More info in the main Magisk thread
