# AUROX - THERMAL
# VERSION = v2.5 | STABLE
# DATE = 05-09-2020
# !/sbin/sh

busybox mount /system

#Backup

if [ ! -f /system/vendor/etc/thermal-engine.conf.parth ]; then
  cp /system/vendor/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

if [ ! -f /system/etc/thermal-engine.conf.parth ]; then
  cp /system/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

