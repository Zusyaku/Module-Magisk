### [Mido] Optimized Thermal Engine

#### Warning
```I am not resposible for anything happens to your device. Use at your own risk !```

#### Description
```Optimized thermal-engine.conf for Redmi Note 4(X) mido. Check featue list below for everything.```

#### Specifications
| Device   | Redmi Note 4 (X) Snapdragon |
| -------- | --------------------------- |
| ARCH     | ARM64                       |
| Board    | msm8953                     |
| ROM      | LOS/AOSP or MIUI            |
| Codename | mido                        |

#### Features
| File | Thermal Engine                                      |
| --   | --                                                  |
| 1.   | Define all sensor types                             |
| 2.   | Sampling rate for thermal throttling 1000ms         |
| 3.   | Tuned thermal threshold limit                       |
| 4.   | Define all cores                                    |
| 5.   | Online games ping fix included                      |
| 6.   | Re-define algo types                                |
| 7.   | Keeps device temp. low as much as possible          |
| 8.   | Better charging speed, should be better then before |
| 9.   | Prevents early thermal throttling                   |

#### Instruction
```
* Install Magisk Module
* Reboot
* Done
```

#### MIUI
`Untested but you can try.`

#### Updates
When required, i will push new changes.

### Require Kernel Configuration
| KA      | Thermal Manager      | Tab |
| --      | --                   | --  |
| Disable | Core Control         | Yes |
| Disable | VDD Restriction      | Yes |
| Enable  | Temperature Throttle | Yes |
