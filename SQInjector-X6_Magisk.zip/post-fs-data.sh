#===========================================================================#
# ╭━━━┳━━━┳━━╮╱╱╱╱╱╱╱╱╱╱╭╮
# ┃╭━╮┃╭━╮┣┫┣╯╱╱╱╭╮╱╱╱╱╭╯╰╮
# ┃╰━━┫┃╱┃┃┃┃╱╭━╮╰╋━━┳━┻╮╭╋━━┳━╮
# ╰━━╮┃┃╱┃┃┃┃╱┃╭╮┳┫┃━┫╭━┫┃┃╭╮┃╭╯
# ┃╰━╯┃╰━╯┣┫┣╮┃┃┃┃┃┃━┫╰━┫╰┫╰╯┃┃
# ╰━━━┻━━╮┣━━╯╰╯╰┫┣━━┻━━┻━┻━━┻╯
# ╱╱╱╱╱╱╱╰╯╱╱╱╱╱╭╯┃ 𝑩𝒚 𝜜𝒌𝒊𝒓𝒂_𝑽𝒊𝒔𝒉𝒂𝒍
# ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰━╯
#===========================================================================#
# GIVE PROPER CREDITS IF YOU USE THE PART OF IT IN YOUR WORK, THANKS!
#===========================================================================#
#!/system/bin/sh
mods=/data/adb/modules
gpu=$(getprop debug.hwui.renderer)
android=$(getprop ro.build.version.release)
# Module Disabler
# by: @WeAreRavens
if [ -e $MODDIR/system/vendor/bin/thermal-engine ]; then
    for t in $mods/*thermal*; do
        touch $t/disable;
    done;
    for t in $mods/*Thermal*; do
        touch $t/disable;
    done;
    for t in $mods/*THERMAL*; do
        touch $t/disable;
    done;
    for t in $mods/KTHERMAL665; do
        touch $t/disable;
    done;
    for t in $mods/mengt; do
        touch $t/disable;
    done;
    for t in $mods/*Aurox*; do
        touch $t/disable;
    done;
    for t in $mods/*Aurox*; do
        touch $t/disable;
    done;
fi
if [ -e $MODDIR/Injectors/gms ]; then
    for t in $mods/*gms*; do
        touch $t/disable;
    done;
    for t in $mods/*doze*; do
        touch $t/disable;
    done;
    for t in $mods/*wakelock*; do
        touch $t/disable;
    done;
    for t in $mods/*GMS*; do
        touch $t/disable;
    done;
    for t in $mods/*WAKELOCK*; do
        touch $t/disable;
    done;
    for t in $mods/*DOZE*; do
        touch $t/disable;
    done;
fi
#if [ "$android" == "7" ]; then
#    for t in $mods/*touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*Touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*TOUCH*; do
#        touch $t/disable;
#    done;
#elif [ "$android" == "8" ]; then
#    for t in $mods/*touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*Touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*TOUCH*; do
#        touch $t/disable;
#    done;
#elif [ "$android" == "9" ]; then
#    for t in $mods/*touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*Touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*TOUCH*; do
#        touch $t/disable;
#    done;
#elif [ "$android" == "10" ]; then
#    for t in $mods/*touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*Touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*TOUCH*; do
#        touch $t/disable;
#    done;
#elif [ "$android" == "11" ]; then
#    for t in $mods/*touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*Touch*; do
#        touch $t/disable;
#    done;
#    for t in $mods/*TOUCH*; do
#        touch $t/disable;
#    done;
#fi
if [ -e $mods/FDE ]; then
    touch $mods/FDE/disable
fi
if [ -e $mods/LiteProject ]; then
    touch $mods/LiteProject/disable
fi
if [ -e $mods/autoswitch ]; then
    touch $mods/autoswitch/disable
fi
if [ -e $mods/injector ]; then
    touch $mods/injector/disable
fi
if [ -e $mods/Ktks ]; then
    touch $mods/Ktks/disable
fi
if [ -e $mods/KTKSR ]; then
    touch $mods/KTKSR/disable
fi
if [ -e $mods/KLR ]; then
    touch $mods/KLR/disable
fi
if [ -e $mods/ZeroLAG ]; then
    touch $mods/ZeroLAG/disable
fi
if [ -e $mods/gembot ]; then
    touch $mods/gembot/disable
fi
if [ -e $mods/extreme ]; then
    touch $mods/extreme/disable
fi
if [ -e $mods/lazy ]; then
    touch $mods/lazy/disable
fi
if [ -e $mods/govTuner ]; then
    touch $mods/govTuner/disable
fi
if [ -e $mods/lspeed ]; then
    touch $mods/lspeed/disable
fi
if [ -e $mods/MAGNETAR ]; then
    touch $mods/MAGNETAR/disable
fi
if [ -e $mods/AuroxT ]; then
    touch $mods/AuroxT/disable
fi
if [ -e $mods/R.kashyap ]; then
    touch $mods/R.kashyap/disable
fi
if [ -e $mods/modul_mantul ]; then
    touch $mods/modul_mantul/disable
fi
for b in $mods/*boost*; do
    touch $b/disable;
done;
for b in $mods/*Boost*; do
    touch $b/disable;
done;
for g in $mods/*gaming*; do
    touch $g/disable;
done;
for g in $mods/*Gaming*; do
    touch $g/disable;
done;
for g in $mods/*gpu*; do
    touch $g/disable;
done;
for g in $mods/*GPU*; do
    touch $g/disable;
done;
for g in $mods/*game*; do
    touch $g/disable;
done;
for g in $mods/*Game*; do
    touch $g/disable;
done;
for t in $mods/*K*; do
    touch $t/disable;
done;
for t in $mods/*KT*; do
    touch $t/disable;
done;
for q in $mods/*quantum*; do
  touch $q/disable;
done;
for t in $mods/*tweak*; do
    touch $t/disable;
done;
# GPU Render Switch
# by: @akira_vishal
if [ "$android" == "7" ]; then
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=opengl" $MODPATH/system.prop;
elif [ "$android" == "8" ]; then
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=opengl" $MODPATH/system.prop;
elif [ "$android" == "9" ]; then
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=skiagl" $MODPATH/system.prop;
elif [ "$android" == "10" ]; then
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=skiagl" $MODPATH/system.prop;
elif [ "$android" == "11" ]; then
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=${gpu}" $MODPATH/system.prop;
else
    sed -i "/debug.hwui.renderer/c debug.hwui.renderer=skiavk" $MODPATH/system.prop;
fi;
# Touch Switch
# by: @akira_vishal
#if [ "$android" == "7" ]; then
#    sed -i "/device.internal/c device.internal=1" $MODPATH/system.prop;
#    sed -i "/touch.deviceType/c touch.deviceType=touchScreen" $MODPATH/system.prop;
#    sed -i "/touch.orientationAware/c touch.orientationAware=1" $MODPATH/system.prop;
#elif [ "$android" == "8" ]; then
#    sed -i "/device.internal/c device.internal=1" $MODPATH/system.prop;
#    sed -i "/touch.deviceType/c touch.deviceType=touchScreen" $MODPATH/system.prop;
#    sed -i "/touch.orientationAware/c touch.orientationAware=1" $MODPATH/system.prop;
#elif [ "$android" == "9" ]; then
#    sed -i "/device.internal/c device.internal=1" $MODPATH/system.prop;
#    sed -i "/touch.deviceType/c touch.deviceType=touchScreen" $MODPATH/system.prop;
#    sed -i "/touch.orientationAware/c touch.orientationAware=1" $MODPATH/system.prop;
#elif [ "$android" == "10" ]; then
#    sed -i "/device.internal/c device.internal=1" $MODPATH/system.prop;
#    sed -i "/touch.deviceType/c touch.deviceType=touchScreen" $MODPATH/system.prop;
#    sed -i "/touch.orientationAware/c touch.orientationAware=1" $MODPATH/system.prop;
#elif [ "$android" == "11" ]; then
#    sed -i "/device.internal/c device.internal=1" $MODPATH/system.prop;
#    sed -i "/touch.deviceType/c touch.deviceType=touchScreen" $MODPATH/system.prop;
#    sed -i "/touch.orientationAware/c touch.orientationAware=1" $MODPATH/system.prop;
#else
#    echo '1' > /proc/irq/240/smp_affinity_list;
#fi;
# Refresh
# by: @akira_vishal
if [ -e $mods/sqinjector ]; then
    su -c "cmd package bg-dexopt-job"
fi;
#===========================================================================#