##### SQInjector | Magisk Module

##### Contact: https://t.me/AkiraProjects

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.

##### Yes, works on all ROMs and on all firmwares.

##### ✓ INSTALLATION: Just flash via Magisk and reboot

#### - ChangeLog -

### Version: X6

- Added Super Injector 
- Added Quantum Injector
- Added Empty Thermals Fixed Lag For Other Devices
- Added Auto Disable Debuggers
- Added GMS Doze | Fixed Some Apps Crashing Issues
- Adjust Miscellaneous Settings
- Added Auto GPU Render Selection
- Disabled Auto Touch Enhancement Selection
- Added sRGB Enabled In Miscellaneous Settings
- Added RCU In Kernel Settings | RCU_normal instead of RCU_expedited for improved real-time latency, CPU utilization and energy efficiency;
- Auto Adjust Network Settings | Added Westwood, Cubic, Reno, bbr, bbr2 optimization
- Adjust Kernel Settings | Disabled NO_HRTICK $ ENERGY_AWARE
- Adjust Kernel Sound Settings
- Fixed UI Lag
- Fixed Logs Automatically Deleted
- Fixed Apps Killed In Background
- Fixed Battery Server Not Turned Off
- Improve Module Security
- Removed EAS PowerHAL
- Removed Game Unlocker
- Removed KCal
- Removed Super Thermals
- Removed EAS Kernel CPU Settings
- Removed SELinux
- Removed WiFi Bonding
- Removed SQuantum
- Removed Auto Performance
- Removed Adrenaline Engine Tweaks
- Removed Module Activate Toast
- Removed Other Shit
- Alot of under the hood improvents

### Version: X5

- Added New Bulid.prop Tweaks
- Added Adrenaline Engine Tweaks
- Added EAS PowerHAL ( Access it with termux command su -c eas )
- Added Game Unlocker ( Access it with termux command su -c game )
- Added GMS ( Access it with termux command su -c gms )
- Improve Auto Performance Injector
- Added SQ Injector
- Removed FKM & Spectrum
- Added sRGB On & KCal Together
- Added Super & Empty Thermals
- Added Module Activate Toast

### Version: X4

- Added SELinux Mode Changer
- Added Logs ( Now you will know that my tweak is working or not )
- Added Force DeepSleep Tweaks
- Added Gpu Performance Tweaks
- Added Touch Tweaks
- Added New Network Tweaks Option
- Added WiFi Bonding (Qcom)
- Added EAS PowerHAL
- Enable msm_thermal and core_control
- Disable exception-trace and reduce some overhead that is caused by a certain amount and percent of kernel logging, in case your kernel of choice have it enabled
- Added FileSystem (FS) optimized tweaks & enhancements for a improved userspace experience
- Added A couple of minor kernel entropy tweaks & enhancements for a slight UI responsivness boost
- Added Kernel based tweaks that reduces the amount of wasted CPU cycles to maximum and gives back a huge amount of needed performance to both the system and the user
- Fully disable kernel printk console log spamming directly for less amount of useless wakeups (reduces overhead)
- Increase how much CPU bandwidth (CPU time) realtime scheduling processes are given for slightly improved system stability and minimized chance of system freezes & lockups
- Enable CFQ group idle mode for improved scheduling effectivness by merging the IO queues in a "unified group" instead of treating them as individual IO based queues
- Disable CFQ low latency mode for overall increased IO based scheduling throughput and for better overall needed responsivness & performance from the system
- Added Wide block based tuning for reduced lag and less possible amount of general IO scheduling based overhead
- Disable GPU frequency based throttling
- Added 1028 readahead KB for sde and sdf io scheds
- Enable a tuned Boeffla wakelock blocker at boot for both better active & idle battery life
- Added Tweak the kernel task scheduler for improved overall system performance and user interface responsivness during all kind of possible workload based scenarios
- Enable Fast Charge for slightly faster battery charging when being connected to a USB 3.1 port
- Added A miscellaneous pm_async tweak that increases the amount of time (in milliseconds) before user processes & kernel threads are being frozen & "put to sleep"
- Added Memory Tuning
- Added ZRAM /sys/block/zram0/queue/read_ahead_kb 1024
- Added DT2W Fix
- Added Network tweaks for slightly reduced battery consumption when being "actively" connected to a network connection
- Added sys/class/net Tweak and decrease tx_queue_len default stock value(s) for less amount of generated bufferbloat and for gaining slightly faster network speed and performance
- Added data connections and network buffer optimizations
- Added Virtual Memory tweaks & enhancements for a massively improved balance between performance and battery life
- Turn off a few additional kernel debuggers and what not for gaining a slight boost in both performance and battery life
- Added sRGB
- Added Colour Calibration
- Added New Injector Mods
- Added Sound Alive
- Added High Performance mode on Qualcomm's WCD9xx DAC
- Added Empty Thermals
- Added DNS Tweaks
- Added DOZE Tweaks
- Fixed CTS Failed Issue
- Added 1028 readahead KB for sde and sdf io scheds
- Removed Backlight Dimmer
- Improve Module Installation Ui
