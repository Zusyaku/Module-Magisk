TEXT1="SQɪɴᴊᴇᴄᴛᴏʀ ᴀ ᴍᴀɢɪꜱᴋ ᴍᴏᴅᴜʟᴇ ᴡʜɪᴄʜ ᴀɪᴍꜱ ᴛᴏ ɪᴍᴘʀᴏᴠᴇ $(getprop ro.product.system.manufacturer)/ʀᴀᴍ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ, ʙʏ ᴄʜᴀɴɢɪɴɢ ᴋᴇʀɴᴇʟ ᴠᴀʟᴜᴇꜱ ʙᴇᴛᴡᴇᴇɴ ᴘᴇʀꜰᴏʀᴍᴀɴᴄᴇ ᴀɴᴅ ʙᴀᴛᴛᴇʀʏ ꜱᴀᴠɪɴɢꜱ. "
TEXT2="ᴇɴᴀʙʟᴇᴅ ᴍᴏᴅꜱ ꜰᴏʀ $(getprop ro.build.product) : "
ui_print ""
ui_print " ╭━━━┳━━━┳━━╮╱╱╱╱╱╱╱╱╱╱╭╮"
ui_print " ┃╭━╮┃╭━╮┣┫┣╯╱╱╱╭╮╱╱╱╱╭╯╰╮"
ui_print " ┃╰━━┫┃╱┃┃┃┃╱╭━╮╰╋━━┳━┻╮╭╋━━┳━╮"
ui_print " ╰━━╮┃┃╱┃┃┃┃╱┃╭╮┳┫┃━┫╭━┫┃┃╭╮┃╭╯"
ui_print " ┃╰━╯┃╰━╯┣┫┣╮┃┃┃┃┃┃━┫╰━┫╰┫╰╯┃┃"
ui_print " ╰━━━┻━━╮┣━━╯╰╯╰┫┣━━┻━━┻━┻━━┻╯"
ui_print " ╱╱╱╱╱╱╱╰╯╱╱╱╱╱╭╯┃ 𝑩𝒚 𝜜𝒌𝒊𝒓𝒂_𝑽𝒊𝒔𝒉𝒂𝒍"
ui_print " ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰━╯"
ui_print ""
sleep 0.5
if [ -f $MODPATH/SQMods.tar.xz ]; then
 tar -xf $MODPATH/SQMods.tar.xz -C $MODPATH 2>/dev/null
 rm -f $MODPATH/SQMods.tar.xz 2>/dev/null
fi
ui_print "- 𝐃𝐞𝐯𝐢𝐜𝐞 : $(getprop ro.build.product) "
sleep 0.2
ui_print "- 𝐌𝐨𝐝𝐞𝐥 : $(getprop ro.product.model) "
sleep 0.2
ui_print "- 𝐌𝐚𝐧𝐮𝐟𝐚𝐜𝐭𝐮𝐫𝐞𝐫 : $(getprop ro.product.system.manufacturer) "
sleep 0.2
ui_print "- 𝐏𝐫𝐨𝐜𝐞𝐬𝐬𝐨𝐫 : $(getprop ro.product.board) "
sleep 0.2
ui_print "- 𝐂𝐏𝐔 : $(getprop ro.hardware) "
sleep 0.2
ui_print "- 𝐀𝐧𝐝𝐫𝐨𝐢𝐝 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : $(getprop ro.build.version.release) "
sleep 0.2
ui_print "- 𝐊𝐞𝐫𝐧𝐞𝐥 : $(uname -r) "
sleep 0.2
ui_print "- 𝐑𝐀𝐌 : $(free | grep Mem |  awk '{print $2}') "
ui_print ""
sleep 1
ui_print "- ⚡Unlocking The True Power Of $(getprop ro.product.system.brand)⚡ -"
ui_print ""
sleep 0.2
for apk in $(pm list packages -3 | sed 's/package://g' | sort); do
	pm disable $apk/com.google.android.gms.analytics.AnalyticsService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsJobService
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementJobService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
	pm disable $apk/com.crashlytics.android.CrashlyticsInitProvider
	pm disable $apk/com.google.android.gms.ads.AdActivity
	pm disable $apk/com.google.firebase.iid.FirebaseInstanceIdService
done
ui_print ""
ui_print "    ╭━━┳╮╭╮╱╱╱╱╭━━╮ "
ui_print "    ┃╭╮┃┣╋╋┳┳━╮┃━━╋┳┳━┳━┳┳╮ "
ui_print "    ┃┣┫┃━┫┃╭┫╋╰╋━━┃┃┃╋┃┻┫╭╯ "
ui_print "    ╰╯╰┻┻┻┻╯╰━━┻━━┻━┫╭┻━┻╯ "
ui_print "    ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰╯ "
ui_print ""
sleep 0.5
ui_print "- ⚡𝙎𝙩𝙖𝙧𝙩𝙞𝙣𝙜 𝙎𝙐𝙋𝙀𝙍乛𝙌𝙪𝙖𝙣𝙩𝙪𝙢 𝙄𝙣𝙟𝙚𝙘𝙩𝙤𝙧 𝙈𝙤𝙙𝙪𝙡𝙚 𝙄𝙣𝙨𝙩𝙖𝙡𝙡𝙖𝙩𝙞𝙤𝙣⚡ -"
ui_print ""
sleep 0.5
ui_print "- (𝗩𝗼𝗹𝘂𝗺𝗲 + 𝗡𝗲𝘅𝘁) × (𝗩𝗼𝗹𝘂𝗺𝗲 - 𝗜𝗻𝘀𝘁𝗮𝗹𝗹) -"
ui_print ""
sleep 0.2
ui_print "- 𝗜𝗻𝗷𝗲𝗰𝘁𝗼𝗿 𝗠𝗼𝗱𝗲 -"
ui_print ""
sleep 0.2
ui_print " 1.️ Super - Gaming + Battery "
sleep 0.2
ui_print " 2. ️Quantum - Performance + Balance "
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
IN=1
while true; do
	ui_print "  $IN"
	if $VKSEL; then
		IN=$((IN + 1))
	else 
		break
	fi
	if [ $IN -gt 2 ]; then
		IN=1
	fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $IN "
#
case $IN in
	1 ) TEXT3="✓Sᴜᴘᴇʀ "; FCTEXTAD1="𝐒𝐮𝐩𝐞𝐫"; cp -af $MODPATH/SQMods/injectors/super $MODPATH/Injectors;;
	2 ) TEXT3="✓Qᴜᴀɴᴛᴜᴍ "; FCTEXTAD1="𝐐𝐮𝐚𝐧𝐭𝐮𝐦"; cp -af $MODPATH/SQMods/injectors/quantum $MODPATH/Injectors;;
esac
ui_print " 𝗜𝗻𝗷𝗲𝗰𝘁𝗼𝗿 𝗠𝗼𝗱𝗲: $FCTEXTAD1 "
ui_print ""
sleep 0.5
ui_print "- 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗘𝗻𝗴𝗶𝗻𝗲 -"
ui_print ""
sleep 0.2
ui_print "- 𝑵𝑶𝑻𝑬: ᴅᴇꜱᴛʀᴏʏ ᴀʟʟ ᴘᴀᴛʜ ᴛʜᴇʀᴍᴀʟꜱ "
ui_print ""
sleep 0.2
ui_print " 1. Enable "
sleep 0.2
ui_print " 2. Disable "
sleep 0.2
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
TE=1
while true; do
	ui_print "  $TE"
	if $VKSEL; then
		TE=$((TE + 1))
	else 
		break
	fi
	if [ $TE -gt 2 ]; then
		TE=1
	fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $TE "
#
case $TE in
 1 ) TEXT4="✓ᴛʜᴇʀᴍᴀʟꜱ "; FCTEXTAD2="𝐄𝐧𝐚𝐛𝐥𝐞"; mkdir -p $MODPATH/system/vendor/etc/init $MODPATH/system/vendor/bin $MODPATH/system/vendor/lib $MODPATH/system/vendor/lib64 $MODPATH/system/bin $MODPATH/system/etc/init; cp -af $MODPATH/SQMods/thermals/* $MODPATH/system/vendor/etc; touch $MODPATH/system/vendor/bin/thermal-engine; touch $MODPATH/system/vendor/lib/libthermalclient.so; touch $MODPATH/system/vendor/lib64/libthermalclient.so; touch $MODPATH/system/vendor/bin/thermal_factory; touch $MODPATH/system/vendor/bin/mi_thermald; touch $MODPATH/system/bin/thermalserviced; touch $MODPATH/system/vendor/etc/init/android.hardware.thermal@1.0-service.rc; touch $MODPATH/system/bin/thermalserviced; touch $MODPATH/system/etc/init/thermalservice.rc;;
 2 ) TEXT4=""; FCTEXTAD2="𝐃𝐢𝐬𝐚𝐛𝐥𝐞"; rm -rf $MODPATH/SQMods/thermals/;;
esac
ui_print "- 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗘𝗻𝗴𝗶𝗻𝗲 𝗠𝗼𝗱𝗲: $FCTEXTAD2 "
ui_print ""
sleep 0.5
ui_print "- 𝗨𝗻𝗶𝘃𝗲𝗿𝘀𝗮𝗹 𝗚𝗠𝗦 𝗗𝗼𝘇𝗲 -️"
ui_print ""
sleep 0.2
ui_print "- 𝑵𝑶𝑻𝑬: ɢᴍꜱ ᴅᴏᴢᴇ ꜱᴛᴏᴘ ᴄᴇʀᴛᴀɪɴ ꜱᴇʀᴠɪᴄᴇꜱ ᴀɴᴅ ʀᴇꜱᴛᴀʀᴛ ɪᴛ ᴏɴ ᴇᴠᴇʀʏ ʙᴏᴏᴛ "
ui_print ""
sleep 0.2
ui_print " 1. Enable "
sleep 0.2
ui_print " 2. Disable "
sleep 0.2
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
GS=1
while true; do
 ui_print "  $GS"
 if $VKSEL; then
  GS=$((GS + 1))
 else 
  break
 fi
 if [ $GS -gt 2 ]; then
  GS=1
 fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $GS "
#
case $GS in
 1 ) TEXT5="✓ɢᴍꜱ "; FCTEXTAD3="𝐄𝐧𝐚𝐛𝐥𝐞"; cp -af $MODPATH/SQMods/tweaks/gms $MODPATH/Injectors;;
 2 ) TEXT5=""; FCTEXTAD3="𝐃𝐢𝐬𝐚𝐛𝐥𝐞"; rm -rf $MODPATH/SQMods/tweaks/gms;;
esac
ui_print "- 𝗚𝗠𝗦 𝗠𝗼𝗱𝗲: $FCTEXTAD3 "
ui_print ""
sleep 0.5
ui_print "- 𝗞𝗲𝗿𝗻𝗲𝗹 𝗧𝘄𝗲𝗮𝗸𝘀 -️"
ui_print ""
sleep 0.2
ui_print "- 𝑵𝑶𝑻𝑬: ᴛᴡᴇᴀᴋɪɴɢ ᴋᴇʀɴᴇʟ ꜱᴇᴛᴛɪɴɢꜱ, ꜱᴜᴄʜ ᴀꜱ ꜱᴄʜᴇᴅ_ꜰᴇᴀᴛᴜʀᴇꜱ ᴀɴᴅ ᴄᴘᴜꜱᴇᴛ "
ui_print " ᴘʀᴏꜰɪʟᴇ ʏᴏᴜ ᴄᴀɴ ꜱᴘᴇᴇᴅ ᴜᴘ ʏᴏᴜʀ ᴀɴᴅʀᴏɪᴅ ᴘʜᴏɴᴇ ᴏʀ ɪɴᴄʀᴇᴀꜱᴇ ɪᴛꜱ ʙᴀᴛᴛᴇʀʏ ʟɪꜰᴇ. "
ui_print ""
sleep 0.2
ui_print " 1. Enable "
sleep 0.2
ui_print " 2. Disable "
sleep 0.2
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
KT=1
while true; do
 ui_print "  $KT"
 if $VKSEL; then
  KT=$((KT + 1))
 else 
  break
 fi
 if [ $KT -gt 2 ]; then
  KT=1
 fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $KT "
#
case $KT in
 1 ) TEXT6="✓ᴋᴇʀɴᴇʟ "; FCTEXTAD4="𝐄𝐧𝐚𝐛𝐥𝐞"; cp -af $MODPATH/SQMods/tweaks/kernel $MODPATH/Injectors;;
 2 ) TEXT6=""; FCTEXTAD4="𝐃𝐢𝐬𝐚𝐛𝐥𝐞"; rm -rf $MODPATH/SQMods/tweaks/kernel;;
esac
ui_print "- 𝗞𝗲𝗿𝗻𝗲𝗹 𝗠𝗼𝗱𝗲: $FCTEXTAD4 "
ui_print ""
sleep 0.5
ui_print "- 𝗠𝗶𝘀𝗰𝗲𝗹𝗹𝗮𝗻𝗲𝗼𝘂𝘀 𝗧𝘄𝗲𝗮𝗸𝘀 -️"
ui_print ""
sleep 0.2
ui_print "- 𝑵𝑶𝑻𝑬: ᴛᴡᴇᴀᴋɪɴɢ ᴍɪꜱᴄᴇʟʟᴀɴᴇᴏᴜꜱ ꜱᴇᴛᴛɪɴɢꜱ, ꜱᴜᴄʜ ᴀꜱ ᴛᴜʀɴ ᴏꜰꜰ "
ui_print " ᴅᴏᴜʙʟᴇᴛᴀᴘ2ᴡᴀᴋᴇ ᴀɴᴅ ᴅᴇᴄʀᴇᴀꜱᴇ ʙʀɪɢʜᴛɴᴇꜱꜱ ʏᴏᴜ ᴄᴀɴ ɪᴍᴘʀᴏᴠᴇ ʙᴀᴛᴛᴇʀʏ ʟɪꜰᴇ. "
ui_print ""
sleep 0.2
ui_print " 1. Enable "
sleep 0.2
ui_print " 2. Disable "
sleep 0.2
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
MT=1
while true; do
 ui_print "  $MT"
 if $VKSEL; then
  MT=$((MT + 1))
 else 
  break
 fi
 if [ $MT -gt 2 ]; then
  MT=1
 fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $MT "
#
case $MT in
 1 ) TEXT7="✓ᴍɪꜱᴄᴇʟʟᴀɴᴇᴏᴜꜱ "; FCTEXTAD5="𝐄𝐧𝐚𝐛𝐥𝐞"; cp -af $MODPATH/SQMods/tweaks/misc $MODPATH/Injectors;;
 2 ) TEXT7=""; FCTEXTAD5="𝐃𝐢𝐬𝐚𝐛𝐥𝐞"; rm -rf $MODPATH/SQMods/tweaks/misc;;
esac
ui_print "- 𝗠𝗶𝘀𝗰𝗲𝗹𝗹𝗮𝗻𝗲𝗼𝘂𝘀 𝗠𝗼𝗱𝗲: $FCTEXTAD5 "
ui_print ""
sleep 0.5
ui_print "- 𝗦𝗼𝘂𝗻𝗱 𝗕𝗼𝗼𝘀𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 -️"
ui_print ""
sleep 0.2
ui_print "- 𝑵𝑶𝑻𝑬: ᴛᴡᴇᴀᴋɪɴɢ ᴋᴇʀɴᴇʟ ꜱᴏᴜɴᴅ ꜱᴇᴛᴛɪɴɢꜱ, ꜱᴜᴄʜ ᴀꜱ ʜᴇᴀᴅᴘʜᴏɴᴇ_ɢᴀɪɴ, "
ui_print "  ᴍɪᴄ_ɢᴀɪɴ ᴀɴᴅ ᴇᴀʀᴘɪᴇᴄᴇ_ɢᴀɪɴ ꜰᴏʀ ɪᴍᴘʀᴏᴠɪɴɢ ʙᴇᴛᴛᴇʀ ꜱᴏᴜɴᴅ. "
ui_print ""
sleep 0.2
ui_print " 1. Enable "
sleep 0.2
ui_print " 2. Disable "
sleep 0.2
ui_print ""
sleep 0.2
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁: "
SB=1
while true; do
 ui_print "  $SB"
 if $VKSEL; then
  SB=$((SB + 1))
 else 
  break
 fi
 if [ $SB -gt 2 ]; then
  SB=1
 fi
done
ui_print " 𝗦𝗲𝗹𝗲𝗰𝘁𝗲𝗱: $SB "
#
case $SB in
 1 ) TEXT8="✓ꜱᴏᴜɴᴅ "; FCTEXTAD6="𝐄𝐧𝐚𝐛𝐥𝐞"; cp -af $MODPATH/SQMods/tweaks/sound $MODPATH/Injectors;;
 2 ) TEXT8=""; FCTEXTAD6="𝐃𝐢𝐬𝐚𝐛𝐥𝐞"; rm -rf $MODPATH/SQMods/tweaks/sound;;
esac
ui_print "- 𝗦𝗼𝘂𝗻𝗱 𝗠𝗼𝗱𝗲: $FCTEXTAD8 "
ui_print ""
sleep 0.5
sed -i "/description=/c description=${TEXT1}${TEXT2}${TEXT}${TEXT3}${TEXT4}${TEXT5}${TEXT6}${TEXT7}${TEXT8}" $MODPATH/module.prop;
fstrim -v /data;
fstrim -v /system;
fstrim -v /cache;
fstrim -v /vendor;
fstrim -v /product;
ui_print ""
sleep 0.5
ui_print "- ⚡𝙎𝙐𝙋𝙀𝙍乛𝙌𝙪𝙖𝙣𝙩𝙪𝙢 𝙄𝙣𝙟𝙚𝙘𝙩𝙤𝙧 𝙝𝙖𝙨 𝙗𝙚𝙚𝙣 𝙞𝙣𝙨𝙩𝙖𝙡𝙡𝙚𝙙 𝙨𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮!⚡ -"
ui_print ""
sleep 1