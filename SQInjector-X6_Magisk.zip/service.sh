#===========================================================================#
# ╭━━━┳━━━┳━━╮╱╱╱╱╱╱╱╱╱╱╭╮
# ┃╭━╮┃╭━╮┣┫┣╯╱╱╱╭╮╱╱╱╱╭╯╰╮
# ┃╰━━┫┃╱┃┃┃┃╱╭━╮╰╋━━┳━┻╮╭╋━━┳━╮
# ╰━━╮┃┃╱┃┃┃┃╱┃╭╮┳┫┃━┫╭━┫┃┃╭╮┃╭╯
# ┃╰━╯┃╰━╯┣┫┣╮┃┃┃┃┃┃━┫╰━┫╰┫╰╯┃┃
# ╰━━━┻━━╮┣━━╯╰╯╰┫┣━━┻━━┻━┻━━┻╯
# ╱╱╱╱╱╱╱╰╯╱╱╱╱╱╭╯┃ 𝑩𝒚 𝜜𝒌𝒊𝒓𝒂_𝑽𝒊𝒔𝒉𝒂𝒍
# ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰━╯
#===========================================================================#
# GIVE PROPER CREDITS IF YOU USE THE PART OF IT IN YOUR WORK, THANKS!
#===========================================================================#
#!/system/bin/sh
MODDIR=${0%/*}

if [ -e $MODDIR/setprop.sh ]; then
     sh $MODDIR/setprop.sh
fi

sleep 30
rm -r /data/dalvik-cache
rm -rf /cache/*.apk
rm -f /cache/*.tmp
rm -f /data/*.log
rm -f /data/*.txt
rm -f /data/anr/*
rm -f /data/backup/pending/*.tmp
rm -f /data/cache/*.*
rm -f /data/data/*.log
rm -f /data/data/*.txt
rm -f /data/log/*.log
rm -f /data/log/*.txt
rm -f /data/local/*.apk
rm -f /data/local/*.log
rm -f /data/local/*.txt
rm -f /data/local/tmp/*
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/wlan_logs
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -f /sdcard/*.log
rm -f /sdcard/*.CHK
rm -f /storage/emulated/0/*.log
rm -f /data/dalvik-cache/*.apk
rm -f /data/dalvik-cache/*.tmp
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/wlan_logs
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -f /sdcard/*.CHK
rm -rf $MODPATH/SQMods
sleep 5
if [ -e $MODDIR/system/vendor/bin/thermal-engine ]; then
     echo "Enabled Empty Thermal Engine Executed on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/SQ_Logs/SQInjector.log
     echo "" >> /storage/emulated/0/SQ_Logs/SQInjector.log
fi
# Config Enabler
# By Zackptg5
for i in $MODDIR/Injectors/*; do
  case $i in
    *-ls|*-ls.sh);;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done