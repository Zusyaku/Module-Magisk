#===========================================================================#
# ╭━━━┳━━━┳━━╮╱╱╱╱╱╱╱╱╱╱╭╮
# ┃╭━╮┃╭━╮┣┫┣╯╱╱╱╭╮╱╱╱╱╭╯╰╮
# ┃╰━━┫┃╱┃┃┃┃╱╭━╮╰╋━━┳━┻╮╭╋━━┳━╮
# ╰━━╮┃┃╱┃┃┃┃╱┃╭╮┳┫┃━┫╭━┫┃┃╭╮┃╭╯
# ┃╰━╯┃╰━╯┣┫┣╮┃┃┃┃┃┃━┫╰━┫╰┫╰╯┃┃
# ╰━━━┻━━╮┣━━╯╰╯╰┫┣━━┻━━┻━┻━━┻╯
# ╱╱╱╱╱╱╱╰╯╱╱╱╱╱╭╯┃ 𝑩𝒚 𝜜𝒌𝒊𝒓𝒂_𝑽𝒊𝒔𝒉𝒂𝒍
# ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰━╯
#===========================================================================#
# Enable Props
# By Akira (akira-vishal @ GitHub)
#===========================================================================#
# GIVE PROPER CREDITS IF YOU USE THE PART OF IT IN YOUR WORK, THANKS!
#===========================================================================#
#!/system/bin/sh

while true; do
setprop net.tcp.buffersize.hsdpa 4096,32768,65536,4096,32768,65536;
setprop net.tcp.buffersize.hspa 4096,32768,65536,4096,32768,65536;
setprop net.tcp.buffersize.hspap 4096,32768,65536,4096,32768,65536;
setprop net.tcp.buffersize.hsupa 4096,32768,65536,4096,32768,65536;
setprop net.tcp.buffersize.umts 4095,87380,110208,4096,32768,110208;
setprop net.tcp.buffersize.default 4094,87380,1220608,4096,32768,1220608;
setprop net.tcp.buffersize.edge 4093,26280,35040,4096,16384,35040;
setprop net.tcp.buffersize.evdo 4093,26280,35040,4096,16384,35040;
setprop net.tcp.buffersize.gprs 4092,8760,11680,4096,8760,11680;
setprop net.tcp.buffersize.wifi 4094,87380,1220608,4096,32768,1220608;
break;
done >/dev/null 2>&1

while true; do
setprop dalvik.vm.checkjini false;
setprop ro.kernel.android.checkjni 0;
setprop ro.kernel.checkjni 0;
setprop ro.config.nocheckin 1;
setprop debug.systemui.latency_tracking 0;
setprop persist.sample.eyetracking.log 0;
setprop ro.com.google.locationfeatures 0;
setprop ro.com.google.networklocation 0;
setprop media.metrics.enabled 0;
setprop sys.debug.watchdog 0;
setprop logd.statistics 0;
setprop media.metrics 0;
setprop config.stats 0;
setprop persist.sys.loglevel 0;
setprop sys.log.app 0;
setprop persist.traced.enable 0;
setprop logd.statistics 0;
setprop persist.sample.eyetracking.log 0;
setprop debug.atrace.tags.enableflags 0;
setprop debugtool.anrhistory 0;
setprop ro.debuggable 1;
setprop profiler.debugmonitor false;
setprop profiler.launch false;
setprop profiler.hung.dumpdobugreport false;
setprop trustkernel.log.state disable;
setprop debug.mdpcomp.logs 0;
setprop debug.atrace.tags.enableflags 0;
setprop pm.sleep_mode 1;
setprop profiler.force_disable_ulog true;
setprop profiler.force_disable_ulog 1;
setprop profiler.force_disable_err_rpt true;
setprop profiler.force_disable_err_rpt 1;
setprop ro.logd.size.stats 0;
setprop debug.atrace.tags.enableflags 0;
setprop persist.service.pcsync.enable 0;
setprop persist.service.lgospd.enable 0;
break;
done >/dev/null 2>&1

#===========================================================================#