#!/system/bin/sh
#
#swap off first
swapoff /dev/block/zram0
#
# resetting zram
echo 1 > /sys/block/zram0/reset
#
# setting zram size to 4 GB
echo 4192000000 > /sys/block/zram0/disksize
#
# making zram swapable
mkswap /dev/block/zram0
#
# starting swap on zram
swapon /dev/block/zram0
#
# setting low memory killer parameters according to total memory
echo "256,10240,32000,34000,36000,38000,40000,42000" > /sys/module/lowmemorykiller/parameters/minfree
#
# setting swappiness to 100
echo 100 > /proc/sys/vm/swappiness
#
# done

cat /sys/module/lowmemorykiller/parameters/minfree
