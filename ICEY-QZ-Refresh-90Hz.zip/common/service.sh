#!/system/bin/sh
#mark zuckerberg
MODDIR=${0%/*}
if [ -e /sys/kernel/fast_charge/force_fast_charge ]; then
  echo "1" > /sys/kernel/fast_charge/force_fast_charge
fi
# This script will be executed in late_start service mode
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# Magisk Busybox Symlink for Apps 
ln -s /sbin/.magisk/busybox/*

# Sleep
sleep 30
##mark zuckerberg
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo "98 1797200:40" > /sys/devices/system/cpu/cpufreq/policy0/performance/target_loads 
echo "98 1797200:40" > /sys/devices/system/cpu/cpufreq/policy0/interactive/target_loads 
echo "98 1797200:40" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/target_loads 
echo "98 1958000:40 2190000:80" > /sys/devices/system/cpu/cpufreq/policy4/performance/target_loads 
echo "98 1988000:40 2190000:80" > /sys/devices/system/cpu/cpufreq/policy4/interactive/target_loads 
echo "98 1988000:40 2190000:80" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/target_loads 
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "Interactive" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 
echo "Interactive" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 
echo "100" > /sys/devices/system/cpu/cpufreq/policy0/performance/go_hispeed_load 
echo "100" > /sys/devices/system/cpu/cpufreq/policy0/interactive/go_hispeed_load 
echo "100" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/go_hispeed_load 
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/performance/go_hispeed_load
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/interactive/go_hispeed_load
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/go_hispeed_load
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_freq
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy0/interactive/hispeed_freq
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '1988000' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_freq
echo '1988000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/hispeed_freq
echo '1988000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq
echo '7035' > /sys/class/touch/switch/set_touchscreen
echo "0" > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/boost 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/align_windows 
echo "0" > /sys/devices/system/cpu/cpufreq/interactive/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/interactive/boost 
echo "1" > /sys/devices/system/cpu/cpufreq/interactive/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/interactive/align_windows 
echo "0" > /sys/devices/system/cpu/cpufreq/schedutil/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/boost 
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/align_windows 
echo "performance" > /sys/kernel/gpu/gpu_governor 
echo "1" > /sys/class/devfreq/5900000.qcom,kgsl-3d0/subsystem/5900000.qcom,kgsl-3d0/adrenoboost
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active 
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores 
echo "0-7" > /dev/cpuset/foreground/cpus 
echo "0-7" > /dev/cpuset/foreground/boost/cpus 
echo "0-7" > /dev/cpuset/system-background/cpus 
echo "0-7" > /dev/cpuset/rt/cpus 
echo "0-7" > /dev/cpuset/top-app/cpus 
echo "0-7" > /dev/cpuset/audio-app/cpus 
echo "0-7" > /dev/cpuset/background/cpus 
echo "0-7" > /dev/cpuset/camera-daemon/cpus 
echo "0-7" > /dev/cpuset/rt/cpus 
echo '0-7' > /sys/devices/system/cpu/online;
echo '12' > /dev/stune/foreground/schedtune.boost
echo '8' > /dev/stune/schedtune.boost
echo '1' > /dev/stune/foreground/schedtune.sched_boost_no_override 
echo '1' > /dev/stune/top-app/schedtune.sched_boost_no_override 
echo '0' > /dev/stune/schedtune.colocate 
echo '0' > /dev/stune/background/schedtune.colocate 
echo '0' > /dev/stune/system-background/schedtune.colocate 
echo '0' > /dev/stune/foreground/schedtune.colocate 
echo '1' > /dev/stune/top-app/schedtune.colocate 
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/interactive/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/interactive/iowait_boost_enable;
echo "647" > /sys/kernel/gpu/gpu_max_clock;
echo "588" > /sys/kernel/gpu/gpu_min_clock;
echo '2150000' > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq;
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq;
echo '1797200' > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq;
echo '633000' > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq;

# CPU INPUT BOOST FREQ
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/performance/up_rate_limit_us	
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_freq
echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us	
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/up_rate_limit_us	
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/interactive/hispeed_freq
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/interactive/pl
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/performance/up_rate_limit_us
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_freq
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/up_rate_limit_us
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/interactive/hispeed_freq
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/interactive/pl

#TCP CONGESTION CONTROL
if [ -e /proc/sys/net/ipv4/tcp_congestion_control ]; then
  echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control
fi
 
#I/O
echo 'cfq' > /sys/block/mmcblk0/queue/scheduler
echo 'cfq' > /sys/block/mmcblk1/queue/scheduler 
echo '512' > /sys/block/mmcblk0rpmb/queue/read_ahead_kb                                                                                                                                                                                                                                    
echo '128' > /sys/block/mmcblk0rpmb/queue/nr_requests 
echo '512' > /sys/block/mmcblk0/bdi/read_ahead_kb
echo '512' > /sys/block/mmcblk0rpmb/bdi/read_ahead_kb
echo '512' > /sys/block/dm-0/queue/read_ahead_kb

# Internal & External Speed up
echo 'cfq' > /sys/block/sda/queue/scheduler
echo '512' > /sys/block/sda/queue/read_ahead_kb
echo '0' > /sys/block/sda/queue/rotational
echo '0' > /sys/block/sda/queue/iostats
echo '0' > /sys/block/sda/queue/add_random
echo '1' > /sys/block/sda/queue/rq_affinity
echo '0' > /sys/block/sda/queue/nomerges
echo '128' > /sys/block/sda/queue/nr_requests
echo 'cfq' > /sys/block/sdb/queue/scheduler
echo '512' > /sys/block/sdb/queue/read_ahead_kb
echo '0' > /sys/block/sdb/queue/rotational
echo '0' > /sys/block/sdb/queue/iostats
echo '0' > /sys/block/sdb/queue/add_random
echo '1' > /sys/block/sdb/queue/rq_affinity
echo '0' > /sys/block/sdb/queue/nomerges
echo '128' > /sys/block/sdb/queue/nr_requests
echo 'cfq' > /sys/block/sdc/queue/scheduler
echo '512' > /sys/block/sdc/queue/read_ahead_kb
echo '0' > /sys/block/sdc/queue/rotational
echo '0' > /sys/block/sdc/queue/iostats
echo '0' > /sys/block/sdc/queue/add_random
echo '1' > /sys/block/sdc/queue/rq_affinity
echo '0' > /sys/block/sdc/queue/nomerges
echo '128' > /sys/block/sdc/queue/nr_requests
echo 'cfq' > /sys/block/sdd/queue/scheduler
echo '512' > /sys/block/sdd/queue/read_ahead_kb
echo '0' > /sys/block/sdd/queue/rotational
echo '0' > /sys/block/sdd/queue/iostats
echo '0' > /sys/block/sdd/queue/add_random
echo '1' > /sys/block/sdd/queue/rq_affinity
echo '0' > /sys/block/sdd/queue/nomerges
echo '128' > /sys/block/sdd/queue/nr_requests
echo 'cfq' > /sys/block/sde/queue/scheduler
echo '512' > /sys/block/sde/queue/read_ahead_kb
echo '0' > /sys/block/sde/queue/rotational
echo '0' > /sys/block/sde/queue/iostats
echo '0' > /sys/block/sde/queue/add_random
echo '1' > /sys/block/sde/queue/rq_affinity
echo '0' > /sys/block/sde/queue/nomerges
echo '128' > /sys/block/sde/queue/nr_requests
echo 'cfq' > /sys/block/sdf/queue/scheduler
echo '512' > /sys/block/sdf/queue/read_ahead_kb
echo '0' > /sys/block/sdf/queue/rotational
echo '0' > /sys/block/sdf/queue/iostats
echo '0' > /sys/block/sdf/queue/add_random
echo '1' > /sys/block/sdf/queue/rq_affinity
echo '0' > /sys/block/sdf/queue/nomerges
echo '128' > /sys/block/sdf/queue/nr_requests

#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 

# Google Service Config Reduce Drain
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService"
su -c "pm disable com.google.android.gms/NearbyMessagesService"
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService"
su -c "pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService"
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

#Fstrim 
fstrim /cache
fstrim /system
fstrim /data

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53

# Removed Log
if [ -e /storage/emulated/0/network.log ]; then
rm /storage/emulated/0/network.log
fi

# init.d enabler
if [ "$1" == "-ls" ]; then LS=true; else LS=false; fi

for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
    *) ;;
  esac
done

# VIRTUAL MEMORY
stop perfd
echo '128' > /proc/sys/kernel/random/read_wakeup_threshold
echo '256' > /proc/sys/kernel/random/write_wakeup_threshold
echo '512' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '512' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '1' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '100' > /proc/sys/vm/swappiness
echo '50' > /sys/module/zswap/parameters/max_pool_percent
echo '0' > /proc/sys/vm/page-cluster
echo '8' > /sys/block/zram0/max_comp_streams 
echo 'lz4' > /sys/block/zram0/comp_algorithm
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '0' > /sys/block/mmcblk0/queue/rotational
echo '1' > /sys/block/mmcblk0/queue/rq_affinity
echo '0' > /sys/block/mmcblk0/queue/nomerges
echo '1' > /proc/sys/vm/dirty_background_ratio
echo '0' > /proc/sys/vm/page-cluster 
echo '100' > /proc/sys/vm/swappiness;
echo '100' > /proc/sys/vm/overcommit_ratio
echo '70' > /proc/sys/vm/dirty_background_ratio;
echo '90' > /proc/sys/vm/dirty_ratio;
echo '300' > /proc/sys/vm/vfs_cache_pressure;
echo '300' > /proc/sys/vm/dirty_writeback_centisecs;
echo '150' > /proc/sys/vm/dirty_expire_centisecs;
echo '30000' > /proc/sys/vm/extra_free_kbytes
echo '512' > /sys/block/ram0/queue/read_ahead_kb
echo '512' > /sys/block/ram1/queue/read_ahead_kb
echo '512' > /sys/block/ram2/queue/read_ahead_kb
echo '512' > /sys/block/ram3/queue/read_ahead_kb
echo '512' > /sys/block/ram4/queue/read_ahead_kb
echo '512' > /sys/block/ram5/queue/read_ahead_kb
echo '512' > /sys/block/ram6/queue/read_ahead_kb
echo '512' > /sys/block/ram7/queue/read_ahead_kb
echo '512' > /sys/block/ram8/queue/read_ahead_kb
echo '512' > /sys/block/ram9/queue/read_ahead_kb
echo '512' > /sys/block/ram10/queue/read_ahead_kb
echo '512' > /sys/block/ram11/queue/read_ahead_kb
echo '512' > /sys/block/ram12/queue/read_ahead_kb
echo '512' > /sys/block/ram13/queue/read_ahead_kb
echo '512' > /sys/block/ram14/queue/read_ahead_kb
echo '512' > /sys/block/ram15/queue/read_ahead_kb
echo '512' > /sys/block/vnswap0/queue/read_ahead_kb
echo '8192' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
chmod 666 /sys/module/lowmemorykiller/parameters/minfree;
chown root /sys/module/lowmemorykiller/parameters/minfree;
echo '16384,24576,32768,65536,131072,163840' > /sys/module/lowmemorykiller/parameters/minfree;
swapoff /dev/block/zram0 > /dev/null 2>&1
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize
echo '1' > /sys/block/zram0/max_comp_streams
echo '2147483648' > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1

#FORCE FAST CHARGE
chmod 777 /sys/class/power_supply/*/*
chmod 777 /sys/module/qpnp_smbcharger/*/*
chmod 777 /sys/module/dwc3_msm/*/*
chmod 777 /sys/module/phy_msm_usb/*/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '160' > /sys/class/power_supply/bms/temp_cool
echo '480' > /sys/class/power_supply/bms/temp_hot
echo '480' > /sys/class/power_supply/bms/temp_warm
echo '2250000' > /sys/class/power_supply/usb/current_max
echo '2250000' > /sys/class/power_supply/usb/hw_current_max
echo '2250000' > /sys/class/power_supply/usb/pd_current_max
echo '2250000' > /sys/class/power_supply/usb/ctm_current_max
echo '2250000' > /sys/class/power_supply/usb/sdp_current_max
echo '2250000' > /sys/class/power_supply/main/current_max
echo '2250000' > /sys/class/power_supply/main/constant_charge_current_max
echo '2250000' > /sys/class/power_supply/battery/current_max
echo '2250000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '4500000' > /sys/class/qcom-battery/restricted_current
echo '2250000' > /sys/class/power_supply/pc_port/current_max
echo '2450000' > /sys/class/power_supply/constant_charge_current__max
sleep 1
done
exit 0