# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false
# Put true if you need system.prop
PROPFILE=true
# Put true if you need post-fs-data.sh
POSTFSDATA=true
# Put true if you need service.sh
LATESTARTSERVICE=true
# Only Works with iUnlocker if you have the Ram expansion key put this to true
IUNLOCKER_RAMEXPANSION=true
. "$TMPDIR/function"
iScreen "
sys.iunlocker.cleaner=true" >> $magisk_sp
unzip -o "$ZIPFILE" 'system/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'iUnlockerVolAddons/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'RamExpansion/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'iSaddons/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'binkit/*' -d $TMPDIR >&2
. $TMPDIR/iUnlockerVolAddons/iUnlockerVpath/install.sh
  if [ "$abi" == "arm64-v8a" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "x86" ]; then
IF32; SWITCH=true
  elif [ "$abi" == "armeabi-v7a" ]; then
  IF32; SWITCH=true
  elif [ "$abi" == "x86_64" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "arm" ]; then
IF32; SWITCH=true
  elif [ "$abi" == "arm64" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "x64" ]; then
IF64; SWITCH=true
else
iScreen " Abi not Verified abortion..."
exit 0
  fi
# Clean up binkit
if [[ "$SWITCH" == true ]]; then
CLEAR $TMPDIR/binkit
fi
if [ -e /data/adb/modules/iUnlocker-PUBG-NewState ]; then
Remove_dir /data/adb/modules/iUnlocker-PUBG-NewState
Remove_dir /data/adb/modules_update/iUnlocker-PUBG-NewState
elif [ -e /data/adb/modules_update/iUnlocker-PUBG-NewState ]; then
Remove_dir /data/adb/modules_update/iUnlocker-PUBG-NewState
wtf="wtf"
fi

# PUBG MOBILE SUPPORTED VERSIONS
IN | CH | TW | VIT | GB | KR

Ad="/data/adb/modules_update/iUnlockerIII/iSaddons"
Kits="/data/adb/modules_update/iUnlocker-Addons-kit"


#SuperClone
SCState_game() {
if [ -e $Superclone ]; then
iScreen "iUnlockerList2.SuperClone.120fps=true" >> $magisk_sp
Tstate_game=$SCState1
else
Tstate_game=$SCState2
iScreen " - $Game_14 $SCState2! Skipping list 2"
  #6
  fi
  }
 #
DeadBydaylightDBDState_game() {
if [ -e $Deadbydaylight ]; then
iScreen "iUnlockerL2G5=$dbd_game_state" >> $magisk_sp
Tstate_game=$DBDState1
else
iScreen " - $Game_15 $DBDState2! Skipping list 2"
Tstate_game=$DBDState2
fi
}    
 #
 # LifeAfter
     LifeAfterState_game() {
     if [ -e $Lifeafter ]; then
     iScreen "iUnlockerList2.LifeAfter.120fps=true" >> $magisk_sp
     Tstate_game="$LifeState1"
       else
       iScreen " - $Game_12 $LifeState2! Skipping list 2"
       Tstate_game="$LifeState2"
       fi
}
     #
     # Cyber Hunter lo(w)
     CyberHunterLOW() {
     if [ -e $Cyberhunter ]; then
         iScreen "iUnlockerList2.CyberHunter.low=true" >> $magisk_sp 
         Tstate_game="$CHState1"
         else
         iScreen " - $Game_13 $CHState2! Skipping list 2"
         Tstate_game="$CHState2"
         fi
}
     #
     # Cyber hunter Hig(h)
     CyberHunterHIGH() {
     if [ -e $Cyberhunter ]; then
     iScreen "iUnlockerList2.CyberHunter.High=true" >> $magisk_sp
Tstate_game="$CHState1"
         else
         iScreen " - $Game_13 $CHState2! Skipping list 2"
         Tstate_game="$CHState2"
         fi
}
 #
 # Minecraft PE
MINECRAFT_PE() {
       if [ -e $MinecraftPE ]; then
       iScreen "binary.iunlocker.List2.MinecraftPE=true" >> $magisk_sp
       Tstate_game="$MCPEState1"
       else
         iScreen " - $Game_16 $MCPEState1! Skipping list 2"
         Tstate_game="$MCPEState2"
         fi
}
#### Start
#
#
#
## Other modules RM code!
MODULE1='unlock-it'
MODULE2='unlocker'
MODULE3='unlock*'
# Print'em
iScreen "! - Modules will be removed if you have them" >> $iLog
iScreen "$MODULE1" >> $iLog
iScreen "$MODULE2" >> $iLog
iScreen "$MODULE3" >> $iLog
iScreen "! - **********************" >> $iLog
iScreen 'remove_over_modules=true' >> $magisk_sp

# - # - # - # - # - # Loading List 1
iScreen ""
iScreen "!***************************************!"
Game_print "(1) [- ❌ Skip list 1]"
iScreen ""
Game_print "(2) [BGMI | PUBG & Mobile Legend & Lol Wild Rift] #90fps"
iScreen ""
Game_print "(3) [PUBG & Fortnite] #90fps"
iScreen ""
Game_print "(4) [League of Legends WildRift] #120fps"
iScreen ""
Game_print "(5) [Call Of Duty Mobile] #120fps"
iScreen ""
Game_print "(6) [Asphalt 9 & Sky Children of light] #60fps"
iScreen ""
Game_print "(7) [Cyber Hunter] #90fps"
iScreen ""
Game_print "(8) [Forsaken World: Gods and Demons] #90fps"
iScreen ""
iScreen "!***************************************!"
L1=1
    while true; do
	              ui_print "#Number: $L1"
	 if $VKSEL; then
		        L1=$((L1 + 1))
	       else 
break
	     fi
	 if [ $L1 -gt 8 ]; then
       L1=1
	       fi
           done
case $L1 in
  #1
1) iUnlocker="| Skip list 1";;
2) iUnlocker="| $Game_1 + $Game_8 + $Game_6 | $iiifps_rate, $supported_versions"; iScreen "binary.iunlocker.PUBG.MlLegend.LolWilDRift=true" >> $magisk_sp;;
  #2
3) iUnlocker="| $Game_1 + $Game_7 | $iiifps_rate, $supported_versions"; iScreen "binary.iunlocker.fortnite.pubg=true" >> $magisk_sp;;
  #3
4) iUnlocker="| $Game_6 | $iiiifps_rate"; iScreen "binary.iunlocker.lolwildrift.120fps=true" >> $magisk_sp;;
  #4
5) iUnlocker="| $Game_5 | $iiiifps_rate"; iScreen "binary.iunlocker.CODM.120fps=true" >> $magisk_sp;;
  #5
6) iUnlocker="| $Game_4 + $Game_11 | $iifps_rate"; iScreen "binary.iunlocker.asphalt.skyChildren.60fps=true" >> $magisk_sp;;
  #6
7) iUnlocker="| $Game_10 | $iiifps_rate"; iScreen "binary.iunlocker.CyberHunter.90fps=true" >> $magisk_sp;;
  #7
8) iUnlocker="| $Game_3 | $iiiifps_rate"; iScreen "binary.iunlocker.ForsakenWorld.120fps=true" >> $magisk_sp;;
esac
iScreen ""
iLogs "
💵 - [ LIST 1 ]:
🎚️ You Select : $iUnlocker
🎚️ Game VSTF: 0.1Alpha
🎚️ AuthorName: $iAuth

"
iScreen ""
iLogs "*************************"
iScreen "!***************************************!"
Game_print "(1) [ Skip × list 2] "
iScreen ""
Game_print "(2) [ Life After ] #120fps"
iScreen ""
Game_print "(3) [ Cyber Hunter ] #Low Graphics"
iScreen ""
Game_print "(4) [ Cyber Hunter ] #High Graphics"
iScreen ""
Game_print "(5) [ Super Clone ] #120fps"
iScreen ""
Game_print "(6) [ Dead by daylight ] #120fps"
iScreen ""
Game_print "(7) [ Minecraft ] #Optmize Chunks"
iScreen ""
iScreen "!***************************************!"

iScreen ""

L2=1
    while true; do
	              ui_print "#Number: $L2"
	 if $VKSEL; then
		        L2=$((L2 + 1))
	       else 
break
	     fi
	 if [ $L2 -gt 7 ]; then
       L2=1
	       fi
           done
case $L2 in
1) List2iUnlocker="| $non_game "; iScreen "binary.iunlocker.skip=true" >> $magisk_sp; BuiltIN="No type found! cuz you skipped the list"; Tstate_game="No Game found";;
  #2 
2) List2iUnlocker="| $Game_12 | $iiiifps_rate"; LifeAfterState_game; BuiltIN="$Graphics_type3";;
  #3
3) List2iUnlocker="| $Game_13 + $iGraphics_type"; CyberHunterLOW; BuiltIN="$Graphics_type1";;
  #4
4) List2iUnlocker="| $Game_13 | $iiGraphics_type"; CyberHunterHIGH; BuiltIN="$Graphics_type1";;
  #5
5) List2iUnlocker="| $Game_14 | $iiiifps_rate"; SCState_game; BuiltIN="$Graphics_type3";;
6) List2iUnlocker="| $Game_15 | $iiiifps_rate"; DBDState_game; BuiltIN="$Graphics_type3";;
7) List2iUnlocker="| $Game_16"; MINECRAFT_PE; BuiltIN="$Graphics_type2, $Graphics_type4";;

esac
iLogs "

💵 [ LIST 2 ]:
🎚️ You Select : $List2iUnlocker
🎚️ Game state: $Tstate_game
🎚️ Game VSTF: 6.0
🎚️ UnlockType: $BuiltIN
🎚️ AuthorName: $iAuth

 "
iScreen ""
iScreen "!***************************************!"
iScreen ""
        iScreen "  |/\| - Do you want SDM888 CHIP And it Optimization?"
iScreen ""
          iScreen " (1) - YES, Of course i want it, Wtf?"
iScreen ""
  iScreen " (2) - NO, Nah i don't want that :|, (Skip)"
iScreen ""
IUNLOCKER_SDM_SHIT=1
    while true; do
	ui_print "#Number: $IUNLOCKER_SDM_SHIT"
	if $VKSEL; then
	IUNLOCKER_SDM_SHIT=$((IUNLOCKER_SDM_SHIT + 1))
	else 
            break
fi
	 if [ $IUNLOCKER_SDM_SHIT -gt 2 ]; then
       IUNLOCKER_SDM_SHIT=1
	       fi
           done
case $IUNLOCKER_SDM_SHIT in
1) iUnlockerSDM="Active"; iScreen "binary.iunlocker.put.SDM888.chip=true" >> $magisk_sp; BuiltIN="$Graphics_type4";;
2) iUnlockerSDM="non-active";;
esac
iScreen ""
iScreen "!***************************************!"

iLogs "

💵 [ Optimization list 1 ]:
🎚️ You Select : $iUnlockerSDM for Set to SDM888
🎚️ UnlockType: $BuiltIN
🎚️ Game VSTF: non-game
🎚️ AuthorName: $iAuth
"

iScreen ""
iScreen ""
iScreen "  |/\| - Do you want to Enable Ram Expansion?"
iScreen ""
iScreen " (1) - YES, I want to Extend and optimize my Ram"
iScreen ""
iScreen " (2) - NO, I don't want this feature, (Skip)"
iScreen ""
RAM_EXPANSION=1
    while true; do
iScreen ""
	              ui_print "🏷️Number: $RAM_EXPANSION"
	 if $VKSEL; then
		        RAM_EXPANSION=$((RAM_EXPANSION + 1))
	       else 
break
	     fi
	 if [ $RAM_EXPANSION -gt 2 ]; then
       RAM_EXPANSION=1
	       fi
           done
case $RAM_EXPANSION in
1) iOPTION="Active"; iScreen "sys.iunlocker.ram.expansion=true" >> $magisk_sp;;
2) iOPTION="non-active"; iScreen "sys.iunlocker.ram.expansion=false" >> $magisk_sp;;
esac
iScreen ""
iScreen "You choose(d) - $iOPTION - for RAM EXPANSION"
iLogs "
🎚️RAM EXPANSION State: - $iOPTION
 "
 iScreen "!***************************************!"
iScreen ""
### iBattery Saver
iScreen " |\/| - Do you want to enable battery life saver?"
iScreen ""
iScreen " (1) - YES, I want this feature"
iScreen ""
iScreen " (2) - NO, I don't want this"
IBATTERY_SAVER=1
    while true; do
iScreen ""
	              ui_print "🏷️Number: $IBATTERY_SAVER"
	 if $VKSEL; then
		        IBATTERY_SAVER=$((IBATTERY_SAVER + 1))
	       else 
break
	     fi
	 if [ $IBATTERY_SAVER -gt 2 ]; then
       IBATTERY_SAVER=1
	       fi
           done
case $IBATTERY_SAVER in
1) iBATTERY_SAVER_OPTION="Active"; iScreen "sys.iunlocker.ibattery.saver=true" >> $magisk_sp;;
2) iBATTERY_SAVER_OPTION="non-active"; iScreen "sys.iunlocker.ibattery.saver=false" >> $magisk_sp;;
esac
iScreen ""
iScreen "You choose(d) - $iBATTERY_SAVER_OPTION - for battery life saver"
iLogs "
🔋Battery Saver State: - $iBATTERY_SAVER_OPTION
"
iScreen ""


Remove_dir $TMPDIR/function
chmod 777 $TMPDIR/iSaddons/*
  chmod 777 $TMPDIR/iUnlocker
  chmod 777 $TMPDIR/system/bin/*
  chmod 777 /data/adb/modules_update/iUnlocker-Addons-kit/*
