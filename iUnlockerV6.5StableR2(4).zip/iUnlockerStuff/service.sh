#!/system/bin/sh
MODDIR=${0%/*}
su -c $MODDIR/iUnlocker
su -c $MODDIR/system/bin/libiunlocker
su -c $MODDIR/RamExpansion/ram_expansion
XIAOMI_DEVICE="$(getprop ro.product.vendor.manufacturer)"
if [ ! "$XIAOMI_DEVICE" != "Xiaomi" ]; then
su -c $MODDIR/system/bin/iUnlockerV9killer
fi