#!/system/bin/sh
# zyractweaks
echo "1"  > /sys/module/mdss_fb/parameters/srgb_enabled
echo "2" > /sys/class/graphics/fb0/msm_fb_srgb
setprop dalvik.vm.dex2oat-filter speed
setprop dalvik.vm.image-dex2oat-filter speed
setprop dalvik.vm.check-dex-sum false
setprop dalvik.vm.checkjni false
setprop dalvik.vm.usejit true
setprop dalvik.vm.execution-mode int:jit
setprop dalvik.vm.verify-bytecode false
setprop dalvik.vm.debug.alloc 0
setprop debug.sf.use_phase_offsets_as_durations 1
setprop vendor.display.disable_rotator_downscale 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 20500000
setprop debug.sf.early.sf.duration 21000000
setprop debug.sf.early.app.duration 16500000
setprop debug.sf.earlyGl.sf.duration 13500000
setprop debug.sf.earlyGl.app.duration 21000000
setprop debug.sf.early_phase_offset_ns 11600000
setprop debug.sf.early_app_phase_offset_ns 11600000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 11600000
setprop ADRENO_PROFILER_ENABLE_OPENCL 1
setprop ADRENO_PROFILER_ENABLE_BLOCKING 1
resetprop -n surface_flinger.max_virtual_display_dimension 4096
resetprop -n surface_flinger.vsync_event_phase_offset_ns 2000000
resetprop -n surface_flinger.vsync_sf_event_phase_offset_ns 6000000
resetprop -n surface_flinger.protected_contents true
resetprop -n surface_flinger.force_hwc_copy_for_virtual_displays true
resetprop -n ro.surface_flinger.max_frame_buffer_acquired_buffers 4
setprop debug.egl.swapinterval 100
setprop debug.gr.swapinterval 0
setprop debug.egl.buffcount 4
setprop debug.performance.tuning 1
setprop debug.hwui.render_dirty_regions false
setprop debug.qctwa.preservebuf 1
setprop debug.egl.profiler 0
setprop debug.overlayui.enable 1
setprop debug.enabletr true
setprop hwui.render_dirty_regions false
setprop debug.egl.hw 0
resetprop -n ro.sf.compbypass.enable 0
resetprop -n ro.sf.disable_triple_buffer 0
setprop vendor.debug.egl.swapinterval -60
setprop debug.composition.type c2d
setprop persist.sys.composition.type c2d
setprop debug.hwui.show_dirty_regions false
setprop debug.qc.hardware true
setprop persist.sampling_profiler 0
resetprop -n ro.config.disable.hw_accel false
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.hw 0
setprop debug.cpurend.vsync false
setprop hwui.disable_vsync true
setprop debug.sf.no_hw_vsync 1
setprop hwui.disable_vsync 1
setprop ro.ril.set.mtu1472 1
setprop ro.mot.eri.losalert.delay 2000
setprop persist.cust.tel.eons 1
setprop ro.config.hw_fast_dormancy 1
setprop ro.ril.gprsclass 10
setprop ro.ril.hsdpa.category 8
setprop ro.ril.hsupa.category 6
setprop ro.ril.hsxpa 2
setprop net.tcp.2g_init_rwnd 10
setprop net.tcp.default_init_rwnd 60
setprop net.tethering.noprovisioning true
setprop persist.service.pcsync.enable 0
setprop persist.service.lgospd.enable 0
setprop vidc.debug.level 0
setprop pm.sleep_mode 1
setprop persist.radio.add_power_save 1
setprop persist.vendor.qti.inputopts.enable true
setprop persist.vendor.qti.inputopts.movetouchslop 0.1
setprop persist.sys.use_dithering 0
setprop persist.sys.use_16bpp_alpha 1