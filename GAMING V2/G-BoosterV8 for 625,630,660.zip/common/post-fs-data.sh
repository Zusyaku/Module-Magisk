MODDIR=${0%/*}

if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors ]; then
 gov=/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors
fi

if grep 'schedutil' $gov; then
	cp -f $MODDIR/config/ker $MODDIR/service.sh
else
    if grep 'blu_schedutil' $gov; then
	    cp -f $MODDIR/config/ker $MODDIR/service.sh
	else
	    cp -f $MODDIR/config/nel $MODDIR/service.sh
	fi
fi
