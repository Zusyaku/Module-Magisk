#!/sbin/sh
REPLACE=""


  ui_print "*******************************"
  ui_print "   
█▀▀ █▀ █▀█ █▄█ █▀█ █▀█
█▄█ ▄█ █▀▀ ░█░ █▀▄ █▄█    "
  ui_print "*******************************"

 ui_print "NOTE :- Remove Hellcat Module If You Are Using⚠️"


SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh
