<h1 align="center">NFS INJECTOR-BY K1ks</h1>
<p align="center">
</p>

# Injector
<p align="center"><img src="https://raw.githubusercontent.com/HafizZiq/NFS-Injector/master/injector.png"></p>
A Magisk module which aims to improve kernel/RAM management, by using values between performance and battery savings.
Flash, and forget.

<p align="center">
<a href="https://forum.xda-developers.com/apps/magisk/module-nfs-injectorv1-t3857231"><img src="https://img.shields.io/badge/XDA-Thread-orange.svg?style=flat-square"></a> <a href="https://t.me/nfsinjector"><img src="https://img.shields.io/badge/Telegram-Group-blue.svg?style=flat-square"></a> <a href="https://t.me/nfsreleases"><img src="https://img.shields.io/badge/Telegram-Channel-blue.svg?style=flat-square"></a>
</p>

# Disclaimer
This program is distributed in the hope that it will be useful
I am not responsible for bricked devices, dead SD cards, corrupted partition, nuclear disasters lmao

No to upload on additionals clouds

## Introduction
This module aim to improve kernel / ram management between efficiency and energy aware. Using a complex algorithm , it deteremine the most optimal settings between battery and performance for your device. NFS improve your overall experience , Others Games also. Very simple to use , You just install it and it will handle everything else. This tool is, in part proactive . It takes heavily into account , the amount of memory on your device , to calculate the appropriate values. Excellent multitasting and memory management.

Improve Standby , as well as screen battery life - A smooth and fluid , overal enhanced , user experience 

This Module is Universal , It works on all OS with all kernels (EAS/HMP), Except on Shit/Retarded Kernel. 

## Thread 
★[MODULE][NFS-INJECTOR][PowerFull And Advanced Management Kernel/Ram]

[XDA](https://forum.xda-developers.com/apps/magisk/module-nfs-injectorv1-t3857231)

## Requirements
- ARMv7 (armeabi-v7a)
- ARMv8 (arm64-v8a)
- Magisk v19+
- [Magisk Release](https://github.com/topjohnwu/Magisk/releases)

## Supporter Suggestions
All NFS Members , without Their Help , NFS wouldn't be great 

## Downloads
[Google Drive](https://drive.google.com/open?id=1GZpVYxd1OyS0PyVBXHyOCjPhI-YnLi8x)

## List devices are tested and run with NFS Injector™ Beta :

- Redmi Note 5/Pro
- Redmi K20 Pro
- Redmi Note 7
- Redmi 7
- Redmi 6A
- Redmi 4
- Redmi Note 5A Prime
- Pocophone F1
- Mi Max 3
- Mi A2/Lite
- Redmi 5A
- Pixel 2 XL
- Pixel 4 XL
- Samsung Galaxy S5
- Samsung Galaxy S7/Edge
- Samsung Galaxy Note 8
- Samsung Galaxy Note 3
- Samsung Galaxy S9+
- Samsung Galaxy Note 4
- Samsung Galaxy Alpha
- Samsung Galaxy J7 Pro
- Samsung Galaxy J1 2016
- Samsung Galaxy A90
- OnePlus 3/T
- OnePlus 5
- OnePlus 6/6T
- HTC U12+
- Moto X4
- Asus Max Pro M1
- Asus Max Pro M2

## NFS - Injector Telegram
[Telegram Group](https://t.me/nfsinjector)

## Credits 
- NFS Lead Developer - [K1ks](https://t.me/K1ks1)
- Lead Developer Helper - [Hafiz](https://t.me/HafizZiq)
- Graphic Designer - [xLidz](https://t.me/xlidz)
- NFS Manager - [Sunil Paul Mathew M.](https://t.me/sunilpaulmathew)
- Magisk Developer - [Topjohnwu](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445)
- Unity Template Developers - [Zackptg5 and Ahrion](https://forum.xda-developers.com/android/software/module-audio-modification-library-t3579612)
- MMT-Extended - [Zackptg5](https://forum.xda-developers.com/apps/magisk/magisk-module-template-extended-mmt-ex-t4029819)

## Changelog

### X1
- Add CodeName : Zoom 
- Add Codeversion : X1
- Update Governor Database ( Add lightningutil & InteractiveS9 Support)
- Drop cdg tcp Support ( Unstable )
- Add sqlite,fps,kernel build info and gpu info
- Update Game List ( Add azure lane game )
- Use UID To Bypass Kernel Blocker
- Update System Property Accessory
- Add Special Property For Android 10
- Add Supersampling Tuner ( Pro )
- Update Ads/Analytics Disabler
- Update Doze
- update EAS Specific Kernel 
- Add UX Task Optimizer ( Pro )
- Update VM & Swapinness
- Update LMK
- Update CPU_Boost ( Turn Off Boost only for Battery Saver Mode Now)
- Update Schedtune & Dyn schedtune
- Add Process Scheduler Tuner
- Update Overwatch According To Current VM
- Force Using Magisk BusyBox For Some command
- Update Binary Name
- Whole Code Revision
- Fix Derped Code
- Update Command
- Fixx Null Main Linnker
- Compiled Using Clang 9.x, Enabled LTO and O3 Optimisation
- Reduce Binary Size
- Some Cleanup On Compiler Side
- Update NFS Manager ( V1.3 )

### V13.5
- Update Anti-Blocker
- Improve Binary Security
- Update VM
- Algorithm Upgrade For LMK
- Nuke Boeffla ( Specific Kernel wakelocks )
- Improve EAS Governor Detection
- Fix Governor Detection
- Update CPU Tune Database ( Add schedutilX Governor, Fix Script )
- Update IO
- Remove chown
- NFS Manager For Public
- Update OpenGL Tweak Detection

### V13.1 (Unofficial)
- Update Compiler
- Algorithm Upgrade For LMK
- See Ya Blocker Kernel , Fuck

### V13
- Add CodeName : Guardian
- Adjustments NFS Engine
- Add Detection Klapse Info
- Not Using Magisk Busybox Anymore ( Since Its Fucked Some Command )
- Implementation of Active VM Tuner
- Update Smart Control Logic
- Update Cpu Power EAS
- Update Stune/Dyn Stune Boost Multimode
- Update IO Scheduler
- Update Doze Mode
- Add OverWatch Engine, Experimental ( Pro ) ( Check Device During Its Operation And Settle Device In Function For Prevent Wakelocks And Avoid Excess Memory )
- Add Toggle for Analytics & Ads Google Disabler (ads.txt)
- Remove Swappiness Toggle (swap.txt)
- Remove Launcher/SystemUi Keeper
- Remove Some useless Things after Revision Script
- Update To MMT-E 1.4
- Add chown Functions
- Update Governor Database ( Add interactiveS9 Support )
- Compiler Speed & Security Improvement
- Update LMK & MFK$
- Improve Root Detection
- Misc.

### V12
- Add CodeName : Nemesis
- Add Checking Busybox Path
- Force Using Magisk Busybox
- Adjustments VM / LMK
- Add More Support Stune
- Update IO Request
- Add Launcher / SystemUi Keeper ( Pro )
- Add Internet Shield Ipv4/Ipv6 ( Pro )
- Update Google Play Fix Drain
- Update NetBoost
- LPM Levels Updated
- GPU Optimizer Updated
- Kill Nfs Binary
- Switch To MMT-Extended
- Icreased Security
- Add More Things
- Misc.

### V11.1
- Fix Magisk Issue
- Fix More

### V11
- Add CodeName : BrainStorm
- Update to Unity 5.0
- Implementation Of The Basic / Pro Version
- Update Boot Complete Script
- Update Smart Control
- Add X86 Soc Support
- Update Cpu Scheduler
- Adjustments VM & LMK & MFK$
- Update NetBoost and Add support Buffersize/Ril Multimode
- Add Analytics & Ads Google Disabler
- Add Open GL Renderer Tuner
- Add Doze Custom
- Full Fix Revision
- Fix After Boot
- Update Waiting Time
- Misc.

### V10.0
- Add CodeName : Santa
- HotFix Selinux Things
- Misc.

### V9.5
- Add CodeName : Santa
- Update LMK & MFK$ Calculation Balanced / Battery
- Update System Proprety Accessory
- Add msmnile Prime Detection
- Add More Stuffs in LowMemoryKiller
- Misc.

### V9.0
- Add CodeName : Titan
- Add Support Cdg/Bbr Tcp
- Update HMP/EAS Specific Values
- Update CPU Database
- Update CPU_Boost
- Update Thermal Base
- Update VM & LMK & MFK$ Calculation
- Remove Breaker
- Full Script Revision
- Misc

### V8.8
- Add CodeName : Paragon
- Update LMK
- Update IO Scheduler Blocks
- Misc.

### V8.7
- Add CodeName : Paragon
- Hotfix VM Value
- Add Thermal Switch Support
- Update Minfree/Mfk For Ram Management
- Update IO Scheduler Blocks
- Add Swappiness Value Control
- Rcu & Reference Amount Mem Removed
- Misc.

### V8.6
- Add CodeName : Paragon
- Increase VM For Ultra / Balanced
- Update IO Scheduler Blocks
- Update Hmp / Eas Specific Values
- Increase AdrenoBoost Values
- Add Support For Stune Off
- Fix Partial Log

### V8.5
- Add CodeName : Paragon
- Encrypted Version For Kangers
- Breaker Updated for LS
- Update VM & LMK
- Update Calculation IO Blocks
- Update System Proprety Accessory
- Update Kernel Task
- Zram & Simple Gpu Support Over
- Sync No More Disabled by Default
- Total Check Script

### V8.0
- Add CodeName : Infinite
- Update VM & LMK
- Update Gpu Optimizer for AdrenoBoost
- Update Hmp/Eas Specific Values
- Clean / Fix Script
- Add Support Intelliactive
- Update NetBoost

### V7.8
- Hotfix Zram/Zswap Part

### V7.7
- Hotfix For VnSwap

### V7.6
- Hotfix For PUBG Detection

### V7.5
- Add CodeName : FlashPoint
- Update Breaker , compatibilty LSpeed
- Update All Propety
- Add Support for TCP Receive Buffer Size
- Update VM For All Profiles
- Update Memory Management
- Add Multiples LMK Parameters
- Update Smart Control
- Update Dalvik Tuner
- Remove Some Props Lines
- Fix All Perms

### V7.0
- Add CodeName : DeathStroke
- Update Minfree/Mfk For Ram Management
- Update LMK Calculation
- Update NetSpeed
- Update CPU Scheduler
- Update All boost update ( Cpuboost , Dsboost .....)
- Update Boeffla Wakelock Blocker Path
- Disable Some More debugs
- Update Smart Control Variable
- Add GPU Frequency Throttling Disabled
- Update VM for Balanced / Ultra
- Add SQLite Query Optimizer
- Script Cleanups And Rearrange Back
- Update Logging
- Add AARCH Detection
- Fix Boeffla Wakelock Path
- Update To Unity 4.4

### V6.5
- Add CodeName : Archer
- Add Some Name Packages Game
- Update Smart Control For IO Sched
- Fix Mode Status After Clean Flash
- Update Minfree/Mfk/EMfk For Ram Management
- Update Cpu Power , Cultivation added
- Add Detection Specific HMP/EAS Kernel Part Tuner ( No Trademark )
- Add Gpu Optimizer ( No Trademark )
- Update Dalvik Tuner
- Update I/O Schreduling , All values readjusted
- Log improved , All gamed showing
- Update Logging
- Update To Unity 4.2

### V6.3
- Update low RAM detection level (Under 2048Mb)
- Ajustement Smart Control on Middle Range devices

### V6.2
- HotFix For Redraw Issue

### V6.0
- Add CodeName : Steel
- Improved Fluidity
- Update Kernel Tasks
- Add Status Flash ( Clean Flash )
- Improved Kill Debugging
- Improved Swappiness Management
- Update Minfree/Mfk/EMfk For Ram Management
- Smart Control ( Automatic Detection )
- Update Sync Module ( ON/OFF )
- Add Support For Phantom governor
- Add Some Name Packages Game
- Add Support For Disable Touchwiz Swap
- Add Low Power Management Levels
- Update Logging
- Update To Unity 4.1

### V5.5
- Add CodeName : Crisis
- Update Cpu Interactive
- Update Kernel Tasks
- Improved Security ( WARNING )
- Add Net Values
- Add More Dns Custom ( Verisign , CleanBrowsing : Testing ...)
- Add Dalvik Tuner
- Add Magisk Version Detection
- Update Mfk/Emfk Calculation
- Update Sync Module
- Update / Fix To Unity 4.0

### V5.0
- Add CodeName : Hunter
- Update Minfree/Mfk in Ram Management
- Update Gaming Mode
- Add Multi Mode Property
- Script Restructuring ( Reorganizations )
- Update To Unity 3.3
- Update Compression Modules
- Thanks To @zackptg5 For fix Unity 3.3

### V4.5
- Add CodeName : GodSpeed
- Update IO Scheduler with Tunables Modes
- Update Cpu Power
- Total Revision of the NFS Engine
- Some Stuff removed
- Update VM Kernel All Modes

### V4.0
- Add CodeName : FireStorm
- Update Governors Database ( See Support List Governors )
- Update Cpu Power with Tunables values
- Improve LMK For Battery Saver & Balanced
- Stune Boost Reduction for Ultra & Gaming
- Remove Battery Stats features ( Useless ) 
- Bypassing Bad Info CPU Cores
- Update Adj Custom in Memory Management
- Adreno Idler Customs for Balance/Battery_Saver
- Remover Tpd Mode & Hid Magic & Clean Up & Net Values

### V3.5
- Add CodeName : Art_Light
- Update Module to Unity V3
- Add Battery Mode , All Modes Renammed
```
0 : Balance Mode
1 : Ultra Mode
2 : Game Mode
3 : Battery Saver Mode
```
- Update All Values
- New Method Settings for TCP & SELinux
- Fix Zip Recognition by Magisk
- FIX DNS and Add Google Public DNS
- Add Some Governors & Schedulers
- Update Fix GP
- Update config Boeffla wakelock blocker
- New Formula calculation MKK/EMFK
- Remove Launcher UI Keeper and Fstrim
- Correct Perms & Clean Script

### V3.2
- Update Network Speed , Stable Connections Browsing / Pubg
- Fix Half Log ( Analytics off )

### V3.1
- Fix Google Analytics Off
- Fix Zram Script
- Little Adjustments on Cpu Boost & Random
- Minor Fix

### V3.0
- Add CodeName : ForceFul
- Re Enable SeLinux Permissive
- Complete Update LowMemory Killer
- Update SchedTune
- Add Cpu Power Governor
- Update Network Speed
- Add Control Scheduler
- Update Network Speed
- Added ability to change profiles

```
0 : Balance Mode
1 : Performance Mode
2 : Game Mode
```
- Add DnsGuard DNS / DNS CloudFlare
- Add Scale Up Animation
- Fix CPU Power
- Mutate Old GP Fix to Google Analytics Off
- Various Fix and Clean Script

### V2.7
- Update Network Speed
- Add Reset Battery Stats
- Update Random Optimizer
- Add Priority Process
- Add Disable Ksm/uKsm if Useless

### V2.5
- Update Module Prop
- Update Low Memory Killer / VM
- Update Entro / Random
- Update Tcp Congestion
- Add Deactivation TouchBoost
- Add Kill Debugging
- Add Some set Wackelocks
- Add Deactivation Kernel Tasks
- Add Secutity Check
- Rngd Removed

### V2.0
- Update Low Memory Killer
- Adjuste VM a little More
- Adjuste Stune
- Update KSM
- Update Random
- Add FSTrim System / Data / Cache
- Add Clean Up

### V1.5
- Add Disable CRC checks ( Battery + )
- Update Low Memory Killer
- Update VM
- Update IO Queue Size
- ZRam / Zswap Disabled ( Battery + )
- Add SchedTune Boost Tune
- Add Disable Fast Dormancy ( Battery + )
- Various fix ( Incompatible with current kernel for Inappropriate Values )
- Remove Custom Doze , unsuitable value with new system
- Clean Script

### V1.2
- Remove Mount System
- Update Kill Google Apps and Network
- Fix Force Close app and Magisk query
- Update Module to Unity v1.7.2

### V1.0
- Initial Release
