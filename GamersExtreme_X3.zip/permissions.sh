#permissions
if [ $TYPEINSTALL = magisk ]; then
	chmod 755 $MAGISKUP/system/bin/gex
else
	chmod 755 $SYSTEM/bin/gex
fi
