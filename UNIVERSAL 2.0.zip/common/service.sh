#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode


# Kernel based tweaks that reduces the amount of wasted CPU cycles to maximum and gives back a huge amount of needed performance to both the system and the user;
echo "0" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "0" > /proc/sys/kernel/nmi_watchdog
echo "5" > /proc/sys/kernel/sched_walt_init_task_load_pct
echo "0" > /proc/sys/kernel/sched_tunable_scaling

#cpu tweak
chown system system /sys/devices/system/cpu/cpufreq/interactive/*
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
restorecon -R /sys/devices/system/cpu
chmod 0644 /sys/devices/system/cpu/cpufreq/interactive/*
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor 
echo "2000000" > /sys/devices/system/cpu/cpufreq/interactive/hispeed_freq
echo "90" > /sys/devices/system/cpu/cpufreq/interactive/target_loads 
echo "90000" > /sys/devices/system/cpu/cpufreq/interactive/above_hispeed_delay
echo "50" > /sys/devices/system/cpu/cpufreq/interactive/go_hispeed_load 
echo "40000" > /sys/devices/system/cpu/cpufreq/interactive/min_sample_time 
echo "20000" > /sys/devices/system/cpu/cpufreq/interactive/timer_rate 
echo "20000" > /sys/devices/system/cpu/cpufreq/interactive/timer_slack 
echo "10000" > /sys/devices/system/cpu/cpufreq/interactive/boostpulse_duration 

# scheduler TWEAK
chmod 0644 /sys/block/sda/queue/*
chmod 0644 /sys/block/sdb/queue/*
chmod 0644 /sys/block/sdc/queue/*
echo "deadline" > /sys/block/mmcblk0/queue/scheduler 
echo "deadline" > /sys/block/sda/queue/scheduler
echo "deadline" > /sys/block/sdb/queue/scheduler 
echo "deadline" > /sys/block/sdc/queue/scheduler 

stop logd
stop thermald
echo always_on > /sys/devices/platform/13040000.mali/power_policy;
echo alweys_on > /sys/devices/platform/13040000.mali/gpuinfo;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed;
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer;
echo boost > /sys/devices/system/cpu/sched/sched_boost;
echo '1' > /sys/devices/system/cpu/eas/enable;
echo '7035' > /sys/class/touch/switch/set_touchscreen

# [KGSL-3D0 WITHOUT THROTTLING] 
#
write "/sys/class/kgsl/kgsl-3d0/throttling" "0"


# [Tweaks For MEDIATEK] 
#
if [[ -e "/sys/class/devfreq/10012000.dvfsrc_top/ ]]
 write "/sys/class/devfreq/10012000.dvfsrc_top/governor" "performance"
 write "/sys/class/devfreq/10012000.dvfsrc_top/min_freq" "400"
 write "/sys/class/devfreq/10012000.dvfsrc_top/max_freq" "$(cat $gpu/devfreq/max_freq)"
fi;


# Network tweaks for slightly reduced battery consumption when being "actively" connected to a network connection;
#
echo "1" > /proc/sys/net/ipv4/route/flush
echo "1" > /proc/sys/net/ipv4/tcp_mtu_probing;
echo "0" > /proc/sys/net/ipv4/conf/all/rp_filter
echo "0" > /proc/sys/net/ipv4/conf/default/rp_filter
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_all
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
echo "1" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses
echo "1" > /proc/sys/net/ipv4/conf/all/log_martians
echo "1" > /proc/sys/kernel/kptr_restrict 
echo "6" > /proc/sys/net/ipv4/tcp_retries2
echo "1" > /proc/sys/net/ipv4/tcp_low_latency
echo "0" > /proc/sys/net/ipv4/tcp_slow_start_after_idle
echo "0" > /proc/sys/net/ipv4/conf/default/secure_redirects
echo "0" > /proc/sys/net/ipv4/conf/default/accept_redirects
echo "0" > /proc/sys/net/ipv4/conf/default/accept_source_route
echo "0" > /proc/sys/net/ipv4/conf/all/secure_redirects
echo "0" > /proc/sys/net/ipv4/conf/all/accept_redirects
echo "0" > /proc/sys/net/ipv4/conf/all/accept_source_route
echo "0" > /proc/sys/net/ipv4/ip_forward
echo "0" > /proc/sys/net/ipv4/ip_dynaddr
echo "0" > /proc/sys/net/ipv4/ip_no_pmtu_disc
echo "0" > /proc/sys/net/ipv4/tcp_ecn
echo "1" > /proc/sys/net/ipv4/tcp_timestamps
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse
echo "1" > /proc/sys/net/ipv4/tcp_fack
echo "1" > /proc/sys/net/ipv4/tcp_sack
echo "1" > /proc/sys/net/ipv4/tcp_dsack
echo "1" > /proc/sys/net/ipv4/tcp_rfc1337
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling
echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save
echo "2" > /proc/sys/net/ipv4/tcp_synack_retries
echo "2" > /proc/sys/net/ipv4/tcp_syn_retries
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo "10" > /proc/sys/net/ipv4/tcp_fin_timeout
echo "1800" > /proc/sys/net/ipv4/tcp_keepalive_time
echo "2097152" > /proc/sys/net/core/rmem_max
echo "2097152" > /proc/sys/net/core/wmem_max
echo "1048576" > /proc/sys/net/core/rmem_default
echo "1048576" > /proc/sys/net/core/wmem_default
echo "300000" > /proc/sys/net/core/netdev_max_backlog
echo "0" > /proc/sys/net/core/netdev_tstamp_prequeue
echo "0" > /proc/sys/net/ipv4/cipso_cache_bucket_size
echo "0" > /proc/sys/net/ipv4/cipso_cache_enable
echo "0" > /proc/sys/net/ipv4/cipso_rbm_strictvalid
echo "0" > /proc/sys/net/ipv4/igmp_link_local_mcast_reports
echo "30" > /proc/sys/net/ipv4/ipfrag_time
echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control
echo "0" > /proc/sys/net/ipv4/tcp_fwmark_accept
echo "600" > /proc/sys/net/ipv4/tcp_probe_interval
echo "60" > /proc/sys/net/ipv6/ip6frag_time


# Google Service Reduce Drain Tweaks Set Config
#
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'


# Magisk Busybox Symlink for Apps
#
ln -s /sbin/.magisk/busybox/*


sleep 30
# Removed Log
#
if [ -e /storage/emulated/0/network.log ]; then
rm /storage/emulated/0/network.log
fi
sleep 5


# init.d enabler
#
if [ "$1" == "-ls" ]; then LS=true; else LS=false; fi

for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
    *) ;;
  esac
done

# iptables
#
iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53

# Set CF DNS servers address
#
setprop net.rmnet0.dns1 1.1.1.1
setprop net.rmnet0.dns2 1.0.0.1

setprop net.rmnet1.dns1 1.1.1.1
setprop net.rmnet1.dns2 1.0.0.1

setprop net.dns1 1.1.1.1
setprop net.dns2 1.0.0.1

setprop net.gprs.dns1 1.1.1.1
setprop net.gprs.dns2 1.0.0.1

setprop net.wcdma.dns1 1.1.1.1
setprop net.wcdma.dns2 1.0.0.1

setprop net.hspa.dns1 1.1.1.1
setprop net.hspa.dns2 1.0.0.1

setprop net.hsdpa.dns1 1.1.1.1
setprop net.hsdpa.dns2 1.0.0.1

setprop net.lte.dns1 1.1.1.1
setprop net.lte.dns2 1.0.0.1

setprop net.ltea.dns1 1.1.1.1
setprop net.ltea.dns2 1.0.0.1

setprop net.ppp0.dns1 1.1.1.1
setprop net.ppp0.dns2 1.0.0.1

setprop net.pdpbr1.dns1 1.1.1.1
setprop net.pdpbr1.dns2 1.0.0.1

setprop net.wlan0.dns1 1.1.1.1
setprop net.wlan0.dns2 1.0.0.1

setprop dhcp.wlan0.dns1 1.1.1.1
setprop dhcp.wlan0.dns2 1.0.0.1

setprop dhcp.eth0.dns1 1.1.1.1
setprop dhcp.eth0.dns2 1.0.0.1

setprop net.eth0.dns1 1.1.1.1
setprop net.eth0.dns2 1.0.0.1

setprop 2606:4700:4700::1111
setprop 2606:4700:4700::1001

# Edit the resolv conf file if it exist
#

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 1.1.1.1\nameserver 1.0.0.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi

done