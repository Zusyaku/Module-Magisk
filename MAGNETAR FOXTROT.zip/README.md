# MAGNETAR
<p align="center">
  <img src="https://github.com/Kyliekyler/MAGNETAR/blob/master/.github/magnetar.png"> 
</p>
 
<p align="center">
  <a href="https://t.me/MAGNETAR1999"><img src="https://img.shields.io/badge/Telegram-Channel-blue.svg"></a><br/><a href="https://t.me/MAGNETARCHAT"><img src="https://img.shields.io/badge/Telegram-Group-blue.svg"></a>
</p>
<br/>

Eliminate Lags and Throttling — Run Your Game Smoothly and Comfortably with No Substantial Performance Drops

# Notes
- This will improve overall performance but in exchange for a bit increased power usage and may cause heating
- Flash at your own risk, I'm not responsible for lost data or bricked devices
- Some phones arent booting when installing the module, try to get logs and send me on the group
- Get the best kernel for your device to handle MAGNETAR's power

# Compatibility
- [![Android 7](https://img.shields.io/badge/Android-7-violet.svg)](https://developer.android.com/)
- [![Android 8](https://img.shields.io/badge/Android-8-yellow.svg)](https://developer.android.com/)
- [![Android 9](https://img.shields.io/badge/Android-9-lightgreen.svg)](https://developer.android.com/)
- [![Android 10](https://img.shields.io/badge/Android-10-brightgreen.svg)](https://developer.android.com/)
- [![Magisk](https://img.shields.io/badge/Magisk-19%2B-00B39B.svg)](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445)
- [![Chipset](https://img.shields.io/badge/Qualcomm-Snapdragon-red.svg)](https://qualcomm.com)
   
# Instructions
- Download and install the module
- Reboot after you finished installing

# Changelog
[![CHANGELOG](https://img.shields.io/badge/CLICK_ME-blue.svg)](https://github.com/Kyliekyler/MAGNETAR/blob/master/CHANGELOG.md)

# Credits
- [Hafiz](https://t.me/HafizZiq) for Fixes and Code Optimization
- [K1ks](https://t.me/K1ks1) for Some of His Tweaks Included in this Module
- [Zackptg5](https://github.com/Zackptg5) for Unity template
- [topjohnwu](https://github.com/topjohnwu) for Magisk
- To my TESTERS who give immediate feedback and hunting 🐞
