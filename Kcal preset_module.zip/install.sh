##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Unity Logic - Don't change/move this section
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
#
# Function Callbacks
#
# The following functions will be called by the installation framework.
# You do not have the ability to modify update-binary, the only way you can customize
# installation is through implementing these functions.
#
# When running your callbacks, the installation framework will make sure the Magisk
# internal busybox path is *PREPENDED* to PATH, so all common commands shall exist.
# Also, it will make sure /data, /system, and /vendor is properly mounted.
#
##########################################################################################
##########################################################################################
#
# The installation framework will export some variables and functions.
# You should use these variables and functions for installation.
#
# ! DO NOT use any Magisk internal paths as those are NOT public API.
# ! DO NOT use other functions in util_functions.sh as they are NOT public API.
# ! Non public APIs are not guranteed to maintain compatibility between releases.
#
# Available variables:
#
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#
# Availible functions:
#
# ui_print <msg>
#     print <msg> to console
#     Avoid using 'echo' as it will not display in custom recovery's console
#
# abort <msg>
#     print error message <msg> to console and terminate installation
#     Avoid using 'exit' as it will skip the termination cleanup steps
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# If you need boot scripts, DO NOT use general boot scripts (post-fs-data.d/service.d)
# ONLY use module scripts as it respects the module status (remove/disable) and is
# guaranteed to maintain the same behavior in future Magisk releases.
# Enable boot scripts by setting the flags in the config section above.
##########################################################################################


# Set what you want to display when installing your module

print_modname() {
  ui_print "*******************************"
  ui_print "     𝘼𝙡𝙡 𝙞𝙣 𝙊𝙣𝙚 𝙋𝙚𝙧𝙨𝙤𝙣𝙖𝙡   "
  ui_print "      𝙈𝙤𝙙𝙪𝙡𝙚𝙨 𝙍𝙖𝙫𝙚𝙣𝙨𝙞𝙖    "
  ui_print "*******************************"
}

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'AIO/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  service=$TMPDIR/service.sh
  state=$MODPATH/AIO/state
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh

  R='\e[01;91m' > /dev/null 2>&1;
  G='\e[01;92m' > /dev/null 2>&1;

ui_print "- 𝘾𝙝𝙤𝙤𝙨𝙚 𝙔𝙤𝙪𝙧 𝘾𝙤𝙣𝙛𝙞𝙜"
sleep 0.2
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➕ ] 𝙉𝙚𝙭𝙩"
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➖ ] 𝙄𝙣𝙨𝙩𝙖𝙡𝙡"
  ui_print "   "
  ui_print "- 🛡️𝙆𝘾𝘼𝙇 𝙋𝙧𝙚𝙨𝙚𝙩🛡️"
  ui_print "     1. 𝙰𝙸𝙾 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     2. 𝙰𝙸𝙾 𝙱𝚛𝚒𝚐𝚑𝚝 "
  ui_print "     3. 𝙰𝙸𝙾 𝙱𝚛𝚒𝚐𝚑𝚝 2 "
  ui_print "     4. 𝙰𝙸𝙾 𝙳𝚎𝚎𝚙 "
  ui_print "     5. 𝙳𝚎𝚎𝚙 𝙱𝚕𝚊𝚌𝚔 𝙲𝚘𝚕𝚘𝚛𝚏𝚞𝚕 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     6. 𝙴𝚡𝚝𝚛𝚎𝚖𝚎 𝙲𝚘𝚘𝚕 "
  ui_print "     7. 𝙵𝚊𝚔𝚎 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     8. 𝙷𝚊𝚛𝚕𝚎𝚢 𝚃𝚎𝚌𝚑 "
  ui_print "     9. 𝙾𝚋𝚜𝚊𝚗𝚒𝚝𝚢 "
  ui_print "    10. 𝙿𝚎𝚛𝚏𝚎𝚌𝚝𝚒𝚘𝚗 "
  ui_print "    11. 𝚅𝚘𝚖𝚎𝚛 𝙱𝚛𝚒𝚐𝚑𝚝 𝙱𝚊𝚕𝚊𝚗𝚌𝚎 "
  ui_print "    12. 𝚆𝚊𝚛𝚖 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "    13. 𝙳𝚘𝚗'𝚝 𝚄𝚜𝚎 𝙺𝙲𝚊𝚕 𝙰𝚍𝚍-𝚘𝚗 "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗞𝗖𝗮𝗹 𝗖𝗼𝗻𝗳𝗶𝗴:"
KC=1
while true; do
	ui_print "  $KC"
	if $VKSEL; then
		KC=$((KC + 1))
	else 
		break
	fi
	if [ $KC -gt 12 ]; then
		KC=1
	fi
done
ui_print "  𝗞𝗖𝗮𝗹 𝗢𝗽𝘁𝗶𝗼𝗻𝘀: $KC"
#
case $KC in
	1 ) FCTEXTAD9="✅ 𝐴𝐼𝑂 𝐴𝑚𝑜𝑙𝑒𝑑"; cp -af $MODPATH/AIO/00aionature.sh $MODPATH/config/00aiokcal.sh; echo "$G     AIO Amoled    $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	2 ) FCTEXTAD9="✅ 𝐴𝐼𝑂 𝐵𝑟𝑖𝑔𝒉𝑡"; cp -af $MODPATH/AIO/00aiobright.sh $MODPATH/config/00aiokcal.sh; echo "$G     AIO Bright    $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	3 ) FCTEXTAD9="✅ 𝐴𝐼𝑂 𝐵𝑟𝑖𝑔𝒉𝑡 2"; cp -af $MODPATH/AIO/00aiobright2.sh $MODPATH/config/00aiokcal.sh; echo "$G    AIO Bright 2   $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	4 ) FCTEXTAD9="✅ 𝐴𝐼𝑂 𝐷𝑒𝑒𝑝"; cp -af $MODPATH/AIO/00aiodeep.sh $MODPATH/config/00aiokcal.sh; echo "$G      AIO Deep      $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	5 ) FCTEXTAD9="✅ 𝐷𝑒𝑒𝑝 𝐵𝑙𝑎𝑐𝑘 𝐶𝑜𝑙𝑜𝑟𝑓𝑢𝑙"; cp -af $MODPATH/AIO/00aiodblack.sh $MODPATH/config/00aiokcal.sh; echo "$G Deep Black Colorful $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	6 ) FCTEXTAD9="✅ 𝐸𝑥𝑡𝑟𝑒𝑚𝑒 𝐶𝑜𝑜𝑙"; cp -af $MODPATH/AIO/00aioextreme.sh $MODPATH/config/00aiokcal.sh; echo "$G    Extreme Cool    $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	7 ) FCTEXTAD9="✅ 𝐹𝑎𝑘𝑒 𝐴𝑚𝑜𝑙𝑒𝑑"; cp -af $MODPATH/AIO/00fakeamoled.sh $MODPATH/config/00aiokcal.sh; echo "$G     Fake Amoled    $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	8 ) FCTEXTAD9="✅ 𝐻𝑎𝑟𝑙𝑒𝑦 𝑇𝑒𝑐𝒉"; cp -af $MODPATH/AIO/00aiohtech.sh $MODPATH/config/00aiokcal.sh; echo "$G    Harley Tech    $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	9 ) FCTEXTAD9="✅ 𝑂𝑏𝑠𝑎𝑛𝑖𝑡𝑦"; cp -af $MODPATH/AIO/00aioobsanity.sh $MODPATH/config/00aiokcal.sh; echo "$G      Obsanity     $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	10 ) FCTEXTAD9="✅ 𝑃𝑒𝑟𝑓𝑒𝑐𝑡𝑖𝑜𝑛"; cp -af $MODPATH/AIO/00aioperfect.sh $MODPATH/config/00aiokcal.sh; echo "$G     Perfection     $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	11 ) FCTEXTAD9="✅ 𝑉𝑜𝑚𝑒𝑟 𝐵𝑟𝑖𝑔𝒉𝑡 𝐵𝑎𝑙𝑎𝑛𝑐𝑒"; cp -af $MODPATH/AIO/00aiovomerb.sh $MODPATH/config/00aiokcal.sh; echo "$G Vomer Bright Balance $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	12 ) FCTEXTAD9="✅ 𝑊𝑎𝑟𝑚 𝐴𝑚𝑜𝑙𝑒𝑑"; cp -af $MODPATH/AIO/00warmamoled.sh $MODPATH/config/00aiokcal.sh; echo "$G Warm Amoled $N" > $state/s_kcal; sh $MODPATH/config/00aiokcal.sh;;
	14 ) FCTEXTAD9="❌ 𝐷𝑜𝑛'𝑡 𝑈𝑠𝑒 𝐾𝐶𝑎𝑙 𝐴𝑑𝑑-𝑜𝑛"; echo "$R KCAL Preset Disabled $N" > $state/s_kcal;;
esac
ui_print "  $FCTEXTAD9 "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️𝙨𝙍𝙂𝘽 𝙊𝙥𝙩𝙞𝙤𝙣𝙨🛡️"
  ui_print "    1. 𝙴𝚗𝚊𝚋𝚕𝚎 𝚜𝚁𝙶𝙱 "
  ui_print "    2. 𝙳𝚒𝚜𝚊𝚋𝚕𝚎 𝚜𝚁𝙶𝙱 "
  ui_print "    3. 𝙳𝚘𝚗'𝚝 𝚄𝚜𝚎 𝚜𝚁𝙶𝙱 𝙰𝚍𝚍-𝚘𝚗 "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝘀𝗥𝗚𝗕 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 3 ]; then
		SR=1
	fi
done
ui_print "  𝘀𝗥𝗚𝗕 𝗢𝗽𝘁𝗶𝗼𝗻𝘀: $SR"
#
#
case $SR in
	1 ) FCTEXTAD10="✅ 𝐸𝑛𝑎𝑏𝑙𝑒 𝑠𝑅𝐺𝐵"; cp -af $MODPATH/AIO/srgb_on $MODPATH/config/srgb.sh; echo $R"sRGB ENABLED$N" > $state/s_srgb; sh $MODPATH/config/srgb.sh;;
	2 ) FCTEXTAD10="📵 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑠𝑅𝐺𝐵"; cp -af $MODPATH/AIO/srgb_off $MODPATH/config/srgb.sh; echo "$R sRGB DISABLED $N" > $state/s_srgb; sh $MODPATH/config/srgb.sh;;
	3 ) FCTEXTAD10="❌ 𝐷𝑜𝑛'𝑡 𝑈𝑠𝑒 𝑠𝑅𝐺𝐵 𝐴𝑑𝑑-𝑜𝑛"; echo "$R sRGB REMOVED $N" > $state/s_srgb;;
esac
ui_print "  $FCTEXTAD10 "
ui_print "   "
ui_print "   "
  }

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
  set_perm_recursive $MODPATH/AIO 0 0 0755 0755
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# Custom Variables for Install AND Uninstall - Keep everything within this function - runs before uninstall/install
unity_custom() {
  : # Remove this if adding to this function
}

# You can add more functions to assist your custom script code
