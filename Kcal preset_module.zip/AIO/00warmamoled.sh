#!/system/bin/sh
# Warm Amoled

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '253 246 243' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '258' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '275' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '251' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "AIO Warm Amoled KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log