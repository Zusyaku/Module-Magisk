#!/system/bin/sh
# Vomer Bright Balance

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '230 232 255' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '243' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '280' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '273' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "AIO Vomer Bright Balance KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log