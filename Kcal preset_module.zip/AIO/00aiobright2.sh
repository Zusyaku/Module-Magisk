#!/system/bin/sh
# AIO Bright 2

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '247 250 255' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '268' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '272' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '269' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "AIO Bright 2 KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log