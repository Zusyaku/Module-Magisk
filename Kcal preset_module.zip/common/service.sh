#!/system/bin/sh
MODDIR=${0%/*}

sleep 30
# config enabler
# by Zackptg5
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh);;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done
