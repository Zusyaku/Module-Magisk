#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# Google Service Config
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

#KCAL BY OZI NAUFAL
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '225 225 233' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '275' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '13' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '260' > /sys/devices/platform/kcal_ctrl.0/kcal_val
echo '260' > /sys/devices/platform/kcal_ctrl.0/kcal_cont

# CPU BOOST
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/performance/up_rate_limit_us	
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/iowait_boost_enable
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/pl
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/performance/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/performance/up_rate_limit_us
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/iowait_boost_enable
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/pl
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_min_freq;
echo '902400' > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy0/scaling_setspeed;
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo '4:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '5:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '6:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '7:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo '0:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '1:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '2:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '3:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq

# This script will be executed in late_start service mode
# More info in the main Magisk thread
