# $1:error_message
bin=$BIN/system/bin
_abort()
{
    echo "$1"
    echo "! Cooling Thermal installation failed."
    exit 1
}
# $1:file_node $2:owner $3:group $4:permission $5:secontext
_set_perm()
{
    local con
    chown $2:$3 $1
    chmod $4 $1
    con=$5
    [ -z $con ] && con=u:object_r:system_file:s0
    chcon $con $1
}

# $1:directory $2:owner $3:group $4:dir_permission $5:file_permission $6:secontext
_set_perm_recursive() {
    find $1 -type d 2>/dev/null | while read dir; do
        _set_perm $dir $2 $3 $4 $6
    done
    find $1 -type f -o -type l 2>/dev/null | while read file; do
        _set_perm $file $2 $3 $5 $6
    done
}

_get_nr_core()
{
    echo "$(cat /proc/stat | grep cpu[0-9] | wc -l)"
}

_is_aarch64()
{
    if [ "$(getprop ro.product.cpu.abi)" == "arm64-v8a" ]; then
        echo "true"
    else
        echo "false"
    fi
}

_is_eas()
{
    if [ "$(grep sched /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors)" != "" ]; then
        echo "true"
    else
        echo "false"
    fi
}

# $1:cpuid
_get_maxfreq()
{
    local fpath="/sys/devices/system/cpu/cpu$1/cpufreq/scaling_available_frequencies"
    local maxfreq="0"

    if [ ! -f "$fpath" ]; then
        echo ""
        return
    fi

    for f in $(cat $fpath); do
        [ "$f" -gt "$maxfreq" ] && maxfreq="$f"
    done
    echo "$maxfreq"
}

_get_socid()
{
    if [ -f /sys/devices/soc0/soc_id ]; then
        echo "$(cat /sys/devices/soc0/soc_id)"
    else
        echo "$(cat /sys/devices/system/soc/soc0/id)"
    fi
}

sed -i "s/#fps/persist.sys.NV_FPSLIMIT=90/g" $props;
cp -af $MODPATH/fpsbooster ; $BIN
cd /data/data
find  . -type f -name '*gms*' -delete
find  . -type f -name '*cache*' -delete
killall disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
cd /sdcard
find  . -type f -name '*bak*' -delete
dumpsys deviceidle force-idle
fstrim -v /data
fstrim -v /system
fstrim -v /vendor
fstrim -v /product
# GMS ripper 1.0
echo "15 15" > /sys/kernel/sound_control/headphone_gain
echo "3" > /sys/kernel/sound_control/mic_gain
echo "7" > /sys/kernel/sound_control/earpiece_gain

echo "SoundBoost is On $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/cooling-thermal.log
echo "" >> /storage/emulated/0/cooling-thermal.log
killall -9 com.google.android.gms
killall -9 com.google.android.gms.persistent
killall -9 com.google.process.gapps
killall -9 com.google.android.gsf
killall -9 com.google.android.gsf.persistent
settings delete global device_idle_constants_user
dumpsys deviceidle enable light
dumpsys deviceidle enable deep
sleep 5
settings put global device_idle_constants

pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity
pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorActivity
pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorMapActivity
pm disable com.google.android.gms/com.google.android.location.settings.ActivityRecognitionPermissionActivity
pm disable com.google.android.gms/com.google.android.location.settings.GoogleLocationSettingsActivity
pm disable com.google.android.gms/com.google.android.location.settings.LocationHistorySettingsActivity
pm disable com.google.android.gms/com.google.android.location.settings.LocationSettingsCheckerActivity
pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity
pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider
pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingContentProvider
pm disable com.google.android.gms/com.google.android.location.internal.LocationContentProvider
pm disable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider
pm disable com.google.android.gms/com.google.android.gms.ads.config.GServicesChangedReceiver
pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver
pm disable com.google.android.gms/.ads.jams.SystemEventReceiver
pm disable com.google.android.gms/.ads.config.FlagsReceiver
pm disable com.google.android.gms/.ads.social.DoritosReceiver
pm disable com.google.android.gms/.analytics.AnalyticsReceiver
pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver
pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver
pm disable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher
pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsSamplerReceiver
pm disable com.google.android.gms/.checkin.CheckinService\$ActiveReceiver
pm disable com.google.android.gms/.checkin.CheckinService\$ClockworkFallbackReceiver
pm disable com.google.android.gms/.checkin.CheckinService\$ImposeReceiver
pm disable com.google.android.gms/.checkin.CheckinService\$SecretCodeReceiver
pm disable com.google.android.gms/.checkin.CheckinService\$TriggerReceiver
pm disable com.google.android.gms/.checkin.EventLogService\$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateActivity
pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver
pm disable com.google.android.gsf/.checkin.EventLogService\$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateService\$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver
pm disable com.google.android.gsf/.checkin.CheckinService
pm disable com.google.android.gsf/.checkin.EventLogService
pm disable com.google.android.gsf/.update.SystemUpdateService
pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService
pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService
echo '75' > /sys/class/graphics/fb0/dynamic_fps;
echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '230 232 255' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '268' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '274' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '247' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "Amoled is On $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/cooling-thermal.log
echo "" >> /storage/emulated/0/cooling-thermal.log
# Disable GMS and IMS run in startup and restart it on boot
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
echo "1" > /proc/sys/net/ipv4/route/flush
echo "1" > /proc/sys/net/ipv4/tcp_mtu_probing;
echo "0" > /proc/sys/net/ipv4/conf/all/rp_filter
echo "0" > /proc/sys/net/ipv4/conf/default/rp_filter
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_all
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
echo "1" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses
echo "1" > /proc/sys/net/ipv4/conf/all/log_martians
echo "1" > /proc/sys/kernel/kptr_restrict 
echo "6" > /proc/sys/net/ipv4/tcp_retries2
echo "1" > /proc/sys/net/ipv4/tcp_low_latency
echo "0" > /proc/sys/net/ipv4/tcp_slow_start_after_idle
echo "0" > /proc/sys/net/ipv4/conf/default/secure_redirects
echo "0" > /proc/sys/net/ipv4/conf/default/accept_redirects
echo "0" > /proc/sys/net/ipv4/conf/default/accept_source_route
echo "0" > /proc/sys/net/ipv4/conf/all/secure_redirects
echo "0" > /proc/sys/net/ipv4/conf/all/accept_redirects
echo "0" > /proc/sys/net/ipv4/conf/all/accept_source_route
echo "0" > /proc/sys/net/ipv4/ip_forward
echo "0" > /proc/sys/net/ipv4/ip_dynaddr
echo "0" > /proc/sys/net/ipv4/ip_no_pmtu_disc
echo "1" > /proc/sys/net/ipv4/tcp_ecn
echo "1" > /proc/sys/net/ipv4/tcp_timestamps
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse
echo "1" > /proc/sys/net/ipv4/tcp_fack
echo "1" > /proc/sys/net/ipv4/tcp_sack
echo "1" > /proc/sys/net/ipv4/tcp_dsack
echo "1" > /proc/sys/net/ipv4/tcp_rfc1337
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling
echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save
echo "2" > /proc/sys/net/ipv4/tcp_synack_retries
echo "2" > /proc/sys/net/ipv4/tcp_syn_retries
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes
echo "320" > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo "10" > /proc/sys/net/ipv4/tcp_fin_timeout
echo "21600" > /proc/sys/net/ipv4/tcp_keepalive_time
echo "2097152" > /proc/sys/net/core/rmem_max
echo "2097152" > /proc/sys/net/core/wmem_max
echo "1048576" > /proc/sys/net/core/rmem_default
echo "1048576" > /proc/sys/net/core/wmem_default
echo "128" > /proc/sys/net/core/netdev_max_backlog
echo "0" > /proc/sys/net/core/netdev_tstamp_prequeue
echo "0" > /proc/sys/net/ipv4/cipso_cache_bucket_size
echo "0" > /proc/sys/net/ipv4/cipso_cache_enable
echo "0" > /proc/sys/net/ipv4/cipso_rbm_strictvalid
echo "0" > /proc/sys/net/ipv4/igmp_link_local_mcast_reports
echo "24" > /proc/sys/net/ipv4/ipfrag_time
echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control
echo "0" > /proc/sys/net/ipv4/tcp_fwmark_accept
echo "1800" > /proc/sys/net/ipv4/tcp_probe_interval
echo "47" > /proc/sys/net/ipv6/ip6frag_time

# MTU Tweak
for i in $(ls /sys/class/net); do
echo "128" > /sys/class/net/"$i"/tx_queue_len
done

for i in $(ls /sys/class/net); do
echo "1500" > /sys/class/net/"$i"/mtu
done

echo "TCP is On $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/cooling-thermal.log
echo "" >> /storage/emulated/0/cooling-thermal.lo
# Disable GMS and IMS run in startup and restart it on boot (custom permissions for Oxygen OS)
cmd appops set com.google.android.gms AUTO_START ignore
cmd appops set com.google.android.ims AUTO_START ignore
exit 0
return $MODPATH/install.sh
