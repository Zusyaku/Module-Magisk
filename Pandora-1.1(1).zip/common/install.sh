#!/system/bin/sh

# Android version selection;
if [[ -f "/sys/kernel/debug/sched_features" ]]
then
w=1
ans="YES"
ui_print "  It seems like your kernel supports enabling HRTICK"
ui_print "- Do you want to enable hrtick?"
ui_print "- HRTICK greatly improves latency but, if not supported by your device, could cause problems."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] YES"
ui_print " [2] NO"
ui_print "Note: HRTICK can cause freezing, lags, if your device have problems with hrtimers"
	while true; do
	ui_print "  $w"
	if $VKSEL; then
		w=$((w + 1))
	else
		break
	fi
	if [ $w -gt 2 ]; then
		w=1
	fi
done

ui_print "  Selected: [$w]"
fi
therm=1
if [ $therm -ne 0 ]; then
ui_print "   "
ui_print "- Do you want to install thermals?"
ui_print "- Thermals can cause issues with cameras, but gives you unthrottled performance"
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] YES"
ui_print " [2] NO"
ui_print " [NOTE]- Thermals may cause issues to your cameras,
           you can reinstall and skip this option if problem persists. "
	while true; do
	ui_print "  $therm"
	if $VKSEL; then
		therm=$((therm + 1))
	else
		break
	fi
	if [ $therm -gt 2 ]; then
		therm=1
	fi
done
ui_print "  Selected: [$therm] "
fi

kcal=1
if [ $kcal -ne 0 ]; then
ui_print "   "
ui_print "- Do you want to install KCAL CONFIGS?"
ui_print "- This changes your screen vividness and brings different color scheme."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] X Reality Engine Kcal™ - brighter,warmer, vivid"
ui_print " [2] Harley Tech Kcal™ - darker, vivid, cooler, more screen details"
ui_print " [3] Vivid Screen Retention Fix - common retention fix preset, but more vivid"
ui_print " [4] No"
ui_print " [NOTE]- you can reinstall and skip this option if problem persists. "
	while true; do
	ui_print "  $kcal"
	if $VKSEL; then
		kcal=$((kcal + 1))
	else
		break
	fi
	if [ $kcal -gt 4 ]; then
		kcal=1
	fi
done
ui_print "  Selected: [$kcal] "
fi
lazy=1
if [ $lazy -ne 0 ]; then
ui_print "   "
ui_print "- Do you want to install lazy kernel optimizer?"
ui_print "- Lazy is a Kernel Optimizer, that may provide performance or smoothness for your device."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] Yes"
ui_print " [2] No"
ui_print " [NOTE]- you can reinstall and skip this option if problem persists. "
	while true; do
	ui_print "  $lazy"
	if $VKSEL; then
		lazy=$((lazy + 1))
	else
		break
	fi
	if [ $lazy -gt 2 ]; then
		lazy=1
	fi
done
ui_print "  Selected: [$lazy] "
fi
swift=1
if [ $swift -ne 0 ]; then
ui_print "   "
ui_print "- Do you want to install Swift?"
ui_print "- Swift is a ROM Optimizer, sets android process and properties for better experience."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] Yes"
ui_print " [2] No"
ui_print " [NOTE]- you can reinstall and skip this option if problem persists. "
	while true; do
	ui_print "  $swift"
	if $VKSEL; then
		swift=$((swift + 1))
	else
		break
	fi
	if [ $swift -gt 2 ]; then
		swift=1
	fi
done
ui_print "  Selected: [$swift] "
fi
fps=1
if [ $fps -ne 0 ]; then
ui_print "  @credits to king unlocker by pedrogingko "
ui_print "- Do you want to use FPS mode unlocker?"
ui_print "- This will unlock various mode by spoofing your device."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] PUBG fps mode unlocker"
ui_print " [2] CODM max frame rate unlocker + ultra (bp)"
ui_print " [3] BLACK DESERT 120 FPS"
ui_print " [4] No"
ui_print " [NOTE]- you can reinstall and skip this option if problem persists. "
	while true; do
	ui_print "  $fps"
	if $VKSEL; then
		fps=$((fps + 1))
	else
		break
	fi
	if [ $fps -gt 4 ]; then
		fps=1
	fi
done
ui_print "  Selected: [$fps] "
fi

renderer=1
if [ $renderer -ne 0 ]; then
ui_print "- Please select your desired renderer"
ui_print "- These renderers may improve your performance."
ui_print "  Vol+ = Next; Vol- = Select "
ui_print " [1] Skia"
ui_print " [2] Vulkan"
ui_print " [3] OpenGL"
ui_print " [4] No"
ui_print " [NOTE]- you can reinstall and skip this option."
	while true; do
	ui_print "  $renderer"
	if $VKSEL; then
		renderer=$((renderer + 1))
	else
		break
	fi
	if [ $renderer -gt 4 ]; then
		renderer=1
	fi
done
ui_print "  Selected: [$renderer] "
fi

case $w in
	1 ) sed -i "858i ctl /sys/kernel/debug/sched_features HRTICK" /data/adb/modules_update/toolbox8/system/bin/lazy;;
	2 ) ui_print " done";;
esac

case $therm in
	1 ) ui_print " done";;
	2 ) rm -rf /data/adb/modules_update/toolbox8/system/vendor;;
esac

case $kcal in
	1 ) echo "echo '252 227 228' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '271' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '1536' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '264' > /sys/devices/platform/kcal_ctrl.0/kcal_val
echo '260' > /sys/devices/platform/kcal_ctrl.0/kcal_cont" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	2 ) echo "echo '236 240 255' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '271' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '240' > /sys/devices/platform/kcal_ctrl.0/kcal_val
echo '270 ' > /sys/devices/platform/kcal_ctrl.0/kcal_cont" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	3 ) echo "echo '240 240 225' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '1' > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '252' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '1520' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '262' > /sys/devices/platform/kcal_ctrl.0/kcal_val
echo '251 ' > /sys/devices/platform/kcal_ctrl.0/kcal_cont" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	4 ) ui_print "Skipped";;
esac

case $lazy in
	1 ) echo "lazy" >> /data/adb/modules_update/toolbox8/service.sh;;
	2 ) rm -rf /data/adb/modules_update/toolbox8/system/bin/lazy;;
esac

case $swift in
	1 ) echo "swift" >> /data/adb/modules_update/toolbox8/service.sh;;
	2 ) rm -rf /data/adb/modules_update/toolbox8/system/bin/swift;;
esac

case $fps in
	1 ) echo "ro.product.model=IN2025" >> /data/adb/modules_update/toolbox8/system.prop;;
	2 ) echo "ro.product.model=SO-52A" >> /data/adb/modules_update/toolbox8/system.prop;;
	3 ) echo "ro.product.model=SM-G975U" >> /data/adb/modules_update/toolbox8/system.prop;;
	4 ) rm -rf /data/adb/modules_update/toolbox8/system.prop;;
esac

case $renderer in
	1 ) echo "resetprop debug.hwui.renderer skiagl" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	2 ) echo "resetprop debug.hwui.renderer skiavk" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	3 ) echo "resetprop debug.hwui.renderer opengl" >> /data/adb/modules_update/toolbox8/post-fs-data.sh;;
	4 ) ui_print "Skipped";;
esac